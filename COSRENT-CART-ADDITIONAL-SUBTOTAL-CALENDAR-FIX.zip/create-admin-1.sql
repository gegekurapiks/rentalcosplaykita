DELETE FROM users WHERE email='1';
INSERT INTO users (id,email,name,role,password_hash,must_change_password)
VALUES ('admin-1','1','Admin','admin','plain$1',0);
