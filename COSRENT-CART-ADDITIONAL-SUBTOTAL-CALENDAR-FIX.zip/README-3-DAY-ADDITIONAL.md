# COSRENT — 3-Day Pricing + Additional

- Harga kostum sekarang dihitung per paket 3 hari: 1–3 hari = 1 paket, 4–6 = 2 paket, dst.
- Admin mengisi `Harga / 3 hari`.
- Admin dapat menambahkan additional berbayar dengan format `Nama|Harga`, contoh `Sepatu|30000`.
- Customer dapat mencentang additional saat checkout.
- Harga additional ditambahkan sekali per order/item, tidak dikali jumlah hari.
- Data lama tetap kompatibel; kolom database baru tidak diwajibkan.
