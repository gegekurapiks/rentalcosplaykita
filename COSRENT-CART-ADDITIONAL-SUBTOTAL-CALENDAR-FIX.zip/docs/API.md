# COSRENT API

## Public
- GET `/api/health`
- GET `/api/config/payment`
- GET `/api/config/couriers`
- GET `/api/costumes?q=&category=`
- GET `/api/costumes/:id`
- GET `/api/availability?costume_id=1&start=YYYY-MM-DD&end=YYYY-MM-DD`
- POST `/api/size-recommendation`

## Customer auth
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/auth/me`
- POST `/api/auth/logout`

## Customer
- POST `/api/orders`
- GET `/api/orders/:id` (hanya pemilik order)
- GET `/api/my/orders`
- POST `/api/payments/proof` (hanya pemilik order)
- POST `/api/reviews`

## Admin
- POST `/api/admin/login`
- GET `/api/admin/me`
- POST `/api/admin/logout`
- GET `/api/admin/stats`
- GET `/api/admin/orders`
- GET `/api/admin/payments`
- GET `/api/admin/costumes`
- GET `/api/admin/customers`
- POST `/api/admin/payment/verify`

## Payment
Pembayaran manual: QRIS, DANA, ShopeePay, GoPay, OVO, dan transfer bank. Tidak memakai Pakasir.
