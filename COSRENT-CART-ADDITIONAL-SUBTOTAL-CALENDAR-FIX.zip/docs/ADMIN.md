# COSRENT Admin

Buka `/admin.html`. Admin login memakai Cloudflare secret `ADMIN_PASSWORD`.

Set secret:
```powershell
npx wrangler secret put ADMIN_PASSWORD
```

Sesi admin disimpan sebagai token acak di D1 dan cookie HttpOnly. Customer tidak dapat mengakses endpoint admin.
