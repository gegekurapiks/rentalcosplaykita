# COSRENT — Full Feature Audit & Order Lifecycle Fix

Versi ini mempertahankan database D1 production dan tidak melakukan DROP/RESET/migration otomatis.

## Fokus perbaikan

### Pesanan sebelum pembayaran
- Pesanan yang belum dibayar tidak lagi terkunci hanya karena status lama (`pending`, `waiting_payment`, dll.).
- Customer dapat mengedit tanggal, penerima, HP, alamat, dan catatan selama pembayaran belum diterima.
- Upload bukti pembayaran juga tetap tersedia selama pesanan belum dibayar dan belum selesai/dibatalkan.
- Admin dapat mengedit detail pesanan sebelum/ketika belum dibayar dan tidak dipaksa menunggu pembayaran untuk mengatur status/pengiriman.

### Schema D1 compatibility
- Order fields lama (`start_date/end_date`, `customer_name`, `payment_method`) dan schema baru (`ship_date/return_date`, `recipient_*`, `shipping_cost`, dll.) dinormalisasi.
- Tidak mengasumsikan `orders.user_id`, `orders.status`, `orders.total`, `payments.method_id`, `payments.proof_image`, `reviews.status`, `payment_methods`, `shipping`, `order_items`, `maintenance`, atau `ktp_records` selalu tersedia.
- Query hanya memakai kolom/tabel yang ditemukan melalui schema D1.
- `PRAGMA table_info` dipakai untuk inspeksi schema; Cloudflare D1 mendukung inspeksi schema dengan PRAGMA tersebut.

### Pembayaran
- Nominal pembayaran dihitung dari harga kostum × hari rental bila kolom total/subtotal lama tidak tersedia.
- `payments.amount` selalu diisi sebelum INSERT.
- Bukti pembayaran kompatibel dengan `proof_url` maupun `proof_image`.
- Approval pembayaran mengubah status order jika kolom status tersedia.

### Kalender / availability
- Tidak bergantung pada customer memilih ukuran.
- Jika tidak ada `costume_sizes`, availability dihitung dari level kostum + rental yang bentrok.
- Stok kostum digunakan bila kolom `stock` memang tersedia.
- Query kalender mengambil range booking/maintenance sekaligus, bukan satu query per hari.

### Admin
- Detail pesanan sekarang benar-benar dapat diedit: tanggal, penerima, HP, alamat, catatan, status, denda.
- Pengiriman tidak gagal hanya karena tabel `shipping` tidak tersedia.
- Daftar pembayaran tidak mengasumsikan kolom baru.
- Review dan maintenance tidak membuat D1 error jika tabel/kolom belum ada.
- KTP tidak lagi menjadi bagian checkout customer; endpoint lama tetap dibuat aman untuk data lama.

### Biteship
- Ditambahkan endpoint server-side `POST /api/shipping/rates`.
- API key dibaca dari Cloudflare secret/settings server-side dan tidak dikirim ke browser.
- Endpoint Biteship yang digunakan: `/v1/rates/couriers`.

### Diagnostik
- `GET /api/health` mengembalikan daftar tabel dan kolom yang terdeteksi tanpa membocorkan API key.

## Deploy

Gunakan ZIP ini untuk menggantikan build sebelumnya. Tidak perlu menjalankan `migrate.sql`.

Setelah deploy, hard refresh (`Ctrl + Shift + R`) lalu uji:
1. Katalog
2. Tambah/edit costume
3. Checkout
4. Edit detail sebelum bayar
5. Pembayaran + upload bukti
6. Admin approve/reject pembayaran
7. Admin edit order + ongkir + status
8. Kalender availability
9. Customer order detail
10. Agent COSRENT AI
