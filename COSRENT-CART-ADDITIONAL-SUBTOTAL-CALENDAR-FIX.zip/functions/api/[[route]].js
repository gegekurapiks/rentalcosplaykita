const COOKIE = "cr_session";
const json = (data, status = 200, extra = {}) =>
  new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store, no-cache, must-revalidate", "pragma": "no-cache", ...extra } });
const fail = (m, s = 400) => json({ error: m }, s);

const cookieGet = (req, name) => {
  const c = req.headers.get("Cookie") || "";
  const m = c.match(new RegExp("(?:^|;\\s*)" + name + "=([^;]*)"));
  return m ? decodeURIComponent(m[1]) : null;
};
const cookieSet = (token, maxAge) => ({ "Set-Cookie": `${COOKIE}=${token}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${maxAge}` });
const cookieClear = () => ({ "Set-Cookie": `${COOKIE}=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0` });

async function hashPassword(password, salt) {
  salt = salt || crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" }, key, 256);
  const hex = (b) => [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
  return `pbkdf2$${hex(salt)}$${hex(bits)}`;
}
async function verifyPassword(stored, password) {
  if (stored.startsWith("plain$")) return { ok: stored.slice(6) === password, plain: true };
  try {
    const [, saltHex] = stored.split("$");
    const salt = Uint8Array.from(saltHex.match(/.{2}/g).map((h) => parseInt(h, 16)));
    return { ok: (await hashPassword(password, salt)) === stored, plain: false };
  } catch { return { ok: false, plain: false }; }
}
const sha256hex = async (t) => {
  const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(t));
  return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
};

const daysBetween = (a, b) => Math.max(1, Math.round((new Date(b) - new Date(a)) / 864e5) + 1);
const rentalPackages3 = (days) => Math.max(1, Math.ceil(Math.max(1, Number(days || 1)) / 3));
const parseAddons = (v) => {
  const money = (x) => {
    if (typeof x === "number") return Number.isFinite(x) ? Math.max(0, Math.round(x)) : 0;
    let s = String(x ?? "").trim().replace(/[^0-9,.-]/g, "");
    if (!s) return 0;
    if (s.includes(".") && s.includes(",")) {
      s = s.lastIndexOf(",") > s.lastIndexOf(".") ? s.replace(/\\./g, "").replace(",", ".") : s.replace(/,/g, "");
    } else if (s.includes(".") && s.split(".").slice(1).every(p => /^\\d{3}$/.test(p))) {
      s = s.replace(/\\./g, "");
    } else if (s.includes(",") && s.split(",").slice(1).every(p => /^\\d{3}$/.test(p))) {
      s = s.replace(/,/g, "");
    } else {
      s = s.replace(",", ".");
    }
    const n = Number(s);
    return Number.isFinite(n) ? Math.max(0, Math.round(n)) : 0;
  };
  try {
    const x = typeof v === "string" ? JSON.parse(v) : v;
    return Array.isArray(x) ? x.map(a => {
      if (typeof a === "string") {
        const [name, price] = a.split("|");
        return {name:String(name || "").trim(), price:money(price)};
      }
      return {name:String(a?.name||a?.label||"").trim(), price:money(a?.price)};
    }).filter(a=>a.name) : [];
  } catch { return []; }
};
const validImg = (s) => typeof s === "string" && s.startsWith("data:image") && s.length < 3500000;
const validUrl = (s) => typeof s === "string" && (s.startsWith("http") || s.startsWith("data:image")) && s.length < 3500000;

export async function onRequest({ request, env, params }) {
  const db = env.DB;
  if (!db) return fail("Binding D1 'DB' belum diatur di dashboard.", 500);
  const [a, b, c, d] = params.route || [];
  const method = request.method;
  const body = ["POST", "PUT", "PATCH"].includes(method) ? await request.json().catch(() => ({})) : {};

  /* ---------- helpers ---------- */
  let usersColumnsPromise;
  const ensureUserColumns = async () => {
    if (!usersColumnsPromise) {
      usersColumnsPromise = (async () => {
        const rows = (await db.prepare("PRAGMA table_info(users)").all()).results || [];
        const existing = new Set(rows.map(r => r.name));
        const wanted = {
          phone: "TEXT DEFAULT ''",
          address: "TEXT DEFAULT ''",
          recipient_name: "TEXT DEFAULT ''",
          recipient_phone: "TEXT DEFAULT ''",
          must_change_password: "INTEGER DEFAULT 0"
        };
        for (const [name, definition] of Object.entries(wanted)) {
          if (!existing.has(name)) await db.prepare(`ALTER TABLE users ADD COLUMN ${name} ${definition}`).run();
        }
      })();
    }
    return usersColumnsPromise;
  };
  const getSession = async () => {
    const t = cookieGet(request, COOKIE);
    if (!t) return null;
    await ensureUserColumns();
    return await db.prepare(
      `SELECT s.token, u.id AS user_id, u.role, u.name, u.email, u.phone, u.address,
              u.recipient_name, u.recipient_phone, u.must_change_password
       FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ? AND CAST(s.expires_at AS INTEGER) > ?`
    ).bind(t, Date.now()).first();
  };
  const requireUser = async () => getSession();
  const requireAdmin = async () => {
    const s = await getSession();
    return s && s.role === "admin" ? s : null;
  };
  const getTableColumns = async (table) => {
    const rows = (await db.prepare(`PRAGMA table_info(${table})`).all()).results || [];
    return new Set(rows.map(r => r.name));
  };
  const hasTable = async (table) => !!(await db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").bind(table).first());
  const ensureWaReminderTable = async () => {
    await db.prepare(`CREATE TABLE IF NOT EXISTS wa_reminder_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id TEXT NOT NULL,
      reminder_key TEXT NOT NULL,
      phone TEXT NOT NULL DEFAULT '',
      sent_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(order_id, reminder_key)
    )`).run();
  };
  const ensureKtpTable = async () => {
    await db.prepare(`CREATE TABLE IF NOT EXISTS ktp_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      order_id TEXT,
      order_code TEXT,
      full_name TEXT NOT NULL DEFAULT '',
      nik_masked TEXT NOT NULL DEFAULT '••••••••••••••••',
      image TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )`).run();
    // Production databases may already have ktp_records with an incompatible
    // INTEGER FK for order_id while COSRENT orders use TEXT ids. Keep the
    // legacy column for compatibility and add a safe order_code link.
    const cols = await getTableColumns("ktp_records");
    if (!cols.has("order_code")) {
      try { await db.prepare("ALTER TABLE ktp_records ADD COLUMN order_code TEXT").run(); } catch {}
    }
  };
  const getPaymentMethodsCompat = async ({ activeOnly = false } = {}) => {
    if (await hasTable("payment_methods")) {
      const where = activeOnly ? " WHERE is_active=1" : "";
      return (await db.prepare(`SELECT * FROM payment_methods${where} ORDER BY sort_order,id`).all()).results || [];
    }
    // Older production D1 has no payment_methods table. Keep QRIS in settings
    // so checkout/admin can still work without requiring a schema migration.
    const st = await getSettings();
    const active = String(st.qris_active ?? "1") === "1";
    if (activeOnly && !active) return [];
    return [{
      id: 1, name: st.qris_name || "QRIS", type: "qris",
      account_number: st.qris_account || "", account_name: st.qris_owner || "",
      instructions: st.qris_instruction || "", qr_image: st.qris_image || "",
      is_active: active ? 1 : 0, sort_order: 0
    }];
  };
  const savePaymentMethodCompat = async (id, body) => {
    if (await hasTable("payment_methods")) {
      const clean = { name: body.name || "QRIS", type: body.type || "qris", account_number: body.account_number || "", account_name: body.account_name || "", instructions: body.instructions || "", qr_image: validUrl(body.qr_image) ? body.qr_image : "", is_active: body.is_active ? 1 : 0, sort_order: +body.sort_order || 0 };
      if (id) {
        await db.prepare("UPDATE payment_methods SET name=?, type=?, account_number=?, account_name=?, instructions=?, qr_image=?, is_active=?, sort_order=? WHERE id=?").bind(clean.name, clean.type, clean.account_number, clean.account_name, clean.instructions, clean.qr_image, clean.is_active, clean.sort_order, id).run();
      } else {
        await db.prepare("INSERT INTO payment_methods (name,type,account_number,account_name,instructions,qr_image,is_active,sort_order) VALUES (?,?,?,?,?,?,?,?)").bind(clean.name, clean.type, clean.account_number, clean.account_name, clean.instructions, clean.qr_image, clean.is_active, clean.sort_order).run();
      }
      return;
    }
    await upsertSettings({
      qris_name: body.name || "QRIS", qris_account: body.account_number || "",
      qris_owner: body.account_name || "", qris_instruction: body.instructions || "",
      qris_image: validUrl(body.qr_image) ? body.qr_image : "",
      qris_active: body.is_active ? "1" : "0"
    });
  };
  const createSession = async (userId, role) => {
    const token = crypto.randomUUID() + crypto.randomUUID();
    await db.prepare("INSERT INTO sessions (token,user_id,role,expires_at) VALUES (?,?,?,?)")
      .bind(token, userId, role, Date.now() + 30 * 864e5).run();
    return token;
  };
  const SECRET_SETTING_KEYS = new Set(["biteship_api_key", "berdu_api_key", "ai_api_key"]);
  const secretKeyBytes = async () => {
    const raw = String(env.SETTINGS_ENCRYPTION_KEY || "");
    if (!raw) return null;
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw));
    return crypto.subtle.importKey("raw", digest, "AES-GCM", false, ["encrypt", "decrypt"]);
  };
  const b64 = (bytes) => {
    let s = ""; for (const b of new Uint8Array(bytes)) s += String.fromCharCode(b);
    return btoa(s);
  };
  const fromB64 = (s) => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  const encryptSecret = async (value) => {
    const key = await secretKeyBytes();
    if (!key) throw new Error("SETTINGS_ENCRYPTION_KEY belum dikonfigurasi");
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const data = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(String(value)));
    return `enc:v1:${b64(iv)}:${b64(data)}`;
  };
  const decryptSecret = async (value) => {
    if (!String(value || "").startsWith("enc:v1:")) return value || "";
    const key = await secretKeyBytes();
    if (!key) return "";
    const [, , iv64, data64] = String(value).split(":");
    try {
      const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromB64(iv64) }, key, fromB64(data64));
      return new TextDecoder().decode(plain);
    } catch { return ""; }
  };
  const getSettings = async ({ decrypt = false } = {}) => {
    await db.prepare("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT '')").run();
    const { results } = await db.prepare("SELECT key, value FROM settings").all();
    const out = Object.fromEntries(results.map((r) => [r.key, r.value]));
    if (!String(out.categories || "").trim()) out.categories = JSON.stringify([{slug:"anime",name:"Anime"},{slug:"game",name:"Game"},{slug:"film",name:"Film"},{slug:"original-character",name:"Original Character"},{slug:"lainnya",name:"Lainnya"}]);
    // Backward-compatible field aliases from older builds.
    if (out.logo_url == null && out.logo != null) out.logo_url = out.logo;
    if (out.favicon_url == null && out.favicon != null) out.favicon_url = out.favicon;
    if (decrypt) for (const k of SECRET_SETTING_KEYS) if (out[k]) out[k] = await decryptSecret(out[k]);
    // Safe defaults for features that were introduced after the original settings migration.
    // Existing explicit values are preserved.
    if (out.ai_enabled == null || out.ai_enabled === "") out.ai_enabled = "1";
    if (out.customer_ai_enabled == null || out.customer_ai_enabled === "") out.customer_ai_enabled = "1";
    if (out.ai_provider == null || out.ai_provider === "") out.ai_provider = "mistral";
    if (out.ai_model == null || out.ai_model === "") out.ai_model = "ministral-3b-latest";
    if (out.ai_provider === "groq" && (!out.ai_model || String(out.ai_model).includes("gemini") || String(out.ai_model).startsWith("@cf/"))) out.ai_model = "ministral-3b-latest";
    if (out.ai_temperature == null || out.ai_temperature === "") out.ai_temperature = "0.3";
    if (out.ai_max_tokens == null || out.ai_max_tokens === "") out.ai_max_tokens = "700";
    if (out.ai_system_prompt == null || out.ai_system_prompt === "") out.ai_system_prompt = "Kamu adalah Agent COSRENT. Jawab singkat, jelas, ramah, dan hanya berdasarkan data COSRENT yang diberikan.";
    if (out.ai_customer_prompt == null || out.ai_customer_prompt === "") out.ai_customer_prompt = "Bantu customer mencari kostum, memahami harga, ukuran, aturan, dan proses rental. Jangan mengarang data.";
    if (decrypt) {
      if (env.BITESHIP_API_KEY) out.biteship_api_key = env.BITESHIP_API_KEY;
      if (env.BERDU_API_KEY) out.berdu_api_key = env.BERDU_API_KEY;
      if (env.AI_API_KEY) out.ai_api_key = env.AI_API_KEY;
    }
    return out;
  };
  const upsertSettings = async (obj) => {
    const entries = [];
    for (const [k, v] of Object.entries(obj)) {
      if (SECRET_SETTING_KEYS.has(k) && v !== "" && !String(v).startsWith("••••")) {
        entries.push([k, await encryptSecret(v)]);
      } else if (!SECRET_SETTING_KEYS.has(k)) entries.push([k, String(v ?? "")]);
    }
    if (!entries.length) return;
    const st = db.prepare("INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
    await db.batch(entries.map(([k, v]) => st.bind(k, v)));
  };
  const sizeAvailability = async (costumeId, start, end) => {
    // Production D1 has multiple schema generations. Availability must NOT
    // depend on costume_sizes existing, because checkout no longer asks the
    // customer to choose a size. If size rows exist, use them; otherwise fall
    // back to costume-level availability and overlapping orders.
    let sizeInfo = [];
    try { sizeInfo = (await db.prepare("PRAGMA table_info(costume_sizes)").all()).results || []; } catch {}
    const sizeCols = new Set(sizeInfo.map((x) => x.name));

    let bookedTotal = 0;
    try {
      const oiInfo = (await db.prepare("PRAGMA table_info(order_items)").all()).results || [];
      const oInfo = (await db.prepare("PRAGMA table_info(orders)").all()).results || [];
      const oiCols = new Set(oiInfo.map(x => x.name));
      const oCols = new Set(oInfo.map(x => x.name));
      // Unpaid/pending orders do NOT reserve dates. A date becomes blocked only
      // after payment proof is submitted (payment_review) or payment is approved.
      let active = "";
      if (oCols.has("status")) {
        // IMPORTANT: an unpaid order must NEVER reserve a rental date.
        // Payment-review is still unpaid, so only paid/active statuses block.
        active = " AND o.status IN ('paid','confirmed','preparing','shipped','rented','inspection','returned')";
      } else if (await hasTable("payments")) {
        const pCols = await getTableColumns("payments");
        if (pCols.has("order_id") && pCols.has("status")) {
          active = " AND EXISTS (SELECT 1 FROM payments p WHERE p.order_id=o.id AND p.status='approved')";
        } else {
          // Legacy payments without status cannot prove payment, therefore
          // they must not reserve dates automatically.
          active = " AND 1=0";
        }
      } else {
        active = " AND 1=0";
      }
      if (oiCols.has("costume_id") && oiCols.has("quantity") && oCols.has("id") && oCols.has("ship_date") && oCols.has("return_date")) {
        const r = await db.prepare(`SELECT COALESCE(SUM(oi.quantity),0) n FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.costume_id=?${active} AND o.ship_date<=? AND o.return_date>=?`).bind(costumeId, end, start).first();
        bookedTotal = Number(r?.n || 0);
      } else if (oCols.has("costume_id") && oCols.has("start_date") && oCols.has("end_date")) {
        const r = await db.prepare(`SELECT COUNT(*) n FROM orders o WHERE o.costume_id=?${active} AND o.start_date<=? AND o.end_date>=?`).bind(costumeId, end, start).first();
        bookedTotal = Number(r?.n || 0);
      }
    } catch {}

    // If explicit size rows exist, keep returning them for compatibility with
    // admin/AI, but stock is optional in the old schema.
    if (sizeCols.has("size") && sizeCols.has("costume_id")) {
      try {
        const sizeSql = sizeCols.has("stock")
          ? "SELECT size, stock FROM costume_sizes WHERE costume_id=? ORDER BY id"
          : "SELECT size, 1 AS stock FROM costume_sizes WHERE costume_id=? ORDER BY id";
        const sizes = (await db.prepare(sizeSql).bind(costumeId).all()).results || [];
        if (sizes.length) {
          let maintenance = false;
          try {
            const mt = await db.prepare("SELECT COUNT(*) n FROM maintenance WHERE costume_id=? AND start_date<=? AND end_date>=?").bind(costumeId, end, start).first();
            maintenance = Number(mt?.n || 0) > 0;
          } catch {}
          const totalStock = sizes.reduce((n, s) => n + Math.max(1, Number(s.stock ?? 1)), 0);
          const remaining = Math.max(0, totalStock - bookedTotal);
          return sizes.map((s, i) => ({
            size: s.size, stock: Math.max(1, Number(s.stock ?? 1)), booked: i === 0 ? bookedTotal : 0,
            maintenance, available: maintenance ? 0 : Math.max(0, Math.max(1, Number(s.stock ?? 1)) - (i === 0 ? bookedTotal : 0))
          }));
        }
      } catch {}
    }

    // No size rows: availability is costume-level. This is the normal path
    // after removing size selection from customer checkout.
    let costume = null;
    try { costume = await db.prepare("SELECT * FROM costumes WHERE id=?").bind(costumeId).first(); } catch {}
    const cCols = new Set(Object.keys(costume || {}));
    let maintenance = false;
    try {
      const mt = await db.prepare("SELECT COUNT(*) n FROM maintenance WHERE costume_id=? AND start_date<=? AND end_date>=?").bind(costumeId, end, start).first();
      maintenance = Number(mt?.n || 0) > 0;
    } catch {}
    const hidden = costume && cCols.has("available") && Number(costume.available) === 0;
    const status = costume && cCols.has("status") ? String(costume.status || "") : "";
    const inactive = status && !["published","available","active"].includes(status);
    const stock = Math.max(1, Number(costume?.stock || 1));
    const available = !maintenance && !hidden && !inactive && bookedTotal < stock;
    return [{ size: "all", stock, booked: bookedTotal, maintenance, available: available ? stock - bookedTotal : 0 }];
  };
  const orderColumns = async () => getTableColumns("orders");
  // Ensure customer contact fields exist without resetting or replacing production data.
  // Older COSRENT schemas only had customer_name/start_date/end_date, so contact
  // information had nowhere to persist. These additive columns are safe to create
  // when missing and are used only for new/edited orders.
  const ensureOrderContactColumns = async () => {
    if (!(await hasTable("orders"))) return;
    const defs = {
      recipient_name: "TEXT DEFAULT ''",
      recipient_phone: "TEXT DEFAULT ''",
      ship_address: "TEXT DEFAULT ''",
      note: "TEXT DEFAULT ''",
      ktp_image: "TEXT DEFAULT ''",
      ktp_status: "TEXT DEFAULT 'pending'"
    };
    const cols = await orderColumns();
    for (const [name, def] of Object.entries(defs)) {
      if (!cols.has(name)) {
        try { await db.prepare(`ALTER TABLE orders ADD COLUMN ${name} ${def}`).run(); } catch {}
      }
    }
  };
  const orderBelongsTo = (o, s) => {
    if (!o || !s) return false;
    if (s.role === "admin") return true;
    if (Object.prototype.hasOwnProperty.call(o, "user_id")) return String(o.user_id) === String(s.user_id);
    if (Object.prototype.hasOwnProperty.call(o, "customer_name")) return String(o.customer_name || "").trim().toLowerCase() === String(s.name || "").trim().toLowerCase();
    return false;
  };
  const insertOrderCompat = async ({ code, session, items, ship_date, return_date, ship_address, recipient_name, recipient_phone, subtotal, note }) => {
    const cols = await orderColumns();
    const first = items[0] || {};
    const values = {
      order_code: code,
      user_id: session.user_id,
      costume_id: first.costume_id,
      customer_name: recipient_name || session.name || "Customer",
      size: first.size || "AUTO",
      start_date: ship_date,
      end_date: return_date,
      payment_method: "qris",
      status: "pending_payment",
      payment_status: "unpaid",
      ship_date,
      event_date: ship_date,
      return_date,
      ship_address: String(ship_address || ""),
      recipient_name: String(recipient_name || ""),
      recipient_phone: String(recipient_phone || ""),
      subtotal: Number(subtotal || 0),
      shipping_cost: 0,
      fine_amount: 0,
      fine_note: "",
      total: Number(subtotal || 0),
      note: String(note || "")
    };
    const insertCols = Object.keys(values).filter(k => cols.has(k));
    if (!insertCols.length) throw new Error("Schema tabel orders tidak memiliki kolom yang dapat digunakan");
    const sql = `INSERT INTO orders (${insertCols.join(",")}) VALUES (${insertCols.map(() => "?").join(",")})`;
    return db.prepare(sql).bind(...insertCols.map(k => values[k])).run();
  };

  const parseMoney = (v) => {
    if (v == null || v === "") return 0;
    if (typeof v === "number") {
      return Number.isFinite(v) ? Math.max(0, Math.round(v)) : 0;
    }

    let raw = String(v).trim().replace(/[^0-9,.-]/g, "");
    if (!raw) return 0;

    if (raw.includes(".") && raw.includes(",")) {
      if (raw.lastIndexOf(",") > raw.lastIndexOf(".")) {
        raw = raw.replace(/\./g, "").replace(",", ".");
      } else {
        raw = raw.replace(/,/g, "");
      }
    } else if (raw.includes(".")) {
      const parts = raw.split(".");
      if (parts.length > 1 && parts.slice(1).every(part => /^\d{3}$/.test(part))) {
        raw = parts.join("");
      }
    } else if (raw.includes(",")) {
      const parts = raw.split(",");
      if (parts.length > 1 && parts.slice(1).every(part => /^\d{3}$/.test(part))) {
        raw = parts.join("");
      } else {
        raw = raw.replace(",", ".");
      }
    }

    const n = Number(raw);
    return Number.isFinite(n) ? Math.max(0, Math.round(n)) : 0;
  };

  const recalcTotal = async (orderId) => {
    const cols = await orderColumns();
    const o = await db.prepare("SELECT * FROM orders WHERE id=?").bind(orderId).first();
    if (!o) return { subtotal: 0, shipping: 0, fine: 0, total: 0 };

    // Always rebuild the rental subtotal from the saved order_items. The old
    // implementation trusted orders.subtotal when it was already populated,
    // which made payment pages show a stale/zero subtotal after cart changes.
    let subtotal = 0;
    if (await hasTable("order_items")) {
      const rows = (await db.prepare("SELECT * FROM order_items WHERE order_id=?").bind(orderId).all()).results || [];
      for (const item of rows) {
        const days = Math.max(1, Number(item.days || 1));
        const packages = Math.max(1, rentalPackages3(days));
        const qty = Math.max(1, Number(item.quantity || 1));
        const addonTotal = parseAddons(item.addons).reduce((n, a) => n + Number(a.price || 0), 0);
        subtotal += (Number(item.price_per_day || 0) * packages * qty) + addonTotal;
      }
    }

    if (subtotal <= 0) {
      const baseOrder = { ...o, total: 0, shipping_cost: 0, shipping: 0, fine_amount: 0, late_fee: 0 };
      subtotal = await computeOrderAmount(baseOrder);
    }

    const shipping = cols.has("shipping_cost") ? Number(o.shipping_cost || 0) : Number(o.shipping || 0);
    const fine = cols.has("fine_amount") ? Number(o.fine_amount || 0) : Number(o.late_fee || 0);
    const total = Math.max(0, Math.round(subtotal + shipping + fine));
    const updates = [];
    if (cols.has("subtotal")) updates.push(["subtotal", Math.round(subtotal)]);
    if (cols.has("total")) updates.push(["total", total]);
    if (updates.length) {
      await db.prepare(`UPDATE orders SET ${updates.map(([k]) => `${k}=?`).join(", ")} WHERE id=?`)
        .bind(...updates.map(([,v]) => v), orderId).run();
    }
    return { subtotal: Math.round(subtotal), shipping, fine, total };
  };
  const canonicalStatus = (raw) => {
    const v = String(raw || "").toLowerCase();
    if (["pending", "waiting_payment", "unpaid", "waiting", "pending_payment"].includes(v)) return "pending_payment";
    if (["payment_review", "review_payment", "verifying_payment"].includes(v)) return "payment_review";
    if (v === "confirmed") return "paid";
    return v || "pending_payment";
  };
  const isUnpaidOrder = (o, summary) => !!o && !["cancelled", "completed"].includes(canonicalStatus(o.status)) && (!summary || summary.status !== "paid");
  const updateExisting = async (table, idCol, id, values) => {
    if (!(await hasTable(table))) return false;
    const cols = await getTableColumns(table);
    const pairs = Object.entries(values).filter(([k,v]) => cols.has(k) && v !== undefined);
    if (!pairs.length) return false;
    await db.prepare(`UPDATE ${table} SET ${pairs.map(([k]) => `${k}=?`).join(", ")} WHERE ${idCol}=?`).bind(...pairs.map(([,v])=>v), id).run();
    return true;
  };
  const orderStatusForStorage = (desired, current) => {
    const d=String(desired||""), cur=String(current||"");
    if (d === "pending_payment" && ["pending","waiting_payment","unpaid","waiting"].includes(cur)) return cur;
    return d;
  };
  const paymentSummary = async (orderId) => {
    if (!(await hasTable("payments"))) return { status: "unpaid", approved: 0, pending: 0, rejected: 0, refund: 0 };
    const pc = await getTableColumns("payments");
    if (!pc.has("order_id") || !pc.has("amount")) return { status: "unpaid", approved: 0, pending: 0, rejected: 0, refund: 0 };
    const statusExpr = pc.has("status") ? "status" : "'pending' AS status";
    const rows = (await db.prepare(`SELECT ${statusExpr}, COALESCE(SUM(amount),0) amount FROM payments WHERE order_id=? GROUP BY ${pc.has("status") ? "status" : "order_id"}`).bind(orderId).all()).results || [];
    const approved = Number(rows.find((r) => r.status === "approved")?.amount || 0);
    const pending = Number(rows.find((r) => r.status === "pending")?.amount || 0);
    const rejected = Number(rows.find((r) => r.status === "rejected")?.amount || 0);
    const order = await db.prepare("SELECT * FROM orders WHERE id=?").bind(orderId).first();
    const total = await computeOrderAmount(order);
    const status = approved >= total && total > 0 ? "paid" : approved > 0 ? "partial" : pending > 0 ? "pending" : "unpaid";
    return { status, approved, pending, rejected, refund: 0, total };
  };

  // Legacy production orders may only have start_date/end_date and no subtotal/total.
  // Always derive a real rental amount from the order item/costume when those fields are absent.
  const computeOrderAmount = async (o) => {
    if (!o) return 0;
    const explicit = Number(o.total);
    if (Number.isFinite(explicit) && explicit > 0) return explicit;
    const start = o.ship_date || o.start_date;
    const end = o.return_date || o.end_date;
    const days = start && end ? daysBetween(start, end) : 1;
    let amount = 0;
    if (await hasTable("order_items")) {
      const rows = (await db.prepare("SELECT * FROM order_items WHERE order_id=?").bind(o.id).all()).results || [];
      for (const item of rows) amount += Number(item.price_per_day || 0) * rentalPackages3(item.days || days) * Math.max(1, Number(item.quantity || 1)) + parseAddons(item.addons).reduce((n,a)=>n+a.price,0);
    }
    if (amount <= 0 && o.costume_id != null && await hasTable("costumes")) {
      const c = await db.prepare("SELECT * FROM costumes WHERE id=?").bind(o.costume_id).first();
      amount = Number(c?.price_per_day || c?.price || c?.rental_price || 0) * rentalPackages3(days) * Math.max(1, Number(o.quantity || 1));
      amount += parseAddons(o.addons).reduce((n,a)=>n+a.price,0);
    }
    if (amount <= 0) amount = Number(o.subtotal || 0) + Number(o.shipping_cost || o.shipping || 0) + Number(o.fine_amount || o.late_fee || 0);
    return Math.max(0, Math.round(amount));
  };
  const orderFull = async (code) => {
    // Do not require the legacy database to already contain contact columns.
    await ensureOrderContactColumns();
    const cols = await orderColumns();
    let o;
    if (cols.has("user_id") && await hasTable("users")) {
      o = await db.prepare(
        `SELECT o.*, u.name AS user_name, u.email AS user_email, u.phone AS user_phone
         FROM orders o LEFT JOIN users u ON u.id = o.user_id WHERE o.order_code = ?`).bind(code).first();
    } else {
      o = await db.prepare("SELECT * FROM orders WHERE order_code=?").bind(code).first();
      if (o) {
        o.user_name = o.customer_name || "";
        o.user_email = "";
        o.user_phone = o.recipient_phone || "";
      }
    }
    if (!o) return null;
    // Legacy orders may not have recipient/contact columns and may not have user_id.
    // Recover customer profile data when possible so Admin Detail is not blank.
    if (!o.recipient_name) o.recipient_name = o.customer_name || o.user_name || "";
    if (!o.recipient_phone) o.recipient_phone = o.customer_phone || "";
    if (!o.ship_address) o.ship_address = o.shipping_address || o.address || "";
    if (await hasTable("users")) {
      try {
        // Legacy-safe profile lookup: never assume phone/address columns exist.
        const ucols = await getTableColumns("users");
        let u = null;
        if (cols.has("user_id") && o.user_id && ucols.has("id")) {
          u = await db.prepare("SELECT * FROM users WHERE id=?").bind(o.user_id).first();
        }
        if (!u && ucols.has("name")) {
          const names = [o.customer_name, o.recipient_name, o.user_name].filter(Boolean);
          for (const name of names) {
            u = await db.prepare("SELECT * FROM users WHERE LOWER(name)=LOWER(?) ORDER BY id DESC LIMIT 1").bind(name).first();
            if (u) break;
          }
        }
        if (u) {
          const phone = u.phone || u.recipient_phone || u.phone_number || u.mobile || "";
          const address = u.address || u.shipping_address || u.ship_address || "";
          o.user_name = o.user_name || u.name || o.customer_name || "";
          o.user_email = o.user_email || u.email || "";
          o.user_phone = o.user_phone || phone;
          o.recipient_phone = o.recipient_phone || phone;
          o.ship_address = o.ship_address || address;
          o.recipient_name = o.recipient_name || u.recipient_name || u.name || "";

          // Backfill legacy orders from the customer profile when possible.
          // This makes old orders stop appearing blank after the first detail view.
          await updateExisting("orders", "id", o.id, {
            recipient_name: o.recipient_name,
            recipient_phone: o.recipient_phone,
            ship_address: o.ship_address,
            shipping_address: o.ship_address
          });
        }
      } catch {}
    }
    o.user_phone = o.user_phone || o.recipient_phone || o.customer_phone || "";
    o.status = canonicalStatus(o.status);
    o.ship_date = o.ship_date || o.start_date || "";
    o.return_date = o.return_date || o.end_date || "";
    if (await hasTable("order_items")) o.items = (await db.prepare("SELECT * FROM order_items WHERE order_id=?").bind(o.id).all()).results;
    else o.items = [];
    // Normalize legacy date/price fields so the payment page never shows blank/zero
    // merely because production uses start_date/end_date instead of ship_date/return_date.
    if (!o.items.length && o.costume_id != null && await hasTable("costumes")) {
      const cst = await db.prepare("SELECT * FROM costumes WHERE id=?").bind(o.costume_id).first();
      if (cst) {
        const days = o.ship_date && o.return_date ? daysBetween(o.ship_date, o.return_date) : 1;
        const price = Number(cst.price_per_day || cst.price || cst.rental_price || 0);
        o.items = [{ costume_id: o.costume_id, costume_name: cst.name || cst.character_name || "Kostum", size: o.size || "AUTO", price_per_day: price, days, quantity: 1 }];
      }
    }
    const computedBase = await computeOrderAmount({ ...o, total: 0 });
    const shippingValue = Number(o.shipping_cost || o.shipping || 0);
    const fineValue = Number(o.fine_amount || o.late_fee || 0);
    const computedSubtotal = Math.max(0, computedBase - shippingValue - fineValue);
    if (computedSubtotal > 0) o.subtotal = computedSubtotal;
    if (!(Number(o.shipping_cost) >= 0)) o.shipping_cost = Number(o.shipping || 0);
    if (!(Number(o.fine_amount) >= 0)) o.fine_amount = Number(o.late_fee || 0);
    o.total = Math.max(0, Math.round((Number(o.subtotal) || 0) + Number(o.shipping_cost || 0) + Number(o.fine_amount || 0)));
    if (await hasTable("payments")) {
      const pc = await getTableColumns("payments");
      if (pc.has("method_id") && await hasTable("payment_methods")) {
        o.payments = (await db.prepare(`SELECT p.*, m.name AS method_name${pc.has("proof_image") ? "" : pc.has("proof_url") ? ", p.proof_url AS proof_image" : ", '' AS proof_image"} FROM payments p LEFT JOIN payment_methods m ON m.id=p.method_id WHERE p.order_id=? ORDER BY p.id DESC`).bind(o.id).all()).results;
      } else {
        const methodExpr = pc.has("method") ? "p.method AS method_name" : "'QRIS' AS method_name";
        const proofExpr = pc.has("proof_image") ? "p.proof_image" : pc.has("proof_url") ? "p.proof_url AS proof_image" : "'' AS proof_image";
        o.payments = (await db.prepare(`SELECT p.*, ${methodExpr}, ${proofExpr} FROM payments p WHERE p.order_id=? ORDER BY p.id DESC`).bind(o.id).all()).results;
      }
    } else o.payments = [];
    o.payment_summary = await paymentSummary(o.id);
    o.shipping = await hasTable("shipping") ? await db.prepare("SELECT * FROM shipping WHERE order_id=?").bind(o.id).first() : null;
    if (!o.shipping) {
      const oc = await orderColumns();
      const tn = oc.has("tracking_number") ? o.tracking_number : "";
      const courier = oc.has("courier") ? o.courier : "";
      const service = oc.has("shipping_service") ? o.shipping_service : (oc.has("service") ? o.service : "");
      if (tn || courier || service) o.shipping = { tracking_number: tn || "", courier: courier || "", service: service || "", cost: Number(o.shipping_cost || o.shipping || 0) };
    }
    if (await hasTable("reviews")) {
      const rc = await getTableColumns("reviews");
      const reviewCols = ["id","rating","text"].filter(x => rc.has(x));
      if (rc.has("status")) reviewCols.push("status");
      o.review = reviewCols.length ? await db.prepare(`SELECT ${reviewCols.join(",")} FROM reviews WHERE order_id=?`).bind(o.id).first() || null : null;
    } else o.review = null;
    if (await hasTable("ktp_records")) {
      const kc = await getTableColumns("ktp_records");
      const cols = ["id","nik_masked","full_name","status","created_at"].filter(x=>kc.has(x));
      if (cols.length) {
        let ktp = null;
        try { ktp = await db.prepare(`SELECT ${cols.join(",")} FROM ktp_records WHERE order_id=? ORDER BY id DESC LIMIT 1`).bind(o.id).first() || null; } catch {}
        if (!ktp && kc.has("order_code") && o.order_code) {
          ktp = await db.prepare(`SELECT ${cols.join(",")} FROM ktp_records WHERE order_code=? ORDER BY id DESC LIMIT 1`).bind(o.order_code).first() || null;
        }
        o.ktp = ktp;
      } else o.ktp = null;
    } else o.ktp = null;
    return o;
  };

  try {
    /* ================= PUBLIK ================= */
    if (a === "health" && method === "GET") {
      const tables={}; for(const t of ["users","costumes","costume_sizes","orders","order_items","payments","payment_methods","shipping","reviews","maintenance","settings"]){tables[t]=await hasTable(t)?[...(await getTableColumns(t))]:null;}
      return json({ok:true,tables});
    }

    if (a === "ai-assistant" && method === "POST") {
      // Customer AI limit: 3 successful questions per browser/device per day.
      // A server-issued HttpOnly cookie prevents simple refresh/reset bypasses.
      await db.prepare("CREATE TABLE IF NOT EXISTS ai_usage (device_id TEXT NOT NULL, usage_date TEXT NOT NULL, count INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(device_id, usage_date))").run();
      const today = new Date().toISOString().slice(0,10);
      let deviceId = cookieGet(request, "cr_ai_device");
      let newDeviceCookie = false;
      if (!deviceId || deviceId.length < 20 || deviceId.length > 100) { deviceId = crypto.randomUUID() + crypto.randomUUID(); newDeviceCookie = true; }
      const deviceHash = await sha256hex(deviceId);
      const ip = request.headers.get("CF-Connecting-IP") || request.headers.get("X-Forwarded-For") || "unknown";
      const bucket = await sha256hex(deviceHash + "|" + String(ip).split(",")[0].trim());
      const usage = await db.prepare("SELECT count FROM ai_usage WHERE device_id=? AND usage_date=?").bind(bucket, today).first();
      if (Number(usage?.count || 0) >= 3) {
        const extra = newDeviceCookie ? {"Set-Cookie": `cr_ai_device=${encodeURIComponent(deviceId)}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=31536000`} : {};
        return json({ reply: "Batas COSRENT AI hari ini sudah habis. Kamu bisa bertanya lagi besok ya 💜", limit_reached: true, remaining: 0 }, 429, extra);
      }
      const all = await getSettings({ decrypt: true });
      if (all.ai_enabled === "0" || all.customer_ai_enabled === "0") return json({ reply: "COSRENT AI sedang nonaktif. Aktifkan dari Admin → Settings → AI Customer." });

      // Read the actual production schema first. The original D1 schema uses
      // character_name/anime_name/image_url/status=available; newer builds may
      // use character/series/main_image/status=published. Never assume columns.
      const costumeInfo = (await db.prepare("PRAGMA table_info(costumes)").all()).results || [];
      const cols = new Set(costumeInfo.map(x => x.name));
      const pick = (...names) => names.find(n => cols.has(n));
      const charCol = pick("character", "character_name");
      const seriesCol = pick("series", "anime_name", "anime");
      const imageCol = pick("main_image", "image_url", "image");
      const statusCol = pick("status");
      const fields = ["id", "name", "category", "price_per_day", "description", "package_items", "accessories", "rules_text"].filter(x => cols.has(x));
      if (charCol) fields.push(`${charCol} AS character`);
      if (seriesCol) fields.push(`${seriesCol} AS series`);
      if (imageCol) fields.push(`${imageCol} AS main_image`);
      if (!fields.includes("id")) return json({ reply: "Data katalog COSRENT belum siap dibaca." }, 503);
      let sql = `SELECT ${fields.join(", ")} FROM costumes`;
      if (statusCol) sql += " WHERE status IN ('published','available')";
      sql += " ORDER BY id DESC LIMIT 100";
      const costumes = (await db.prepare(sql).all()).results || [];
      for (const cst of costumes) {
        if (await (async () => !!(await db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='costume_sizes'").first()))()) {
          const sizeCols = new Set(((await db.prepare("PRAGMA table_info(costume_sizes)").all()).results || []).map((x) => x.name));
          const sizeSql = sizeCols.has("stock") ? "SELECT size, stock FROM costume_sizes WHERE costume_id=? ORDER BY id" : "SELECT size, 1 AS stock FROM costume_sizes WHERE costume_id=? ORDER BY id";
          cst.sizes = (await db.prepare(sizeSql).bind(cst.id).all()).results || [];
        }
      }
      const sys = `${all.ai_system_prompt || "Kamu adalah Agent COSRENT."}
${all.ai_customer_prompt || "Bantu customer COSRENT."}
DATA KOSTUM SAAT INI: ${JSON.stringify(costumes)}
PENGATURAN: denda telat Rp${all.fine_per_day || 0}/hari, deposit Rp${all.deposit_amount || 0}.
ATURAN: Jangan mengarang data. Jika informasi tidak ada, katakan belum tersedia. Balas HANYA satu JSON: {"reply":"...","open_costume_id":null atau id kostum}.`;
      let text = "";
      const provider = String(all.ai_provider || "mistral").toLowerCase();
      if (provider !== "mistral") return json({ reply: "COSRENT AI sekarang menggunakan Mistral. Pilih Provider AI = mistral di Admin → Settings → AI Customer." }, 503);
      if (!all.ai_api_key) return json({ reply: "Mistral belum dikonfigurasi. Isi Mistral API Key di Admin → Settings → AI Customer." }, 503);
      const model = String(all.ai_model || "ministral-3b-latest").trim();
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 25000);
      let r;
      try {
        r = await fetch((all.ai_base_url || "https://api.mistral.ai/v1").replace(/\/$/, "") + "/chat/completions", {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${all.ai_api_key}` },
        body: JSON.stringify({
          model,
          messages: [{ role: "system", content: sys }, { role: "user", content: String(body.message || "") }],
          temperature: Math.max(0, Math.min(1, Number(all.ai_temperature ?? 0.3))),
          max_tokens: Math.max(128, Math.min(2048, Number(all.ai_max_tokens ?? 700)))
        }), signal: controller.signal
        });
      } catch (e) {
        clearTimeout(timeout);
        return json({ reply: e?.name === "AbortError" ? "Mistral terlalu lama merespons. Coba lagi." : `Mistral tidak dapat dihubungi: ${e?.message || "network error"}` }, 502);
      }
      clearTimeout(timeout);
      const j = await r.json().catch(() => ({}));
      if (!r.ok) {
        const msg = j?.error?.message || j?.message || (r.status === 401 ? "Mistral API Key tidak valid atau sudah kedaluwarsa." : r.status === 403 ? "Mistral API Key tidak memiliki akses ke model ini." : r.status === 429 ? "Mistral sedang mencapai batas penggunaan. Coba beberapa saat lagi." : `Mistral gagal merespons (HTTP ${r.status}).`);
        return json({ reply: msg }, r.status === 429 ? 429 : 502);
      }
      text = j?.choices?.[0]?.message?.content || "";
      // Count only successful provider responses.
      await db.prepare("INSERT INTO ai_usage(device_id,usage_date,count) VALUES(?,?,1) ON CONFLICT(device_id,usage_date) DO UPDATE SET count=count+1").bind(bucket, today).run();
      const remaining = Math.max(0, 2 - Number(usage?.count || 0));
      let out = { reply: text || "Maaf, Agent COSRENT belum mendapat jawaban.", open_costume_id: null };
      try { const match = text.match(/\{[\s\S]*\}/); if (match) { const j = JSON.parse(match[0]); out = { reply: j.reply || text, open_costume_id: j.open_costume_id || null }; } } catch {}
      const extra = newDeviceCookie ? {"Set-Cookie": `cr_ai_device=${encodeURIComponent(deviceId)}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=31536000`} : {};
      return json({ ...out, remaining }, 200, extra);
    }


    /* ================= AUTH CUSTOMER ================= */
    if (a === "auth" && method === "POST" && b === "register") {
      const name = String(body.name || "").trim(), email = String(body.email || "").toLowerCase().trim(), password = String(body.password || "");
      if (!name || !email || !password) return fail("Lengkapi nama, email, dan password");
      if (!/^\S+@\S+\.\S+$/.test(email)) return fail("Format email tidak valid");
      if (password.length < 6) return fail("Password minimal 6 karakter");
      if (await db.prepare("SELECT id FROM users WHERE email=?").bind(email).first()) return fail("Email sudah terdaftar", 409);
      const r = await db.prepare("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'customer')")
        .bind(name, email, await hashPassword(password)).run();
      const token = await createSession(r.meta.last_row_id, "customer");
      return json({ user: { id: r.meta.last_row_id, name, email, must_change_password: 0 } }, 200, cookieSet(token, 30 * 86400));
    }
    if (a === "auth" && method === "POST" && b === "login") {
      const email = String(body.email || "").toLowerCase().trim();
      const u = await db.prepare("SELECT * FROM users WHERE email=?").bind(email).first();
      if (!u) return fail("Email atau password salah", 401);
      const v = await verifyPassword(u.password_hash, String(body.password || ""));
      if (!v.ok) return fail("Email atau password salah", 401);
      if (v.plain) await db.prepare("UPDATE users SET password_hash=? WHERE id=?").bind(await hashPassword(String(body.password)), u.id).run();
      const token = await createSession(u.id, u.role);
      return json({ user: { id: u.id, name: u.name, email: u.email, role: u.role, must_change_password: u.must_change_password } },
        200, cookieSet(token, 30 * 86400));
    }
    if (a === "auth" && method === "POST" && b === "logout") {
      const t = cookieGet(request, COOKIE);
      if (t) await db.prepare("DELETE FROM sessions WHERE token=?").bind(t).run();
      return json({ ok: true }, 200, cookieClear());
    }
    if (a === "auth" && b === "me" && method === "GET") {
      const s = await requireUser();
      if (!s) return json({ user: null });
      // Keep the login cookie alive for another 30 days whenever the user is active.
      const refreshed = cookieSet(s.token, 30 * 86400);
      return json({ user: s }, 200, refreshed);
    }
    if (a === "profile" && method === "PUT") {
      const s = await requireUser();
      if (!s) return fail("Belum login", 401);
      await db.prepare("UPDATE users SET name=?, phone=?, address=?, recipient_name=?, recipient_phone=? WHERE id=?")
        .bind(String(body.name || s.name).trim(), String(body.phone || "").trim(), String(body.address || "").trim(),
          String(body.recipient_name || "").trim(), String(body.recipient_phone || "").trim(), s.user_id).run();
      return json({ ok: true });
    }
    if (a === "profile" && b === "password" && method === "POST") {
      const s = await requireUser();
      if (!s) return fail("Belum login", 401);
      const u = await db.prepare("SELECT password_hash FROM users WHERE id=?").bind(s.user_id).first();
      const v = await verifyPassword(u.password_hash, String(body.old_password || ""));
      if (!v.ok) return fail("Password lama salah", 401);
      if (!body.new_password || String(body.new_password).length < 6) return fail("Password baru minimal 6 karakter");
      await db.prepare("UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?")
        .bind(await hashPassword(String(body.new_password)), s.user_id).run();
      return json({ ok: true });
    }

    /* ================= PUBLIC CATALOG ================= */
    if (a === "costumes" && method === "GET" && !b) {
      const cols = new Set(((await db.prepare("PRAGMA table_info(costumes)").all()).results || []).map(x => x.name));
      let sql = "SELECT * FROM costumes WHERE 1=1";
      const args = [];
      if (cols.has("status")) {
        sql += " AND COALESCE(status,'published') IN ('published','available')";
      } else if (cols.has("available")) {
        sql += " AND COALESCE(available,1)=1";
      }
      const u = new URL(request.url);
      const search = String(u.searchParams.get("search") || "").trim();
      const category = String(u.searchParams.get("category") || "").trim();
      const gender = String(u.searchParams.get("gender") || "").trim();
      const maxPrice = Number(u.searchParams.get("max_price") || 0);
      if (search) {
        const fields = ["name","character","character_name","series","anime_name","anime","category"].filter(x => cols.has(x));
        if (fields.length) { sql += " AND (" + fields.map(x => `LOWER(COALESCE(${x},'')) LIKE LOWER(?)`).join(" OR ") + ")"; args.push(...fields.map(() => `%${search}%`)); }
      }
      if (category && cols.has("category")) {
        let categoryName = category;
        try {
          const cats = JSON.parse((await getSettings()).categories || "[]");
          const found = (Array.isArray(cats) ? cats : []).find(c => String(c.slug || "").toLowerCase() === category.toLowerCase() || String(c.name || "").toLowerCase() === category.toLowerCase());
          if (found) categoryName = found.name || found.slug || category;
        } catch {}
        sql += " AND (LOWER(COALESCE(category,''))=LOWER(?) OR LOWER(COALESCE(category,''))=LOWER(?))"; args.push(category, categoryName);
      }
      if (gender && cols.has("gender")) { sql += " AND LOWER(COALESCE(gender,'unisex'))=LOWER(?)"; args.push(gender); }
      if (maxPrice > 0 && cols.has("price_per_day")) { sql += " AND CAST(price_per_day AS REAL) <= ?"; args.push(maxPrice); }
      sql += " ORDER BY id DESC";
      const rows = (await db.prepare(sql).bind(...args).all()).results || [];
      let globalAdditional = [];
      try {
        const st = await getSettings();
        const parsed = JSON.parse(st.global_addons || "[]");
        globalAdditional = Array.isArray(parsed)
          ? parsed.filter(x => x && x.active !== false && String(x.name || "").trim())
              .map(x => ({ id:x.id, name:String(x.name).trim(), price:Math.max(0, parseMoney(x.price)), image:String(x.image || "") }))
          : [];
      } catch {}
      const out = rows.map(r => ({
        ...r,
        character: r.character ?? r.character_name ?? "",
        series: r.series ?? r.anime_name ?? r.anime ?? "",
        main_image: r.main_image ?? r.image_url ?? r.image ?? "",
        category: r.category ?? "lainnya",
        gender: r.gender ?? "unisex",
        status: r.status ?? (r.available === 0 ? "hidden" : "published"),
        price_per_day: Number(r.price_per_day || r.price || r.rental_price || 0),
        additional: globalAdditional
      }));
      return json(out);
    }
    if (a === "costumes" && b && method === "GET" && !c) {
      const row = await db.prepare("SELECT * FROM costumes WHERE id=?").bind(b).first();
      if (!row) return fail("Kostum tidak ditemukan", 404);
      const status = row.status ?? (row.available === 0 ? "hidden" : "published");
      if (!["published","available"].includes(String(status))) return fail("Kostum tidak tersedia",404);
      let sizes = [];
      if (await hasTable("costume_sizes")) sizes = (await db.prepare("SELECT * FROM costume_sizes WHERE costume_id=? ORDER BY id").bind(b).all()).results || [];
      let size_measurements = [];
      if (await hasTable("size_measurements")) {
        const mr = (await db.prepare("SELECT size,field,value_cm FROM size_measurements WHERE costume_id=? ORDER BY id").bind(b).all()).results || [];
        const grouped = new Map(); for (const m of mr) { if (!grouped.has(m.size)) grouped.set(m.size,{size:m.size,measurements:{},note:""}); grouped.get(m.size).measurements[m.field]=m.value_cm; }
        size_measurements = [...grouped.values()];
      }
      let rawAccessories = []; try { rawAccessories = JSON.parse(row.accessories || "[]"); } catch {}
      let globalAdditional = [];
      try { const st = await getSettings(); const parsed = JSON.parse(st.global_addons || "[]"); globalAdditional = Array.isArray(parsed) ? parsed.filter(x => x && x.active !== false && String(x.name || "").trim()).map(x => ({ id:x.id, name:String(x.name).trim(), price:Math.max(0, parseMoney(x.price)), image:String(x.image || "") })) : []; } catch {}
      const additional = globalAdditional.length ? globalAdditional : rawAccessories.map(x => {
        if (x && typeof x === "object") return { name:String(x.name || x.label || "").trim(), price:Math.max(0, Number(x.price || 0) || 0) };
        if (typeof x === "string" && x.includes("|")) { const [name, price] = x.split("|"); return { name:String(name || "").trim(), price:Math.max(0, parseMoney(price)) }; }
        return null;
      }).filter(x => x && x.name);
      return json({
        ...row,
        character: row.character ?? row.character_name ?? "",
        series: row.series ?? row.anime_name ?? row.anime ?? "",
        main_image: row.main_image ?? row.image_url ?? row.image ?? "",
        category: row.category ?? "lainnya",
        gender: row.gender ?? "unisex",
        price_per_day: Number(row.price_per_day || row.price || row.rental_price || 0),
        sizes, size_measurements, additional,
        accessories: rawAccessories.filter(x => typeof x === "string" && !x.includes("|"))
      });
    }

    /* ================= PUBLIC AVAILABILITY CALENDAR ================= */
    // Customer detail pages call /api/costumes/:id/availability-dates.
    // Keep this endpoint public: it only exposes which dates are available,
    // never customer/order information.
    if (a === "costumes" && b && c === "availability-dates" && method === "GET") {
      const costume = await db.prepare("SELECT * FROM costumes WHERE id=?").bind(b).first();
      if (!costume) return fail("Kostum tidak ditemukan", 404);
      const status = costume.status ?? (costume.available === 0 ? "hidden" : "published");
      if (!["published", "available", "active"].includes(String(status))) return fail("Kostum tidak tersedia", 404);

      const u = new URL(request.url);
      const rawFrom = String(u.searchParams.get("from") || "").trim();
      const days = Math.min(90, Math.max(1, Number(u.searchParams.get("days") || 60)));
      const today = new Date();
      const isoToday = today.toISOString().slice(0, 10);
      const validDate = /^\d{4}-\d{2}-\d{2}$/.test(rawFrom);
      const from = validDate && rawFrom >= isoToday ? rawFrom : isoToday;

      const start = new Date(`${from}T00:00:00Z`);
      const calendarDays = [];
      const unavailable = [];
      for (let i = 0; i < days; i++) {
        const d = new Date(start.getTime() + i * 86400000);
        const date = d.toISOString().slice(0, 10);
        const av = await sizeAvailability(b, date, date);
        const available = av.some(x => Number(x.available || 0) > 0);
        const label = d.toLocaleDateString("id-ID", { day: "numeric", month: "short" });
        const day = d.toLocaleDateString("id-ID", { weekday: "short" });
        calendarDays.push({ date, day, label, available });
        if (!available) unavailable.push(date);
      }
      return json({ ok: true, costume_id: b, from, days: calendarDays, unavailable });
    }

    /* ================= ORDER CUSTOMER ================= */
    if (a === "orders" && method === "POST" && !b) {
      const s = await requireUser();
      if (!s) return fail("Masuk terlebih dahulu", 401);
      const { items, ship_date, return_date, ship_address, recipient_name, recipient_phone, note, ktp_image } = body;
      if (!Array.isArray(items) || !items.length) return fail("Tidak ada item");
      if (!ship_date || !return_date) return fail("Lengkapi tanggal rental");
      if (return_date < ship_date) return fail("Tanggal kembali tidak boleh sebelum tanggal kirim");
      if (!ship_address || !recipient_name || !recipient_phone) return fail("Lengkapi alamat & data penerima");
      const ktpRequired = String((await getSettings()).ktp_required ?? "1") === "1";
      if (ktpRequired && !validImg(ktp_image)) return fail("Upload foto KTP terlebih dahulu");
      if (ktp_image && !validImg(ktp_image)) return fail("Foto KTP tidak valid");
      await ensureOrderContactColumns();
      // KTP is stored directly on the order to avoid legacy ktp_records foreign-key
      // incompatibilities in production databases. The legacy ktp_records table is
      // intentionally not required for checkout.
      
      let subtotal = 0;
      const itemRows = [];
      for (const it of items) {
        const costumeCols = new Set(((await db.prepare("PRAGMA table_info(costumes)").all()).results || []).map((x) => x.name));
        const cst = await db.prepare("SELECT * FROM costumes WHERE id=?").bind(it.costume_id).first();
        if (!cst) return fail("Kostum tidak tersedia", 404);
        const cstStatus = costumeCols.has("status") ? String(cst.status || "") : (cst.available === 0 ? "hidden" : "published");
        if (!["published", "available"].includes(cstStatus)) return fail("Kostum tidak tersedia", 404);
        const avs = await sizeAvailability(cst.id, ship_date, return_date);
        const pick = avs.find((x) => x.available > 0);
        if (!pick) return fail(`Kostum ${cst.name} tidak tersedia untuk tanggal rental tersebut`, 409);
        const days = daysBetween(ship_date, return_date), packages = rentalPackages3(days), qty = Math.max(1, +it.quantity || 1);
        const addons = parseAddons(it.addons);
        const addonTotal = addons.reduce((n,a)=>n+a.price,0);
        subtotal += (cst.price_per_day * packages * qty) + addonTotal;
        itemRows.push({ costume_id: cst.id, costume_name: cst.name, size: pick.size || "AUTO", price_per_day: cst.price_per_day, days, packages, quantity: qty, addons });
      }
      const code = "CR-" + Math.random().toString(36).slice(2, 8).toUpperCase();
      const r = await insertOrderCompat({ code, session: s, items: itemRows, ship_date, return_date, ship_address, recipient_name, recipient_phone, subtotal, note });
      const savedOrder = await db.prepare("SELECT * FROM orders WHERE order_code=?").bind(code).first();
      const orderId = savedOrder?.id ?? r.meta.last_row_id;
      if (ktp_image && orderId != null) {
        const oc = await orderColumns();
        const pairs = [];
        if (oc.has("ktp_image")) pairs.push(["ktp_image", ktp_image]);
        if (oc.has("ktp_status")) pairs.push(["ktp_status", "pending"]);
        if (pairs.length) {
          await db.prepare(`UPDATE orders SET ${pairs.map(([k]) => `${k}=?`).join(", ")} WHERE id=?`)
            .bind(...pairs.map(([,v]) => v), orderId).run();
        }
      }
      if (orderId == null) throw new Error("Pesanan berhasil dibuat tetapi ID pesanan tidak dapat dibaca kembali.");
      if (await hasTable("order_items")) {
        // Older production D1 schemas may not have the addons column yet.
        // Create it before inserting so a selected Additional can never
        // disappear between checkout and the payment/order page.
        let itemCols = await getTableColumns("order_items");
        if (!itemCols.has("addons")) {
          try { await db.prepare("ALTER TABLE order_items ADD COLUMN addons TEXT DEFAULT '[]'").run(); } catch (e) {
            // If the schema cannot be altered, do not silently lose the
            // selected Additional. Return a clear error instead.
            if (itemRows.some(x => Array.isArray(x.addons) && x.addons.length)) {
              return fail("Additional belum bisa disimpan. Schema database order_items perlu diperbarui.", 500);
            }
          }
          itemCols = await getTableColumns("order_items");
        }
        const allowed = ["order_id","costume_id","costume_name","size","price_per_day","days","quantity","addons"].filter(x => itemCols.has(x));
        for (const x of itemRows) {
          const vals = { order_id: orderId, costume_id: x.costume_id, costume_name: x.costume_name, size: x.size || "AUTO", price_per_day: x.price_per_day, days: x.days, quantity: x.quantity, addons: JSON.stringify(x.addons || []) };
          await db.prepare(`INSERT INTO order_items (${allowed.join(",")}) VALUES (${allowed.map(() => "?").join(",")})`).bind(...allowed.map(k => vals[k])).run();
        }
      }
      // Persist the final subtotal/total from the rows that actually landed in D1.
      // This keeps the payment page, customer order page and admin in sync.
      await recalcTotal(orderId);
      return json({ ok: true, order_code: code }, 201);
    }

    if (a === "my-orders" && method === "GET") {
      const s = await requireUser();
      if (!s) return fail("Belum login", 401);
      const cols = await orderColumns();
      let rows = [];
      if (cols.has("user_id")) rows = (await db.prepare(`SELECT o.*${await hasTable("order_items") ? ", (SELECT GROUP_CONCAT(oi.costume_name || ' (' || oi.size || ')', ', ') FROM order_items oi WHERE oi.order_id=o.id) AS items_label" : ""} FROM orders o WHERE o.user_id=? ORDER BY o.id DESC`).bind(s.user_id).all()).results;
      else rows = (await db.prepare(`SELECT o.*${await hasTable("order_items") ? ", (SELECT GROUP_CONCAT(oi.costume_name || ' (' || oi.size || ')', ', ') FROM order_items oi WHERE oi.order_id=o.id) AS items_label" : ""} FROM orders o WHERE o.customer_name=? ORDER BY o.id DESC`).bind(s.name).all()).results;
      for (const r of rows) {
        r.status=canonicalStatus(r.status);
        r.ship_date=r.ship_date||r.start_date||"";
        r.return_date=r.return_date||r.end_date||"";
        r.total=await computeOrderAmount(r);
        r.payment_summary=await paymentSummary(r.id);
        r.shipping=await hasTable("shipping") ? await db.prepare("SELECT * FROM shipping WHERE order_id=?").bind(r.id).first() : null;
        r.tracking_number=r.shipping?.tracking_number || r.tracking_number || "";
        r.courier=r.shipping?.courier || r.courier || "";
        r.service=r.shipping?.service || r.shipping_service || "";
      }
      return json(rows);
    }

    if (a === "orders" && method === "GET" && b && !c) {
      const s = await requireUser();
      if (!s) return fail("Belum login", 401);
      const o = await orderFull(b);
      if (!o) return fail("Pesanan tidak ditemukan", 404);
      if (s.role !== "admin" && !orderBelongsTo(o, s)) return fail("Tidak diizinkan", 403);
      return json(o);
    }

    if (a === "orders" && b && !c && method === "PUT") {
      const s=await requireUser(); if(!s) return fail("Belum login",401);
      const o=await db.prepare("SELECT * FROM orders WHERE order_code=?").bind(b).first();
      if(!o||!orderBelongsTo(o,s)) return fail("Tidak diizinkan",403);
      const ps=await paymentSummary(o.id); if(!isUnpaidOrder(o,ps)) return fail("Detail pesanan hanya bisa diedit sebelum pembayaran diterima",409);
      if(body.ship_date&&body.return_date&&body.return_date<body.ship_date) return fail("Tanggal kembali tidak boleh sebelum tanggal kirim");
      if(body.ship_date&&body.return_date&&o.costume_id!=null){
        const oc=await orderColumns(); let conflict=null;
        if(await hasTable("order_items")){ const oi=await getTableColumns("order_items"); if(oi.has("costume_id")&&oc.has("ship_date")&&oc.has("return_date")){ const active=oc.has("status")?" AND o.status IN ('paid','confirmed','preparing','shipped','rented','inspection','returned')":""; conflict=await db.prepare(`SELECT o.id FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.costume_id=? AND o.id<>?${active} AND o.ship_date<=? AND o.return_date>=? LIMIT 1`).bind(o.costume_id,o.id,body.return_date,body.ship_date).first(); } }
        if(!conflict&&oc.has("costume_id")&&oc.has("start_date")&&oc.has("end_date")){ const active=oc.has("status")?" AND o.status IN ('paid','confirmed','preparing','shipped','rented','inspection','returned')":""; conflict=await db.prepare(`SELECT id FROM orders o WHERE o.costume_id=? AND o.id<>?${active} AND o.start_date<=? AND o.end_date>=? LIMIT 1`).bind(o.costume_id,o.id,body.return_date,body.ship_date).first(); }
        if(conflict) return fail("Tanggal tersebut sudah tidak tersedia untuk kostum ini",409);
      }
      await updateExisting("orders","id",o.id,{start_date:body.ship_date,ship_date:body.ship_date,end_date:body.return_date,return_date:body.return_date,recipient_name:String(body.recipient_name||""),recipient_phone:String(body.recipient_phone||""),customer_name:String(body.recipient_name||s.name||""),ship_address:String(body.ship_address||""),shipping_address:String(body.ship_address||""),note:String(body.note||"")});
      return json({ok:true,order:await orderFull(b)});
    }

    if (a === "orders" && b && c === "payment-proof" && method === "POST") {
      const s = await requireUser();
      if (!s) return fail("Belum login", 401);
      const o = await db.prepare("SELECT * FROM orders WHERE order_code=?").bind(b).first();
      if (!o || !orderBelongsTo(o, s)) return fail("Tidak diizinkan", 403);
      const ps=await paymentSummary(o.id);
      if (!isUnpaidOrder(o,ps)) return fail("Pesanan ini sudah dibayar atau tidak bisa dibayar lagi");
      if (!validImg(body.proof_image)) return fail("Bukti transfer tidak valid (foto, maks ±2MB)");
      if (!(await hasTable("payments"))) return fail("Fitur pembayaran belum tersedia",503);
      // Uploading proof does NOT reserve the date. The reservation starts only
      // when an admin approves the payment, which re-checks availability.
      const pc = await getTableColumns("payments");
      const methods=await getPaymentMethodsCompat();
      const pm=methods.find(x=>String(x.id)===String(body.method_id))||methods[0]||null;
      const totalAmount=await computeOrderAmount(o);
      const approvedAlready=Number(ps.approved||0);
      const choice=String(body.payment_type||"full").toLowerCase()==="dp" ? "dp" : "full";
      const remaining=Math.max(0,totalAmount-approvedAlready);
      const amount=approvedAlready>0 ? remaining : (choice==="dp" ? Math.ceil(totalAmount*0.5) : totalAmount);
      if(amount<=0) return fail("Tidak ada sisa pembayaran",400);
      const paymentValues={order_id:o.id,method_id:pc.has("method_id")?(+body.method_id||null):undefined,method:pc.has("method")?String(pm?.name||"QRIS"):undefined,amount,status:pc.has("status")?"pending":undefined,proof_image:pc.has("proof_image")?body.proof_image:undefined,proof_url:pc.has("proof_url")?body.proof_image:undefined,note:pc.has("note")?choice:undefined,admin_note:pc.has("admin_note")?choice:undefined,payment_type:pc.has("payment_type")?choice:undefined,type:pc.has("type")?choice:undefined};
      const insertCols=Object.keys(paymentValues).filter(k=>pc.has(k)&&paymentValues[k]!==undefined);
      if(!insertCols.length||!pc.has("amount")) return fail("Schema tabel payments tidak kompatibel: kolom amount wajib tersedia",500);
      await db.prepare(`INSERT INTO payments (${insertCols.join(",")}) VALUES (${insertCols.map(()=>"?").join(",")})`).bind(...insertCols.map(k=>paymentValues[k])).run();
      const oc=await orderColumns();
      if(oc.has("status")) await updateExisting("orders","id",o.id,{status:"payment_review"});
      if(oc.has("payment_status")) await updateExisting("orders","id",o.id,{payment_status:"pending"});
      return json({ok:true,amount},201);
    }

    if (a === "orders" && b && c === "cancel" && method === "POST") {
      const s = await requireUser();
      if (!s) return fail("Belum login", 401);
      const o = await db.prepare("SELECT * FROM orders WHERE order_code=?").bind(b).first();
      if (!o || !orderBelongsTo(o, s)) return fail("Tidak diizinkan", 403);
      const currentStatus = canonicalStatus(o.status);
      const cancellable = ["pending_payment", "payment_review", "paid", "preparing"];
      if (!cancellable.includes(currentStatus)) return fail("Pesanan ini sudah masuk proses pengiriman/sewa dan tidak bisa dibatalkan", 409);
      // PENTING: pembatalan hanya mengubah status jika kolom status memang ada.
      await updateExisting("orders","id",o.id,{status:"cancelled"});
      return json({ ok: true, order_code: o.order_code, status: "cancelled", message: "Pesanan dibatalkan. DP yang sudah dibayar tidak dikembalikan." });
    }

    if (a === "orders" && b && c === "review" && method === "POST") {
      const s = await requireUser();
      if (!s) return fail("Belum login", 401);
      const o = await db.prepare("SELECT * FROM orders WHERE order_code=?").bind(b).first();
      if (!o || !orderBelongsTo(o, s)) return fail("Tidak diizinkan", 403);
      if (o.status !== "completed") return fail("Review bisa diberikan setelah pesanan selesai");
      if (await db.prepare("SELECT id FROM reviews WHERE order_id=?").bind(o.id).first()) return fail("Kamu sudah memberi review");
      const rating = Math.min(5, Math.max(1, +body.rating || 0));
      if (!rating) return fail("Pilih rating 1-5");
      if (!(await hasTable("reviews"))) return fail("Fitur review belum tersedia",503);
      const item = await hasTable("order_items") ? await db.prepare("SELECT costume_id FROM order_items WHERE order_id=? LIMIT 1").bind(o.id).first() : null;
      const costumeId=item?.costume_id ?? o.costume_id;
      const rc=await getTableColumns("reviews");
      const vals={order_id:o.id,user_id:s.user_id,costume_id:costumeId,rating,text:String(body.text||"").slice(0,1000),comment:String(body.text||"").slice(0,1000),photo:validImg(body.photo)?body.photo:"",status:"pending"};
      const cols=Object.keys(vals).filter(k=>rc.has(k));
      await db.prepare(`INSERT INTO reviews (${cols.join(",")}) VALUES (${cols.map(()=>"?").join(",")})`).bind(...cols.map(k=>vals[k])).run();
      return json({ ok: true }, 201);
    }

    /* ================= ADMIN ================= */
    if (a === "admin" && b === "login" && method === "POST") {
      const email = String(body.email || "").toLowerCase().trim();
      const u = await db.prepare("SELECT * FROM users WHERE email=?").bind(email).first();
      if (!u || u.role !== "admin") return fail("Akun admin tidak ditemukan", 401);
      const v = await verifyPassword(u.password_hash, String(body.password || ""));
      if (!v.ok) return fail("Email atau password salah", 401);
      if (v.plain) await db.prepare("UPDATE users SET password_hash=? WHERE id=?").bind(await hashPassword(String(body.password)), u.id).run();
      const token = await createSession(u.id, "admin");
      return json({ ok: true }, 200, cookieSet(token, 7 * 86400));
    }
    if (a === "admin" && b === "logout" && method === "POST") {
      const t = cookieGet(request, COOKIE);
      if (t) await db.prepare("DELETE FROM sessions WHERE token=?").bind(t).run();
      return json({ ok: true }, 200, cookieClear());
    }

    if (a === "admin") {
      const admin = await requireAdmin();
      if (!admin) return fail("Unauthorized", 401);

      if (b === "check") return json({ ok: true });

      if (b === "dashboard" && method === "GET") {
        const orders = (await db.prepare("SELECT * FROM orders").all()).results || [];
        const payments = await hasTable("payments") ? ((await db.prepare("SELECT * FROM payments").all()).results || []) : [];
        const customers = await hasTable("users") ? Number((await db.prepare("SELECT COUNT(*) n FROM users WHERE role='customer'").first())?.n || 0) : 0;
        const revenue = orders.reduce((sum,o) => { const st=canonicalStatus(o.status); if (["pending_payment","payment_review","cancelled"].includes(st)) return sum; return sum + Math.max(0, Number(o.total || o.subtotal || 0)); }, 0);
        const dp_pending=[]; const settlement_pending=[]; const ship_today=[];
        const today = new Date().toISOString().slice(0,10);
        for (const o of orders) {
          if (canonicalStatus(o.status)==="cancelled") continue;
          const total = await computeOrderAmount(o);
          let pays=[]; if (await hasTable("payments")) pays=(await db.prepare("SELECT * FROM payments WHERE order_id=? ORDER BY id ASC").bind(o.id).all()).results||[];
          const approved=pays.filter(x=>String(x.status||"")==="approved").reduce((n,x)=>n+Number(x.amount||0),0);
          const pending=pays.filter(x=>String(x.status||"")==="pending").reduce((n,x)=>n+Number(x.amount||0),0);
          const name=o.customer_name || (o.user_id && await hasTable("users") ? ((await db.prepare("SELECT name FROM users WHERE id=?").bind(o.user_id).first())?.name||"") : "");
          const base={id:o.id,order_code:o.order_code||String(o.id),customer_name:name||"-",total,approved,remaining:Math.max(0,total-approved),status:canonicalStatus(o.status),ship_date:o.ship_date||o.start_date||"",return_date:o.return_date||o.end_date||""};
          if (approved<=0 && pending<=0) dp_pending.push(base);
          else if (approved>0 && approved<total) settlement_pending.push(base);
          if ((base.ship_date===today) && !["cancelled","returned","completed"].includes(base.status)) ship_today.push(base);
        }
        return json({ total_orders:orders.length, revenue, pending_payments:payments.filter(p=>String(p.status||"pending")==="pending").length, active_rentals:orders.filter(o=>new Set(["paid","preparing","shipped","rented","returned","inspection"]).has(canonicalStatus(o.status))).length, costumes:Number((await db.prepare("SELECT COUNT(*) n FROM costumes").first())?.n||0), customers, dp_pending, settlement_pending, ship_today });
      }

      if (b === "orders" && method === "GET" && !c) {
        const q = new URL(request.url).searchParams;
        const search = q.get("search")?.trim(), status = q.get("status")?.trim();
        const oCols = await orderColumns();
        let sql = `SELECT o.*${await hasTable("order_items") ? ", (SELECT GROUP_CONCAT(oi.costume_name || ' (' || oi.size || ')', ', ') FROM order_items oi WHERE oi.order_id=o.id) AS items_label" : ""}`;
        if (oCols.has("user_id") && await hasTable("users")) sql += `, u.name AS user_name, u.email AS user_email FROM orders o LEFT JOIN users u ON u.id=o.user_id WHERE 1=1`;
        else sql += `, o.customer_name AS user_name, '' AS user_email FROM orders o WHERE 1=1`;
        const args = [];
        if (search) {
          if (oCols.has("user_id") && await hasTable("users")) { sql += " AND (o.order_code LIKE ? OR u.name LIKE ? OR u.email LIKE ?)"; args.push(`%${search}%`, `%${search}%`, `%${search}%`); }
          else { sql += " AND (o.order_code LIKE ? OR COALESCE(o.customer_name,'') LIKE ?)"; args.push(`%${search}%`, `%${search}%`); }
        }
        if (status) { sql += " AND o.status=?"; args.push(status); }
        sql += " ORDER BY o.id DESC";
        const rows=(await db.prepare(sql).bind(...args).all()).results || [];
        for(const r of rows){ r.status=canonicalStatus(r.status); r.ship_date=r.ship_date||r.start_date||""; r.return_date=r.return_date||r.end_date||""; r.total=await computeOrderAmount(r); r.shipping=await hasTable("shipping") ? await db.prepare("SELECT * FROM shipping WHERE order_id=?").bind(r.id).first() : null; r.tracking_number=r.shipping?.tracking_number||""; }
        return json(rows);
      }
      if (b === "orders" && c && !d && method === "GET") {
        const o = await db.prepare("SELECT order_code FROM orders WHERE id=?").bind(c).first();
        if (!o) return fail("Tidak ditemukan", 404);
        return json(await orderFull(o.order_code));
      }
      if (b === "orders" && c && d === "cancel" && method === "POST") {
        const o = await db.prepare("SELECT * FROM orders WHERE id=?").bind(c).first();
        if (!o) return fail("Pesanan tidak ditemukan", 404);
        const currentStatus = canonicalStatus(o.status);
        const cancellable = ["pending_payment", "payment_review", "paid", "preparing"];
        if (!cancellable.includes(currentStatus)) return fail("Pesanan ini tidak dapat dibatalkan pada status sekarang", 409);
        await updateExisting("orders","id",c,{status:"cancelled"});
        return json({ ok: true, order_code: o.order_code, status: "cancelled", message: "Pesanan dibatalkan. DP tetap tercatat dan tidak direfund." });
      }
      if (b === "orders" && c === "permanent" && method === "POST") {
        const ids = Array.isArray(body.ids) ? [...new Set(body.ids.map(x => String(x)).filter(Boolean))].slice(0, 200) : [];
        if (!ids.length) return fail("Pilih minimal satu pesanan", 400);
        let deleted = 0;
        for (const id of ids) {
          const o = await db.prepare("SELECT id, order_code FROM orders WHERE id=?").bind(id).first();
          if (!o) continue;
          // Hard-delete is intentionally allowed for old orders of any status.
          // Clean direct order_id children first so old data can be removed safely.
          const del=[];
          for(const t of ["reviews","ktp_records","shipping","payments","order_items","inspections","steps"]) {
            if(await hasTable(t)) {
              const tc=await getTableColumns(t);
              if(tc.has("order_id")) del.push(db.prepare(`DELETE FROM ${t} WHERE order_id=?`).bind(id));
            }
          }
          del.push(db.prepare("DELETE FROM orders WHERE id=?").bind(id));
          await db.batch(del);
          deleted++;
        }
        return json({ ok:true, deleted, requested:ids.length, message:`${deleted} pesanan dihapus permanen.` });
      }
      if (b === "orders" && c && d === "permanent" && method === "DELETE") {
        const o = await db.prepare("SELECT * FROM orders WHERE id=?").bind(c).first();
        if (!o) return fail("Pesanan tidak ditemukan", 404);
        const del=[];
        for(const t of ["reviews","ktp_records","shipping","payments","order_items","inspections","steps"]) if(await hasTable(t)) { const tc=await getTableColumns(t); if(tc.has("order_id")) del.push(db.prepare(`DELETE FROM ${t} WHERE order_id=?`).bind(c)); }
        del.push(db.prepare("DELETE FROM orders WHERE id=?").bind(c));
        await db.batch(del);
        return json({ ok: true, deleted: true, order_code: o.order_code });
      }
      if (b === "orders" && c && !d && method === "PUT") {
        const current = await db.prepare("SELECT * FROM orders WHERE id=?").bind(c).first();
        if (!current) return fail("Pesanan tidak ditemukan", 404);
        if (body.status === "cancelled") return fail("Gunakan tombol Batalkan Pesanan agar pembatalan tercatat dengan benar", 409);
        await updateExisting("orders", "id", c, {
          status: body.status ? orderStatusForStorage(body.status, current.status) : undefined,
          customer_name: body.customer_name, recipient_name: body.recipient_name, recipient_phone: body.recipient_phone,
          ship_address: body.ship_address, shipping_address: body.ship_address, start_date: body.ship_date, ship_date: body.ship_date, end_date: body.return_date, return_date: body.return_date,
          note: body.note, size: body.size, payment_method: body.payment_method, payment_status: body.payment_status,
          fine_amount: body.fine_amount != null ? parseMoney(body.fine_amount) : undefined,
          late_fee: body.fine_amount != null ? parseMoney(body.fine_amount) : undefined,
          fine_note: String(body.fine_note||""),
          subtotal: body.subtotal != null ? parseMoney(body.subtotal) : undefined,
          shipping_cost: body.shipping_cost != null ? parseMoney(body.shipping_cost) : undefined,
          shipping: body.shipping_cost != null ? parseMoney(body.shipping_cost) : undefined
        });
        await recalcTotal(c);
        return json({ ok:true });
      }
      if (b === "orders" && c && d === "shipping" && method === "PUT") {
        const rawCost =
          body.cost ??
          body.shipping_cost ??
          body.ongkir ??
          body.shipping?.cost ??
          0;

        const cost = parseMoney(rawCost);

        const courier = String(
          body.courier ??
          body.shipping?.courier ??
          ""
        ).trim();

        const service = String(
          body.service ??
          body.shipping?.service ??
          ""
        ).trim();

        const tracking = String(
          body.tracking_number ??
          body.shipping?.tracking_number ??
          ""
        ).trim();

        const nextStatus = String(
          body.order_status || "pending"
        ).trim();

        let orderCols = await orderColumns();

        const columnsToEnsure = [
          ["shipping_cost", "INTEGER NOT NULL DEFAULT 0"],
          ["tracking_number", "TEXT DEFAULT ''"],
          ["courier", "TEXT DEFAULT ''"],
          ["shipping_service", "TEXT DEFAULT ''"]
        ];

        for (const [name, definition] of columnsToEnsure) {
          if (!orderCols.has(name)) {
            try {
              await db.prepare(
                `ALTER TABLE orders ADD COLUMN ${name} ${definition}`
              ).run();
            } catch (_) {}
          }
        }

        orderCols = await orderColumns();

        if (await hasTable("shipping")) {
          try {
            const shippingCols = await getTableColumns("shipping");

            const existing = shippingCols.has("order_id")
              ? await db
                  .prepare("SELECT id FROM shipping WHERE order_id=?")
                  .bind(c)
                  .first()
              : null;

            const shippingValues = {
              courier,
              service,
              cost,
              shipping_cost: cost,
              ongkir: cost,
              tracking_number: tracking,
              status: nextStatus,
              shipped_at:
                nextStatus === "shipped"
                  ? new Date().toISOString()
                  : undefined
            };

            if (existing) {
              await updateExisting(
                "shipping",
                "order_id",
                c,
                shippingValues
              );
            } else {
              const pairs = Object.entries({
                order_id: c,
                ...shippingValues
              }).filter(
                ([key, value]) =>
                  shippingCols.has(key) &&
                  value !== undefined
              );

              if (pairs.length) {
                await db.prepare(
                  `INSERT INTO shipping (${pairs.map(([key]) => key).join(",")})
                   VALUES (${pairs.map(() => "?").join(",")})`
                ).bind(
                  ...pairs.map(([, value]) => value)
                ).run();
              }
            }
          } catch (err) {
            console.error(
              "Gagal menyimpan tabel shipping:",
              err
            );
          }
        }

        const orderUpdate = {
          shipping_cost: cost,

          shipping: orderCols.has("shipping")
            ? cost
            : undefined,

          tracking_number:
            orderCols.has("tracking_number")
              ? tracking
              : undefined,

          courier:
            orderCols.has("courier")
              ? courier
              : undefined,

          shipping_service:
            orderCols.has("shipping_service")
              ? service
              : undefined
        };

        if (body.order_status) {
          const current = await db
            .prepare("SELECT status FROM orders WHERE id=?")
            .bind(c)
            .first();

          orderUpdate.status = orderStatusForStorage(
            body.order_status,
            current?.status
          );
        }

        const updated = await updateExisting(
          "orders",
          "id",
          c,
          orderUpdate
        );

        if (!updated) {
          return fail(
            "Data pengiriman gagal disimpan ke pesanan",
            500
          );
        }

        await recalcTotal(c);

        const saved = await db
          .prepare("SELECT * FROM orders WHERE id=?")
          .bind(c)
          .first();

        const savedShipping =
          await hasTable("shipping")
            ? await db
                .prepare("SELECT * FROM shipping WHERE order_id=?")
                .bind(c)
                .first()
            : null;

        const savedCost = Number(
          saved?.shipping_cost ??
          saved?.shipping ??
          savedShipping?.cost ??
          savedShipping?.shipping_cost ??
          savedShipping?.ongkir ??
          0
        );

        return json({
          ok: true,
          saved: true,

          tracking_number: String(
            saved?.tracking_number ??
            savedShipping?.tracking_number ??
            tracking
          ),

          courier: String(
            saved?.courier ??
            savedShipping?.courier ??
            courier
          ),

          service: String(
            saved?.shipping_service ??
            savedShipping?.service ??
            service
          ),

          cost: savedCost,
          shipping_cost: savedCost,
          total: Number(saved?.total || 0)
        });
      }

      if (b === "payments" && method === "GET") {
        const params = new URL(request.url).searchParams;
        const wanted=params.get("status");
        const search=(params.get("search")||"").trim().toLowerCase();
        if(!(await hasTable("payments"))) return json([]);
        const rows=(await db.prepare("SELECT * FROM payments ORDER BY id DESC").all()).results||[]; const out=[];
        for(const p of rows){
          const o=await db.prepare("SELECT * FROM orders WHERE id=?").bind(p.order_id).first(); if(!o) continue;
          const st=p.status||"pending"; if(wanted&&st!==wanted) continue;
          let customer=o.customer_name||""; if(o.user_id&&await hasTable("users")) customer=(await db.prepare("SELECT name FROM users WHERE id=?").bind(o.user_id).first())?.name||customer;
          const total=await computeOrderAmount(o);
          const allPays=(await db.prepare("SELECT * FROM payments WHERE order_id=? ORDER BY id ASC").bind(p.order_id).all()).results||[];
          const approved=allPays.filter(x=>String(x.status||"") === "approved").reduce((n,x)=>n+Number(x.amount||0),0);
          const explicit=String(p.payment_type||p.type||"").toLowerCase();
          const payment_type=explicit === "dp" || explicit === "deposit" ? "dp" : explicit === "full" || explicit === "pelunasan" || explicit === "settlement" ? "full" : (Number(p.amount||0) < total ? "dp" : "full");
          const previousApproved=allPays.filter(x=>String(x.status||"") === "approved" && Number(x.id||0) < Number(p.id||0)).reduce((n,x)=>n+Number(x.amount||0),0);
          const isSettlement=payment_type === "full" && previousApproved > 0;
          const shipping=await hasTable("shipping") ? await db.prepare("SELECT * FROM shipping WHERE order_id=?").bind(o.id).first() : null;
          const item={...p,order_code:o.order_code,order_total:total,customer_name:customer,method_name:p.method||"QRIS",proof_image:p.proof_image||p.proof_url||"",payment_type,paid_total:approved,remaining:Math.max(0,total-approved),is_settlement:isSettlement,tracking_number:shipping?.tracking_number||"",courier:shipping?.courier||"",service:shipping?.service||""};
          if(search){ const hay=[item.order_code,item.customer_name,item.tracking_number,item.courier,item.service,item.email||""].join(" ").toLowerCase(); if(!hay.includes(search)) continue; }
          out.push(item);
        }
        return json(out);
      }
      if (b === "payments" && c && method === "PUT") {
        const status=body.status==="approved"?"approved":body.status==="rejected"?"rejected":"pending";
        const p=await db.prepare("SELECT * FROM payments WHERE id=?").bind(c).first(); if(!p) return fail("Tidak ditemukan",404);
        if(status==="approved"){
          const o=await db.prepare("SELECT * FROM orders WHERE id=?").bind(p.order_id).first();
          if(!o) return fail("Pesanan tidak ditemukan",404);
          const start=o.ship_date||o.start_date, end=o.return_date||o.end_date;
          if(start && end){
            const items = await hasTable("order_items") ? ((await db.prepare("SELECT * FROM order_items WHERE order_id=?").bind(o.id).all()).results||[]) : [];
            const checks = items.length ? items.map(x=>x.costume_id).filter(Boolean) : [o.costume_id].filter(Boolean);
            for(const cid of checks){
              const av=await sizeAvailability(cid,start,end);
              if(!av.some(x=>Number(x.available||0)>0)) return fail("Tanggal rental sudah diambil customer lain. Pembayaran belum disetujui; minta customer memilih tanggal lain.",409);
            }
          }
        }
        await updateExisting("payments","id",c,{status,admin_note:String(body.admin_note||""),note:String(body.admin_note||""),verified_by:admin.user_id,verified_at:new Date().toISOString()});
        if(status==="approved"){ const o=await db.prepare("SELECT * FROM orders WHERE id=?").bind(p.order_id).first(); if(o){ const ps=await paymentSummary(o.id); const full=Number(ps.total||await computeOrderAmount(o)); const isFull=Number(ps.approved||0)>=full && full>0; await updateExisting("orders","id",p.order_id,{status:"paid",payment_status:isFull?"paid":"partial"}); } }
        return json({ok:true});
      }

      if (b === "customers" && method === "GET")
        return json((await db.prepare("SELECT id,name,email,phone,created_at,must_change_password FROM users WHERE role='customer' ORDER BY id DESC").all()).results);
      if (b === "customers" && c && d === "temp-password" && method === "POST") {
        const temp = "cr-" + Math.random().toString(36).slice(2, 10);
        await db.prepare("UPDATE users SET password_hash=?, must_change_password=1 WHERE id=? AND role='customer'")
          .bind(await hashPassword(temp), c).run();
        return json({ temp_password: temp });
      }

      /* ---- Kostum CRUD ---- */
      if (b === "costumes") {
        let costumeInfo = (await db.prepare("PRAGMA table_info(costumes)").all()).results || [];
        let costumeCols = new Set(costumeInfo.map((x) => x.name));
        if (!costumeCols.has("accessories")) { try { await db.prepare("ALTER TABLE costumes ADD COLUMN accessories TEXT NOT NULL DEFAULT '[]'").run(); } catch {} }
        try { await db.prepare(`CREATE TABLE IF NOT EXISTS costume_sizes (id INTEGER PRIMARY KEY AUTOINCREMENT, costume_id INTEGER NOT NULL, size TEXT NOT NULL, stock INTEGER NOT NULL DEFAULT 1)`).run(); } catch {}
        try { await db.prepare(`CREATE TABLE IF NOT EXISTS size_measurements (id INTEGER PRIMARY KEY AUTOINCREMENT, costume_id INTEGER NOT NULL, size TEXT NOT NULL, field TEXT NOT NULL, value_cm REAL NOT NULL)`).run(); } catch {}
        costumeInfo = (await db.prepare("PRAGMA table_info(costumes)").all()).results || [];
        costumeCols = new Set(costumeInfo.map((x) => x.name));
        const normalizeCostume = (r) => ({
          ...r,
          character: r.character ?? r.character_name ?? "",
          series: r.series ?? r.anime_name ?? r.anime ?? "",
          main_image: r.main_image ?? r.image_url ?? r.image ?? "",
          gender: r.gender ?? "unisex",
          category: r.category ?? "lainnya",
          status: r.status ?? (r.available === 0 ? "hidden" : "published"),
          featured: r.featured ?? 0,
          rental_count: r.rental_count ?? 0
        });
        if (method === "GET" && !c)
          return json((await db.prepare("SELECT * FROM costumes ORDER BY id DESC").all()).results.map(normalizeCostume));
        if (method === "GET" && c) {
          const row = await db.prepare("SELECT * FROM costumes WHERE id=?").bind(c).first();
          if (!row) return fail("Kostum tidak ditemukan", 404);
          const out = normalizeCostume(row);
          let raw = []; try { raw = JSON.parse(row.accessories || "[]"); } catch {}
          out.additional = raw.map(x => {
            if (x && typeof x === "object" && (x.name || x.label || x.price != null)) return {name:String(x.name || x.label || "").trim(), price:Math.max(0, parseMoney(x.price))};
            if (typeof x === "string" && x.includes("|")) { const [name, price] = x.split("|"); return {name:String(name || "").trim(), price:Math.max(0, parseMoney(price))}; }
            return null;
          }).filter(x => x && x.name);
          out.accessories = raw.filter(x => typeof x === "string" && !x.includes("|"));
          out.sizes = [];
          if (await hasTable("costume_sizes")) {
            const sc = new Set(((await db.prepare("PRAGMA table_info(costume_sizes)").all()).results || []).map(x => x.name));
            const cols = ["id","size",...(sc.has("stock") ? ["stock"] : [])].filter(x => sc.has(x));
            if (cols.length) out.sizes = (await db.prepare(`SELECT ${cols.join(",")} FROM costume_sizes WHERE costume_id=? ORDER BY id`).bind(c).all()).results || [];
          }
          out.size_measurements = [];
          if (await hasTable("size_measurements")) {
            const mr = (await db.prepare("SELECT size,field,value_cm FROM size_measurements WHERE costume_id=? ORDER BY id").bind(c).all()).results || [];
            const grouped = new Map(); for (const m of mr) { if (!grouped.has(m.size)) grouped.set(m.size,{size:m.size,measurements:{},note:""}); grouped.get(m.size).measurements[m.field]=m.value_cm; }
            out.size_measurements = [...grouped.values()];
          }
          return json(out);
        }
        // Save must work with BOTH the original production schema and the newer schema.
        // The original D1 table uses slug/character_name/anime_name/image_url/status=available
        // while the newer admin UI uses character/series/main image/status=published.
        const images = Array.isArray(body.images) ? body.images.filter((i) => validUrl(i.url)).map((i) => ({ url: i.url, is_ai: i.is_ai ? 1 : 0 })) : null;
        const sizes = Array.isArray(body.sizes) ? body.sizes.map((s) => ({ size: String(s.size || "").trim(), stock: Math.max(0, +s.stock || 0) })).filter((s) => s.size) : null;
        const measurements = Array.isArray(body.size_measurements) ? body.size_measurements.map((m) => ({ size: String(m.size || "").trim(), bust: m.bust === "" || m.bust == null ? null : Number(m.bust), waist: m.waist === "" || m.waist == null ? null : Number(m.waist), length: m.length === "" || m.length == null ? null : Number(m.length), note: String(m.note || "").trim() })).filter((m) => m.size) : null;
        const mainImage = images?.[0]?.url || (validUrl(body.image_url) ? body.image_url : "");
        const slugify = (v) => String(v || "kostum").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 70) || "kostum";
        const saveCore = async (cid = null) => {
          let saveStatus = "published";
          if (costumeCols.has("status")) {
            const statusMeta = costumeInfo.find(x => x.name === "status");
            const requested = String(body.status || "published").toLowerCase();
            const defaultStatus = String(statusMeta?.dflt_value || "").toLowerCase();
            // Do not query status blindly: some production databases have no status column.
            // For the original schema, the default is usually "available".
            if (requested === "published" && defaultStatus.includes("available")) saveStatus = "available";
            else if (["published", "available", "draft", "hidden", "maintenance"].includes(requested)) saveStatus = requested;
            else saveStatus = defaultStatus.includes("available") ? "available" : "published";
          }
          const values = {
            name: String(body.name || "").trim(),
            character: String(body.character || "").trim(),
            series: String(body.series || "").trim(),
            category: String(body.category || "lainnya").trim(),
            gender: String(body.gender || "unisex"),
            price_per_day: +body.price_per_day || 0,
            description: String(body.description || ""),
            status: saveStatus,
            image_url: mainImage,
            image: mainImage,
            stock: sizes?.reduce((n, x) => n + Math.max(0, x.stock), 0) || 1,
            featured: body.featured ? 1 : 0,
            available: body.status === "hidden" || body.status === "maintenance" ? 0 : 1,
            package_items: JSON.stringify(body.package_items || []),
            accessories: JSON.stringify((() => {
              const normalizeAddon = (a) => {
                if (typeof a === "string") {
                  const [name, price] = a.split("|");
                  return { name: String(name || "").trim(), price: Math.max(0, Number(String(price || "0").replace(/[^0-9.-]/g, "")) || 0) };
                }
                return {
                  name: String(a?.name || a?.label || "").trim(),
                  price: Math.max(0, parseMoney(a?.price))
                };
              };
              const source = Array.isArray(body.addon_items)
                ? body.addon_items
                : (Array.isArray(body.additional_items) ? body.additional_items : []);
              const addons = source.map(normalizeAddon).filter(a => a.name);
              const legacy = Array.isArray(body.accessories)
                ? body.accessories.map(normalizeAddon).filter(a => a.name)
                : [];
              return [...legacy, ...addons];
            })()),
            rules_text: String(body.rules_text || ""),
            size_guide_image: validUrl(body.size_guide_image) ? body.size_guide_image : "",
            anime: String(body.series || ""),
            images: JSON.stringify(images?.map((x) => x.url) || []),
            sizes: JSON.stringify(sizes?.map((x) => x.size) || [])
          };
          // Keep legacy `available` synchronized with the new status field so
          // Hidden always really disappears from the customer catalog.
          if (costumeCols.has("available")) values.available = ["hidden", "draft", "maintenance", "unavailable"].includes(saveStatus) ? 0 : 1;

          const data = {};
          for (const col of costumeCols) {
            if (col === "id" || col === "created_at") continue;
            if (col === "slug") data.slug = slugify(values.name) + "-" + Math.random().toString(36).slice(2, 7);
            else if (col === "character_name") data.character_name = values.character;
            else if (col === "anime_name") data.anime_name = values.series;
            else if (values[col] !== undefined) data[col] = values[col];
          }
          const keys = Object.keys(data);
          if (!keys.includes("name")) throw new Error("Kolom name pada tabel costumes tidak ditemukan.");
          if (cid == null) {
            const sql = `INSERT INTO costumes (${keys.join(",")}) VALUES (${keys.map(() => "?").join(",")})`;
            const r = await db.prepare(sql).bind(...keys.map((k) => data[k])).run();
            const id = r.meta.last_row_id;
            const saved = await db.prepare("SELECT id FROM costumes WHERE id=?").bind(id).first();
            if (!saved) throw new Error("Data kostum tidak ditemukan setelah INSERT.");
            return id;
          }
          const sql = `UPDATE costumes SET ${keys.map((k) => `${k}=?`).join(",")} WHERE id=?`;
          await db.prepare(sql).bind(...keys.map((k) => data[k]), cid).run();
          const saved = await db.prepare("SELECT id FROM costumes WHERE id=?").bind(cid).first();
          if (!saved) throw new Error("Data kostum tidak ditemukan setelah UPDATE.");
          return cid;
        };
        const saveChildren = async (cid) => {
          if (images && await hasTable("costume_images")) {
            await db.prepare("DELETE FROM costume_images WHERE costume_id=?").bind(cid).run();
            const st = db.prepare("INSERT INTO costume_images (costume_id,url,type,is_ai,sort_order) VALUES (?,?,?,?,?)");
            await db.batch(images.map((i, idx) => st.bind(cid, i.url, idx === 0 ? "main" : "detail", i.is_ai, idx)));
          }
          if (sizes && await hasTable("costume_sizes")) {
            const sizeCols = new Set(((await db.prepare("PRAGMA table_info(costume_sizes)").all()).results || []).map(x => x.name));
            await db.prepare("DELETE FROM costume_sizes WHERE costume_id=?").bind(cid).run();
            if (sizes.length) {
              if (sizeCols.has("stock")) {
                const st = db.prepare("INSERT INTO costume_sizes (costume_id,size,stock) VALUES (?,?,?)");
                await db.batch(sizes.map((s) => st.bind(cid, s.size, s.stock)));
              } else {
                const st = db.prepare("INSERT INTO costume_sizes (costume_id,size) VALUES (?,?)");
                await db.batch(sizes.map((s) => st.bind(cid, s.size)));
              }
            }
          }
          if (measurements && await hasTable("size_measurements")) {
            const measurementCols = new Set(((await db.prepare("PRAGMA table_info(size_measurements)").all()).results || []).map(x => x.name));
            if (measurementCols.has("costume_id") && measurementCols.has("size") && measurementCols.has("field") && measurementCols.has("value_cm")) {
              await db.prepare("DELETE FROM size_measurements WHERE costume_id=?").bind(cid).run();
              const st = db.prepare("INSERT INTO size_measurements (costume_id,size,field,value_cm) VALUES (?,?,?,?)");
              const rows=[];
              measurements.forEach(m=>{
                if(m.bust!=null && Number.isFinite(m.bust)) rows.push(st.bind(cid,m.size,"bust",m.bust));
                if(m.waist!=null && Number.isFinite(m.waist)) rows.push(st.bind(cid,m.size,"waist",m.waist));
                if(m.length!=null && Number.isFinite(m.length)) rows.push(st.bind(cid,m.size,"length",m.length));
              });
              if(rows.length) await db.batch(rows);
            }
          }
        };
        if (method === "POST" && !c) {
          let id = null;
          try {
            id = await saveCore();
            await saveChildren(id);
            const saved = await db.prepare("SELECT * FROM costumes WHERE id=?").bind(id).first();
            return json({ ok: true, id, costume: normalizeCostume(saved) }, 201);
          } catch (e) {
            if (id != null) {
              try { await db.prepare("DELETE FROM costumes WHERE id=?").bind(id).run(); } catch {}
            }
            return fail("Kostum gagal disimpan: " + (e?.message || "database error"), 500);
          }
        }
        if (method === "PUT" && c) {
          try {
            await saveCore(c);
            await saveChildren(c);
            const saved = await db.prepare("SELECT * FROM costumes WHERE id=?").bind(c).first();
            return json({ ok: true, id: c, costume: normalizeCostume(saved) });
          } catch (e) {
            return fail("Kostum gagal diperbarui: " + (e?.message || "database error"), 500);
          }
        }
        if (method === "DELETE" && c) {
          const exists = await db.prepare("SELECT * FROM costumes WHERE id=?").bind(c).first();
          if (!exists) return fail("Kostum tidak ditemukan", 404);

          // Hard-delete is intentionally allowed even when the costume has
          // historical orders. The catalog entry should disappear completely.
          // Any order that depends on this costume is removed together with its
          // dependent records so SQLite foreign keys cannot block the delete.
          const orderIds = new Set();
          if (await hasTable("orders")) {
            const rows = await db.prepare("SELECT id FROM orders WHERE costume_id=?").bind(c).all();
            for (const r of (rows.results || [])) if (r?.id != null) orderIds.add(String(r.id));
          }
          if (await hasTable("order_items")) {
            const rows = await db.prepare("SELECT order_id FROM order_items WHERE costume_id=?").bind(c).all();
            for (const r of (rows.results || [])) if (r?.order_id != null) orderIds.add(String(r.order_id));
          }

          const orderTables = ["reviews","ktp_records","shipping","payments","order_items","inspections","steps"];
          for (const oid of orderIds) {
            for (const t of orderTables) {
              if (!(await hasTable(t))) continue;
              const cols = await getTableColumns(t);
              if (cols.has("order_id")) {
                try { await db.prepare(`DELETE FROM "${t.replace(/"/g,'""')}" WHERE order_id=?`).bind(oid).run(); } catch {}
              }
            }
            if (await hasTable("orders")) {
              try { await db.prepare("DELETE FROM orders WHERE id=?").bind(oid).run(); } catch {}
            }
          }

          // Remove any remaining costume-linked records across known/legacy tables.
          const costumeTables = ["reviews","order_items","inspections","steps","costume_images","costume_sizes","size_measurements"];
          for (const t of costumeTables) {
            if (!(await hasTable(t))) continue;
            const cols = await getTableColumns(t);
            if (cols.has("costume_id")) {
              try { await db.prepare(`DELETE FROM "${t.replace(/"/g,'""')}" WHERE costume_id=?`).bind(c).run(); } catch {}
            }
          }

          await db.prepare("DELETE FROM costumes WHERE id=?").bind(c).run();
          return json({ ok: true, deleted: true, hard_deleted: true, message: "Kostum berhasil dihapus permanen." });
        }
      }

      /* ---- Payment methods CRUD ---- */
      // Public customer endpoint: /api/payment-methods
      // Admin endpoint remains /api/admin/payment-methods.
      if (a === "payment-methods" && method === "GET") {
        return json(await getPaymentMethodsCompat({ activeOnly: true }));
      }
      if (b === "payment-methods") {
        if (method === "GET") return json(await getPaymentMethodsCompat());
        if (method === "POST" && !c) {
          await savePaymentMethodCompat(null, body);
          return json({ ok: true }, 201);
        }
        if (method === "PUT" && c) {
          await savePaymentMethodCompat(c, body);
          return json({ ok: true });
        }
        if (method === "DELETE" && c) {
          if (await hasTable("payment_methods")) await db.prepare("DELETE FROM payment_methods WHERE id=?").bind(c).run();
          else await upsertSettings({ qris_active: "0" });
          return json({ ok: true });
        }
      }

      /* ---- Reviews ---- */
      if (b === "reviews") {
        const reviewCols=await getTableColumns("reviews");
        if(method==="GET"){ if(!(await hasTable("reviews"))) return json([]); const rows=(await db.prepare("SELECT * FROM reviews ORDER BY id DESC").all()).results||[]; const out=[]; for(const r of rows){const o=await db.prepare("SELECT order_code FROM orders WHERE id=?").bind(r.order_id).first();const u=await db.prepare("SELECT name FROM users WHERE id=?").bind(r.user_id).first();const cst=await db.prepare("SELECT name FROM costumes WHERE id=?").bind(r.costume_id).first();out.push({...r,order_code:o?.order_code||"",user_name:u?.name||"",costume_name:cst?.name||"",text:r.text??r.comment??"",status:r.status||"pending"});} return json(out); }
        if(method==="PUT"&&c){ if(!reviewCols.has("status")) return fail("Moderasi review belum tersedia karena kolom status tidak ada di schema D1 saat ini.",409); await updateExisting("reviews","id",c,{status:body.status==="approved"?"approved":"rejected"}); return json({ok:true}); }
      }

      /* ---- Maintenance ---- */
      if (b === "maintenance") {
        if (!(await hasTable("maintenance"))) { if(method==="GET") return json([]); return fail("Maintenance belum tersedia pada schema database saat ini.",409); }
        if (method === "GET") return json((await db.prepare(`SELECT m.*, c.name AS costume_name FROM maintenance m JOIN costumes c ON c.id=m.costume_id ORDER BY m.id DESC`).all()).results);
        if (method === "POST" && !c) {
          if (!body.costume_id || !body.start_date || !body.end_date || body.end_date < body.start_date) return fail("Data maintenance tidak valid");
          await db.prepare("INSERT INTO maintenance (costume_id,start_date,end_date,note) VALUES (?,?,?,?)").bind(body.costume_id, body.start_date, body.end_date, body.note || "").run();
          return json({ ok: true }, 201);
        }
        if (method === "DELETE" && c) { await db.prepare("DELETE FROM maintenance WHERE id=?").bind(c).run(); return json({ ok: true }); }
      }

      /* ---- Settings ---- */
      if (b === "settings" && method === "GET") {
        const all = await getSettings();
        delete all.password_hash;
        for (const k of SECRET_SETTING_KEYS) {
          const configured = !!(env[k.toUpperCase()] || all[k]);
          all[k] = configured ? "••••••••••••••••" : "";
          all[`${k}_configured`] = configured;
        }
        all.settings_encryption_key_configured = !!String(env.SETTINGS_ENCRYPTION_KEY || "").trim();
        return json(all);
      }
      if (b === "settings" && method === "PUT") {
        try { await upsertSettings(body); return json({ ok: true }); }
        catch (e) { return fail(e.message || "Gagal menyimpan settings"); }
      }

    }

    return fail("Not found", 404);
  } catch (e) {
    return json({ error: e.message }, 500);
  }
}