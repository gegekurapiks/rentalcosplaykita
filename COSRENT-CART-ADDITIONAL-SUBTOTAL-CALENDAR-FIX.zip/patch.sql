﻿INSERT OR IGNORE INTO categories (slug, name) VALUES
  ('kimono','Kimono'), ('school','Sekolah'), ('armor','Armor'), ('dress','Gaun');

INSERT INTO costumes (id, name, anime, category, price_per_day, sizes, description, images, featured, available)
  SELECT 1,'Fantasy Knight','Original','armor',125000,'["M","L","XL"]','Set armor lengkap dengan cape dan properti pedang.','["https://placehold.co/600x800?text=Knight+Foto+1","https://placehold.co/800x600?text=Knight+Foto+2"]',1,1
  WHERE NOT EXISTS (SELECT 1 FROM costumes WHERE id=1);
INSERT INTO costumes (id, name, anime, category, price_per_day, sizes, description, images, featured, available)
  SELECT 2,'Seragam Sailor','Original','school',85000,'["S","M","L"]','Seragam sailor lengkap dengan dasi dan kaos kaki.','["https://placehold.co/600x800?text=Sailor+Foto+1"]',0,1
  WHERE NOT EXISTS (SELECT 1 FROM costumes WHERE id=2);
INSERT INTO costumes (id, name, anime, category, price_per_day, sizes, description, images, featured, available)
  SELECT 3,'Kimono Sakura','Original','kimono',110000,'["S","M","L","XL"]','Kimono motif sakura dengan obi mengkilap.','["https://placehold.co/800x600?text=Kimono+Foto+1","https://placehold.co/600x800?text=Kimono+Foto+2"]',0,1
  WHERE NOT EXISTS (SELECT 1 FROM costumes WHERE id=3);
INSERT INTO costumes (id, name, anime, category, price_per_day, sizes, description, images, featured, available)
  SELECT 4,'Gaun Putri Kerajaan','Original','dress',140000,'["S","M"]','Gaun pesta royal dengan detail renda.','["https://placehold.co/600x800?text=Gaun+Foto+1"]',0,1
  WHERE NOT EXISTS (SELECT 1 FROM costumes WHERE id=4);

UPDATE costumes SET images='["https://placehold.co/600x800?text=Knight+Foto+1","https://placehold.co/800x600?text=Knight+Foto+2"]' WHERE id=1 AND images IN ('[]','');
UPDATE costumes SET images='["https://placehold.co/600x800?text=Sailor+Foto+1"]' WHERE id=2 AND images IN ('[]','');
UPDATE costumes SET images='["https://placehold.co/800x600?text=Kimono+Foto+1","https://placehold.co/600x800?text=Kimono+Foto+2"]' WHERE id=3 AND images IN ('[]','');
UPDATE costumes SET images='["https://placehold.co/600x800?text=Gaun+Foto+1"]' WHERE id=4 AND images IN ('[]','');

CREATE TABLE IF NOT EXISTS steps (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  number TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  sort_order INTEGER NOT NULL DEFAULT 0
);
INSERT INTO steps (number, title, description, sort_order)
  SELECT '01','Pilih kostum','Lihat-lihat karakter, ukuran, dan detail kostum.',1
  WHERE NOT EXISTS (SELECT 1 FROM steps WHERE title='Pilih kostum');
INSERT INTO steps (number, title, description, sort_order)
  SELECT '02','Pesan tanggal','Cek ketersediaan dan tentukan durasi sewa.',2
  WHERE NOT EXISTS (SELECT 1 FROM steps WHERE title='Pesan tanggal');
INSERT INTO steps (number, title, description, sort_order)
  SELECT '03','Bayar','QRIS, DANA, ShopeePay, GoPay, OVO, atau transfer bank.',3
  WHERE NOT EXISTS (SELECT 1 FROM steps WHERE title='Bayar');
INSERT INTO steps (number, title, description, sort_order)
  SELECT '04','Terima & kembalikan','Ikuti status pesanan, kembalikan tepat waktu.',4
  WHERE NOT EXISTS (SELECT 1 FROM steps WHERE title='Terima & kembalikan');

INSERT OR IGNORE INTO settings (key, value) VALUES ('featured_costume_id','1');
