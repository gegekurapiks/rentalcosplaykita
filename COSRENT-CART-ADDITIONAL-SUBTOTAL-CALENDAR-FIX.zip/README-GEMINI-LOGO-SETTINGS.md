# COSRENT — Gemini, Logo Upload & Settings Encryption

## Gemini
Admin → Settings → AI Customer:
- Provider: `gemini`
- Model: `gemini-2.5-flash`
- API key: isi Gemini API Key

The API key is stored encrypted in D1 when `SETTINGS_ENCRYPTION_KEY` exists.

## SETTINGS_ENCRYPTION_KEY
This key is a Cloudflare Secret and is intentionally NOT stored in D1.

For local development, put it in `.dev.vars`.

For Cloudflare Pages/Workers, configure the secret named:
`SETTINGS_ENCRYPTION_KEY`

Example CLI:
`npx wrangler pages secret put SETTINGS_ENCRYPTION_KEY`

Use a long random secret. Do not put the real value into Git or frontend code.

## Logo
Admin → Settings → Identitas:
- Upload image
- Ctrl+V image directly on the Settings page
- Drag/drop can be added through the file picker
- Crop to square
- Saved as an optimized data URL in the existing `settings.logo_url` value
- No logo domain/URL is required
