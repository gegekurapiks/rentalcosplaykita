﻿CREATE TABLE IF NOT EXISTS costume_sizes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  costume_id INTEGER NOT NULL REFERENCES costumes(id),
  size TEXT NOT NULL,
  stock INTEGER NOT NULL DEFAULT 1,
  UNIQUE(costume_id, size)
);
INSERT INTO costume_sizes (costume_id, size, stock)
  SELECT c.id, TRIM(j.value), 1 FROM costumes c, json_each(c.sizes) j
  WHERE NOT EXISTS (SELECT 1 FROM costume_sizes cs WHERE cs.costume_id = c.id);
