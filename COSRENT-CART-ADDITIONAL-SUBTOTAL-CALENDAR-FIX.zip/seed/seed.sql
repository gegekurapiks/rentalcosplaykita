INSERT OR IGNORE INTO costumes
(id, slug, name, character_name, anime_name, category, price_per_day, deposit, stock, status, description, image_url)
VALUES
(1,'miko-classic','Classic Miko Set','Miko','Original / Shrine Maiden','kimono',75000,150000,2,'available','Set miko dengan atasan, rok, obi, dan aksesori dasar.','/assets/cosplay-placeholder.svg'),
(2,'school-sailor','Sailor School Uniform','School Girl','Anime School','school',65000,120000,3,'available','Seragam sailor serbaguna untuk berbagai karakter anime sekolah.','/assets/cosplay-placeholder.svg'),
(3,'fantasy-knight','Fantasy Knight Costume','Knight','Fantasy Anime','armor',125000,250000,1,'available','Kostum knight dengan detail armor dan cape.','/assets/cosplay-placeholder.svg'),
(4,'gothic-idol','Gothic Idol Dress','Idol','Original Gothic Idol','dress',95000,180000,2,'available','Dress gothic dengan detail ribbon dan aksesori.','/assets/cosplay-placeholder.svg');

INSERT OR IGNORE INTO costume_sizes
(costume_id,size,height_min,height_max,ld,lp,lb,pb,pl,ll)
VALUES
(1,'S',145,155,84,68,36,72,57,30),
(1,'M',150,165,90,74,38,75,58,32),
(1,'L',160,172,96,80,40,78,59,34),
(1,'XL',168,180,104,88,43,82,60,36),
(2,'S',145,155,82,66,35,70,56,29),
(2,'M',150,165,88,72,37,73,57,31),
(2,'L',160,172,94,78,39,76,58,33),
(2,'XL',168,180,102,86,42,80,59,35),
(3,'S',150,160,86,70,37,78,59,30),
(3,'M',158,168,92,76,39,82,60,32),
(3,'L',165,175,100,84,42,86,61,34),
(3,'XL',172,185,108,92,45,90,62,36),
(4,'S',145,155,84,66,35,72,55,29),
(4,'M',150,165,90,72,37,75,56,31),
(4,'L',160,172,96,80,40,78,57,33),
(4,'XL',168,180,104,88,43,82,58,35);
