DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS costumes;
DROP TABLE IF EXISTS steps;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS settings;

CREATE TABLE settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);

CREATE TABLE categories (
  id   INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL
);

CREATE TABLE costumes (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  anime         TEXT NOT NULL DEFAULT '',
  category      TEXT NOT NULL DEFAULT 'lainnya',
  price_per_day INTEGER NOT NULL DEFAULT 0,
  sizes         TEXT NOT NULL DEFAULT '["S","M","L","XL"]',
  description   TEXT NOT NULL DEFAULT '',
  image         TEXT NOT NULL DEFAULT '',
  featured      INTEGER NOT NULL DEFAULT 0,
  available     INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE steps (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  number      TEXT NOT NULL DEFAULT '',
  title       TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  sort_order  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE orders (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  order_code     TEXT UNIQUE NOT NULL,
  costume_id     INTEGER NOT NULL REFERENCES costumes(id),
  customer_name  TEXT NOT NULL,
  size           TEXT NOT NULL DEFAULT '',
  start_date     TEXT NOT NULL,
  end_date       TEXT NOT NULL,
  payment_method TEXT NOT NULL DEFAULT 'qris',
  status         TEXT NOT NULL DEFAULT 'pending',
  payment_status TEXT NOT NULL DEFAULT 'unpaid',
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

