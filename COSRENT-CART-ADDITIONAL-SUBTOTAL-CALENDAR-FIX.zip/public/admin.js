const $ = (s) => document.querySelector(s);
const esc = (t) => String(t ?? "").replace(/[&<>"']/g, (c) => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
const rupiah = (n) => "Rp" + Number(n || 0).toLocaleString("id-ID");
const STATUS_ID = { pending_payment:"Menunggu Bayar", payment_review:"Verifikasi Bayar", paid:"Dibayar", preparing:"Disiapkan", shipped:"Dikirim", rented:"Disewa", returned:"Dikembalikan", inspection:"Pemeriksaan", completed:"Selesai", cancelled:"Dibatalkan" };
const FLOW = ["pending_payment","payment_review","paid","preparing","shipped","rented","returned","inspection","completed"];

const api = (path, opts = {}) =>
  fetch("/api" + path, { ...opts, headers: { ...(opts.body ? { "content-type": "application/json" } : {}) } })
    .then(async (r) => { const d = await r.json().catch(() => ({})); if (r.status === 401) { showLogin(); throw new Error("unauthorized"); } if (!r.ok || d.ok === false) throw new Error(d.error || `Request gagal (${r.status})`); return d; });

function showLogin() { $("#login").hidden = false; $("#panel").hidden = true; }
function showPanel() { $("#login").hidden = true; $("#panel").hidden = false; loadAll(); }
async function login() {
  const r = await fetch("/api/admin/login", { method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify({ email: $("#email").value, password: $("#password").value }) }).then((x) => x.json()).catch(() => null);
  if (r?.ok) showPanel(); else alert(r?.error || "Gagal masuk");
}
async function logout() { await fetch("/api/admin/logout", { method: "POST" }); showLogin(); }

function compress(file, maxDim = 1200, q = 0.72) {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => {
      const sc = Math.min(1, maxDim / Math.max(img.width, img.height));
      const cv = document.createElement("canvas");
      cv.width = Math.round(img.width * sc); cv.height = Math.round(img.height * sc);
      cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
      res(cv.toDataURL("image/jpeg", q)); URL.revokeObjectURL(img.src);
    };
    img.onerror = rej; img.src = URL.createObjectURL(file);
  });
}

/* ---- Tabs ---- */
document.querySelectorAll("#tabbar button").forEach((b) => b.addEventListener("click", () => activateTab(b.dataset.tab)));
function activateTab(name) {
  document.querySelectorAll("#tabbar button").forEach((b) => b.classList.toggle("active", b.dataset.tab === name));
  document.querySelectorAll(".tab-section").forEach((s) => s.classList.toggle("active", s.id === "tab-" + name));
}

/* ---- Dashboard ---- */
async function loadDash() {
  const d = await api("/admin/dashboard");
  $("#dashStats").innerHTML = [
    ["Total Order", d.total_orders], ["Revenue", rupiah(d.revenue)],
    ["Belum DP", d.dp_pending?.length || 0], ["Belum Lunas", d.settlement_pending?.length || 0],
    ["Kirim Hari Ini", d.ship_today?.length || 0], ["Pending Payment", d.pending_payments],
    ["Rental Aktif", d.active_rentals], ["Kostum", d.costumes], ["Customer", d.customers],
  ].map(([l, v]) => `<div class="stat-card"><b>${v}</b><span>${l}</span></div>`).join("");
  const mini = (o, type) => `<div class="stack" style="justify-content:space-between;border-bottom:1px solid var(--line);padding:8px 0;gap:10px">
    <div><b>${esc(o.customer_name)}</b><br><small>${esc(o.order_code)} • ${esc(o.ship_date || "-")}</small></div>
    <div style="text-align:right"><b>${type === "ship" ? "Kirim" : rupiah(type === "dp" ? o.total : o.remaining)}</b><br><button class="btn ghost small" type="button" onclick="window.openOrder(${JSON.stringify(String(o.id))})">Detail</button></div>
  </div>`;
  $("#dashDpPending").innerHTML = d.dp_pending?.length ? d.dp_pending.slice(0,8).map(o=>mini(o,"dp")).join("") : `<p class="muted">Semua pesanan sudah memiliki pembayaran.</p>`;
  $("#dashSettlementPending").innerHTML = d.settlement_pending?.length ? d.settlement_pending.slice(0,8).map(o=>mini(o,"settlement")).join("") : `<p class="muted">Tidak ada sisa pelunasan.</p>`;
  $("#dashShipToday").innerHTML = d.ship_today?.length ? d.ship_today.slice(0,8).map(o=>mini(o,"ship")).join("") : `<p class="muted">Tidak ada pengiriman hari ini.</p>`;
}

/* ---- Pesanan ---- */
let currentOrderList = [];
async function loadOrders() {
  const q = $("#orderSearch").value.trim();
  const list = await api("/admin/orders" + (q ? `?search=${encodeURIComponent(q)}` : ""));
  currentOrderList = list;
  $("#orderTable").innerHTML = `
    <div class="order-tools">
      <label><input type="checkbox" id="selectAllOrders"> Pilih semua</label>
      <button type="button" class="btn ghost small" onclick="deleteSelectedOrders()">Hapus yang dipilih</button>
      <small class="muted">Bisa menghapus pesanan lama/status apa pun secara permanen.</small>
    </div>
    <table>
    <tr><th></th><th>Kode</th><th>Customer</th><th>Item</th><th>Tanggal</th><th>Total</th><th>Resi</th><th>Status</th><th></th></tr>
    ${list.map((o) => `<tr>
      <td><input class="order-select" type="checkbox" value="${esc(o.id)}"></td>
      <td>${esc(o.order_code)}</td><td>${esc(o.user_name)}<br><small>${esc(o.user_email)}</small></td>
      <td>${esc(o.items_label || "-")}</td><td>${esc(o.ship_date)}<br>s/d ${esc(o.return_date)}</td>
      <td>${rupiah(o.total)}</td>
      <td>${o.tracking_number ? `<b>${esc(o.tracking_number)}</b>${o.shipping?.courier ? `<br><small>${esc(o.shipping.courier)}</small>` : ""}` : `<span class="muted">Belum ada</span>`}</td>
      <td><span class="pill st-${esc(o.status)}">${STATUS_ID[o.status] || esc(o.status)}</span></td>
      <td><button type="button" class="order-detail-btn" data-order-id="${esc(o.id)}">Detail</button></td></tr>`).join("")}
    </table>`;
  const all = $("#selectAllOrders");
  if (all) all.onchange = () => document.querySelectorAll(".order-select").forEach(x => x.checked = all.checked);
}
async function deleteSelectedOrders() {
  const ids = [...document.querySelectorAll(".order-select:checked")].map(x => x.value);
  if (!ids.length) return alert("Pilih pesanan yang mau dihapus dulu.");
  if (!confirm(`Hapus ${ids.length} pesanan secara permanen?\n\nData pesanan, pembayaran, item, KTP, dan data terkait yang tersimpan akan ikut dibersihkan dan tidak bisa dikembalikan.`)) return;
  const r = await api("/admin/orders/permanent", { method:"POST", body:JSON.stringify({ids}) });
  alert(r.message || `${r.deleted || 0} pesanan dihapus permanen.`);
  await loadOrders();
  loadDash();
}
window.openOrder = async function openOrder(id) {
  const modal = $("#modal");
  const body = $("#modalBody");
  if (!modal || !body) return alert("Panel detail pesanan belum tersedia. Refresh halaman admin.");
  body.innerHTML = `<div class="stack" style="padding:24px;text-align:center"><b>Memuat detail pesanan…</b></div>`;
  modal.classList.remove("hidden");
  try {
    const o = await api("/admin/orders/" + id);
  const cancellable = ["pending_payment","payment_review","paid","preparing"].includes(o.status);
  const f = FLOW.map((s) => `<option value="${s}" ${s === o.status ? "selected" : ""}>${STATUS_ID[s]}</option>`).join("");
  const paymentStatus = o.payment_summary?.status === "paid" ? "Lunas / Full Payment" : o.payment_summary?.status === "partial" ? "DP 50% Dibayar" : o.payment_summary?.status === "pending" ? "Menunggu verifikasi" : "Belum dibayar";
  $("#modalBody").innerHTML = `
    <h2>${esc(o.order_code)} <span class="pill st-${esc(o.status)}">${STATUS_ID[o.status] || esc(o.status)}</span></h2>
    <div class="group-card"><h3>Data Pesanan</h3>
      <div class="row"><label style="flex:1">Nama penerima<input id="ordRecipient" value="${esc(o.recipient_name || o.user_name || "")}" placeholder="Belum tersimpan — isi manual"></label><label style="flex:1">No. HP<input id="ordPhone" value="${esc(o.recipient_phone || o.user_phone || o.customer_phone || "")}" placeholder="Belum tersimpan — isi nomor HP"></label></div>
      <label>Alamat<textarea id="ordAddress" placeholder="Belum tersimpan — isi alamat">${esc(o.ship_address || o.shipping_address || o.address || "")}</textarea></label>
      <div class="row"><label style="flex:1">Tanggal kirim<input id="ordShipDate" type="date" value="${esc(o.ship_date || "")}"></label><label style="flex:1">Tanggal kembali<input id="ordReturnDate" type="date" value="${esc(o.return_date || "")}"></label></div>
      <label>Catatan<textarea id="ordNote" placeholder="Belum ada catatan">${esc(o.note || "")}</textarea></label>
    </div>
    <div class="group-card"><h3>Item</h3>${o.items.map((i) => `<p><b>${esc(i.costume_name)}</b> • ${i.days || 1} hari • ${rupiah(i.price_per_day || 0)}/3 hari</p>`).join("")}</div>
    <div class="pay-summary"><div><span>Subtotal</span><b>${rupiah(o.subtotal)}</b></div><div><span>Ongkir</span><b>${rupiah(o.shipping_cost)}</b></div><div><span>Denda</span><b>${rupiah(o.fine_amount)}</b></div><div class="pay-total"><span>TOTAL</span><b>${rupiah(o.total)}</b></div></div>
    <div class="group-card"><h3>Status & Denda</h3>
      ${o.status === "cancelled" ? `<p><span class="pill st-cancelled">Dibatalkan</span></p>` : `<select id="ordStatus">${f}</select>`}
      <div class="row"><input id="ordFine" type="number" value="${o.fine_amount || 0}" placeholder="Denda Rp" style="max-width:120px"><input id="ordFineNote" value="${esc(o.fine_note || "")}" placeholder="alasan denda"><button onclick="saveOrder(${o.id})">Simpan Detail</button></div>
      ${cancellable ? `<div class="cancel-actions"><button class="btn danger" onclick="adminCancelOrder(${o.id})">Batalkan Pesanan</button><small>DP tidak dikembalikan. Tanggal rental akan tersedia kembali.</small></div>` : ""}
      ${o.status === "cancelled" ? `<div class="permanent-delete"><button class="btn ghost small" onclick="permanentDeleteOrder(${o.id})">Hapus Permanen</button></div>` : ""}
    </div>
    <div class="group-card"><h3>Status Pembayaran</h3><p><b>${paymentStatus}</b></p>${o.payment_summary?.approved > 0 ? `<p class="muted">Sudah dibayar: ${rupiah(o.payment_summary.approved)}${o.payment_summary?.status === "partial" ? ` • Sisa: ${rupiah(Math.max(0,(o.payment_summary.total||o.total||0)-o.payment_summary.approved))}` : ""}</p>` : ""}</div>
    <div class="group-card"><h3>Pengiriman</h3><div class="row"><input id="shCourier" value="${esc(o.shipping?.courier || "")}" placeholder="Kurir"><input id="shService" value="${esc(o.shipping?.service || "")}" placeholder="Service"><input id="shCost" type="number" value="${o.shipping?.cost || o.shipping_cost || 0}" placeholder="Ongkir Rp"></div><div class="row"><input id="shTrack" value="${esc(o.shipping?.tracking_number || "")}" placeholder="No. resi"><select id="shOrderStatus">${f}</select><button onclick="saveShipping(${o.id})">Simpan Pengiriman</button></div></div>
    <div class="group-card"><h3>Pembayaran</h3>${o.payments.length ? o.payments.map((p) => `<div class="stack"><b>${rupiah(p.amount)}</b> • <span class="pill">${esc((p.payment_type||p.type||p.note)==="dp"?"DP 50%":"Full Payment")}</span> • ${esc(p.method_name || "QRIS")} • <span class="pill ${p.status === "approved" ? "st-done" : p.status === "rejected" ? "st-cancelled" : "st-pending"}">${p.status || "pending"}</span>${p.proof_image ? `<img class="photo-thumb" src="${esc(p.proof_image)}">` : ""}${p.status === "pending" ? `<input id="payNote${p.id}" placeholder="catatan"><button onclick="setPay(${p.id},'approved')">Approve</button><button onclick="setPay(${p.id},'rejected')">Reject</button>` : ""}</div>`).join("") : `<p class="muted">Belum ada bukti.</p>`}</div>`;
    $("#modal").classList.remove("hidden");
  } catch (e) {
    body.innerHTML = `<div class="stack" style="padding:24px"><h3>Detail pesanan gagal dimuat</h3><p class="muted">${esc(e.message || "Terjadi kesalahan")}</p><button class="btn ghost" type="button" onclick="closeModal()">Tutup</button></div>`;
  }
}
function closeModal() {
  const modal = $("#modal");
  if (modal) modal.classList.add("hidden");
}
window.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });
async function adminCancelOrder(id) {
  if (!confirm("Batalkan pesanan ini?\n\nDP yang sudah dibayar tidak dikembalikan dan tanggal rental akan tersedia kembali.")) return;
  const r = await api(`/admin/orders/${id}/cancel`, { method: "POST" });
  if (!r.ok) return alert(r.error || "Pesanan gagal dibatalkan");
  alert("Pesanan dibatalkan. Tanggal rental sudah tersedia kembali.");
  closeModal();
  loadOrders();
}
async function permanentDeleteOrder(id) {
  if (!confirm("Hapus pesanan secara permanen?\n\nData pesanan akan dihapus dan tidak dapat dikembalikan.")) return;
  const r = await api(`/admin/orders/${id}/permanent`, { method: "DELETE" });
  if (!r.ok) return alert(r.error || "Pesanan gagal dihapus");
  alert("Pesanan dihapus permanen.");
  closeModal();
  loadOrders();
}
async function saveOrder(id) {
  const r=await api("/admin/orders/" + id, { method: "PUT", body: JSON.stringify({
    status: $("#ordStatus")?.value, fine_amount: +$("#ordFine")?.value || 0, fine_note: $("#ordFineNote")?.value || "",
    recipient_name: $("#ordRecipient")?.value || "", recipient_phone: $("#ordPhone")?.value || "", ship_address: $("#ordAddress")?.value || "",
    ship_date: $("#ordShipDate")?.value || "", return_date: $("#ordReturnDate")?.value || "", note: $("#ordNote")?.value || "" }) });
  if(!r.ok) return alert(r.error||"Gagal menyimpan detail pesanan");
  alert("Tersimpan"); closeModal(); loadOrders();
}
async function saveShipping(id) {
  try { await api(`/admin/orders/${id}/shipping`, { method: "PUT", body: JSON.stringify({
    courier: $("#shCourier").value, service: $("#shService").value, cost: +$("#shCost").value || 0, shipping_cost: +$("#shCost").value || 0,
    tracking_number: $("#shTrack").value, order_status: $("#shOrderStatus").value }) });
    alert("Pengiriman tersimpan — total order sudah diperbarui"); closeModal(); loadOrders();
  } catch(e) { alert(e.message || "Gagal menyimpan pengiriman"); }
}
async function setPay(id, status) {
  await api("/admin/payments/" + id, { method: "PUT", body: JSON.stringify({ status, admin_note: $("#payNote" + id)?.value || "" }) });
  loadPayments(); loadOrders();
}

/* ---- Pembayaran: satu daftar gabungan DP + Pelunasan + Full Payment ---- */
async function loadPayments() {
  const q = (document.querySelector("#paymentSearch")?.value || "").trim();
  const list = await api("/admin/payments" + (q ? `?search=${encodeURIComponent(q)}` : ""));
  const approved = list.filter(p => p.status === "approved");
  const dp = list.filter(p => p.payment_type === "dp");
  const settlement = list.filter(p => p.is_settlement || p.payment_type === "full");
  const unpaidSettlement = list.filter(p => Number(p.remaining || 0) > 0 && p.payment_type === "dp");
  const card = (p) => {
    const label = p.payment_type === "dp" ? "DP 50%" : (p.is_settlement ? "Pelunasan" : "Full Payment");
    return `<div class="order-item">
      <div class="order-head"><b>${esc(p.order_code)}</b> — ${esc(p.customer_name || "-")} <span class="pill">${label}</span> <span class="pill ${p.status === "approved" ? "st-done" : p.status === "rejected" ? "st-cancelled" : "st-pending"}">${esc(p.status || "pending")}</span></div>
      <p><b>${rupiah(p.amount)}</b> via ${esc(p.method_name || "-")} • total ${rupiah(p.order_total)} • sudah dibayar ${rupiah(p.paid_total)} • <b>sisa ${rupiah(p.remaining)}</b></p>
      <p class="muted">Resi: <b>${esc(p.tracking_number || "Belum ada")}</b>${p.courier ? ` • ${esc(p.courier)} ${esc(p.service || "")}` : ""} • ${esc(p.created_at || "")}</p>
      ${p.remaining > 0 && p.status === "approved" && p.payment_type === "dp" ? `<p class="pay-reminder"><b>⚠️ Menunggu pelunasan:</b> ${rupiah(p.remaining)}</p>` : ""}
      ${p.proof_image ? `<img class="proof-thumb" src="${esc(p.proof_image)}">` : ""}
      ${p.admin_note ? `<p class="muted">Catatan: ${esc(p.admin_note)}</p>` : ""}
      ${p.status === "pending" ? `<div class="row"><input id="pn${p.id}" placeholder="catatan (utk reject)"><button onclick="setPay(${p.id},'approved')">✅ Approve</button><button onclick="setPay(${p.id},'rejected')">❌ Reject</button></div>` : ""}
    </div>`;
  };
  $("#payList").innerHTML = `<div class="payment-summary-grid">
    <div class="stat-card"><b>${list.length}</b><span>Semua Pembayaran</span></div>
    <div class="stat-card"><b>${dp.length}</b><span>DP</span></div>
    <div class="stat-card"><b>${settlement.length}</b><span>Pelunasan / Full</span></div>
    <div class="stat-card"><b>${rupiah(approved.reduce((n,p)=>n+Number(p.amount||0),0))}</b><span>Total Diterima</span></div>
  </div>
  ${unpaidSettlement.length ? `<div class="group-card"><b>⚠️ ${unpaidSettlement.length} pesanan masih memiliki sisa pelunasan.</b></div>` : ""}
  ${list.length ? list.map(card).join("") : `<p class="muted">Tidak ada pembayaran yang cocok.</p>`}`;
}

let paymentSearchTimer;
const paymentSearch = document.querySelector("#paymentSearch");
if (paymentSearch) paymentSearch.addEventListener("input", () => { clearTimeout(paymentSearchTimer); paymentSearchTimer = setTimeout(loadPayments, 180); });

/* ---- Kostum ---- */
const DEFAULT_CATEGORIES = [{slug:"anime",name:"Anime"},{slug:"game",name:"Game"},{slug:"film",name:"Film"},{slug:"original-character",name:"Original Character"},{slug:"lainnya",name:"Lainnya"}];
let photoList = [], sizeRows = [], settingsCache = {};
function pj(v, fb) { try { return JSON.parse(v ?? "") ?? fb; } catch { return fb; } }
function renderPhotos() {
  $("#photoPreview").innerHTML = photoList.map((p, i) => `
    <div class="photo-thumb"><img src="${esc(p.url)}" title="${p.is_ai ? "AI" : "asli"}">
    <button type="button" onclick="rmPhoto(${i})">×</button>
    <label style="position:absolute;bottom:-4px;left:0;font-size:9px;background:#fff;border-radius:4px;padding:0 2px">
    <input type="checkbox" ${p.is_ai ? "checked" : ""} onchange="photoList[${i}].is_ai=this.checked">AI</label></div>`).join("");
}
function rmPhoto(i) { photoList.splice(i, 1); renderPhotos(); }
function addImgUrl() { const u = $("#imgUrl").value.trim(); if (u) { photoList.push({ url: u, is_ai: false }); $("#imgUrl").value = ""; renderPhotos(); } }
async function addPhotoFiles(files) {
  for (const f of Array.from(files || [])) {
    if (!f.type || !f.type.startsWith("image/")) continue;
    photoList.push({ url: await compress(f), is_ai: false });
  }
  renderPhotos();
}
const photoZone = $("#pastePhotoZone");
const photoInput = $("#photoFiles");
photoZone?.addEventListener("click", () => photoInput?.click());
photoInput?.addEventListener("change", async (e) => {
  await addPhotoFiles(e.target.files);
  e.target.value = "";
});
photoZone?.addEventListener("dragover", (e) => { e.preventDefault(); photoZone.classList.add("dragover"); });
photoZone?.addEventListener("dragleave", () => photoZone.classList.remove("dragover"));
photoZone?.addEventListener("drop", async (e) => {
  e.preventDefault(); photoZone.classList.remove("dragover");
  await addPhotoFiles(e.dataTransfer?.files);
});
document.addEventListener("paste", async (e) => {
  const active = document.activeElement;
  const form = $("#costumeForm");
  if (!form || !form.contains(active)) return;
  const items = Array.from(e.clipboardData?.items || []);
  const files = items.map(i => i.kind === "file" ? i.getAsFile() : null).filter(Boolean);
  if (!files.length) return;
  e.preventDefault();
  await addPhotoFiles(files);
});
function renderSizeRows() {
  const el = $("#sizeRows");
  el.innerHTML = sizeRows.map((s,i)=>`<div class="size-row"><input value="${esc(s.size)}" placeholder="Ukuran" oninput="sizeRows[${i}].size=this.value"><input type="number" min="0" value="${s.stock ?? 1}" placeholder="Stok" oninput="sizeRows[${i}].stock=Math.max(0,+this.value||0)"><input type="number" min="0" step="0.1" value="${s.bust ?? ""}" placeholder="Dada cm" oninput="sizeRows[${i}].bust=this.value"><input type="number" min="0" step="0.1" value="${s.waist ?? ""}" placeholder="Pinggang cm" oninput="sizeRows[${i}].waist=this.value"><input type="number" min="0" step="0.1" value="${s.length ?? ""}" placeholder="Panjang cm" oninput="sizeRows[${i}].length=this.value"><input value="${esc(s.note || "")}" placeholder="Catatan" oninput="sizeRows[${i}].note=this.value"><button type="button" class="btn ghost small" onclick="sizeRows.splice(${i},1);renderSizeRows()">Hapus</button></div>`).join("") || `<p class="muted">Belum ada ukuran. Tambahkan row ukuran di atas.</p>`;
}
function addSizeRow() { sizeRows.push({ size: "", stock: 1, bust: "", waist: "", length: "", note: "" }); renderSizeRows(); }
async function loadCostumes() {
  const list = await api("/admin/costumes");
  settingsCache.categories = Array.isArray(settingsCache.categories) ? settingsCache.categories : pj(settingsCache.categories, []);
  if (!settingsCache.categories.length) settingsCache.categories = DEFAULT_CATEGORIES;
  settingsCache.categories = settingsCache.categories.map(c => ({slug:String(c.slug || categorySlug(c.name)), name:String(c.name || c.slug || "").trim()})).filter(c => c.name);
  const currentCategory = $("#fCategory")?.value || "";
  $("#fCategory").innerHTML = `<option value="" disabled>Pilih kategori</option>` + settingsCache.categories.map((c) => `<option value="${esc(c.slug)}">${esc(c.name)}</option>`).join("");
  if (currentCategory && settingsCache.categories.some(c => c.slug === currentCategory)) $("#fCategory").value = currentCategory;
  // Dropdown hanya menampilkan kostum yang sedang aktif agar tidak penuh oleh produk tersembunyi.
  const activeCostumes = list.filter(c => !["hidden", "draft", "maintenance", "unavailable"].includes(String(c.status || "").toLowerCase()));
  $("#mCostume").innerHTML = activeCostumes.length
    ? activeCostumes.map((c) => `<option value="${c.id}">${c.id}. ${esc(c.name)}</option>`).join("")
    : `<option value="" disabled>Tidak ada kostum aktif</option>`;
  $("#costumeTable").innerHTML = `<table>
    <tr><th>Nama</th><th>Series</th><th>Harga</th><th>Status</th><th>Size Guide</th><th></th></tr>
    ${list.map((c) => {
      const hidden = ["hidden", "draft", "maintenance", "unavailable"].includes(String(c.status || "").toLowerCase()) || Number(c.available) === 0;
      return `<tr><td><b>${esc(c.name)}</b><br><small>${esc(c.character)}</small></td><td>${esc(c.series)}</td>
      <td>${rupiah(c.price_per_day)} / 3 hari</td><td>${hidden ? "Tersembunyi" : "Tampil"}</td>
      <td>${c.size_guide_image ? "📏 ada" : `<span title="belum ada">⚠️</span>`}</td>
      <td><button onclick="editCostume(${c.id})">Edit</button> <button onclick="toggleCostumeVisibility(${c.id}, ${hidden})">${hidden ? "Tampilkan" : "Sembunyikan"}</button> <button onclick="delCostume(${c.id})">Hapus</button></td></tr>`;
    }).join("")}</table>`;
  window._costumeList = list;
}
let globalAddonRows = [];
function globalAddonEsc(v){ return esc(v); }
function renderGlobalAddons(items = globalAddonRows) {
  const box = $("#globalAddonRows"); if (!box) return;
  globalAddonRows = Array.isArray(items) ? items.map((x,i)=>({
    id: x?.id || (Date.now()+i), name: String(x?.name || ""), price: Number(x?.price || 0) || 0, image: String(x?.image || ""), active: x?.active !== false
  })) : [];
  if (!globalAddonRows.length) { box.innerHTML = `<div class="addon-empty" style="padding:12px;border:1px dashed #d1d5db;border-radius:10px;color:#6b7280">Belum ada Additional. Klik <b>+ Tambah Additional</b>.</div>`; return; }
  box.innerHTML = globalAddonRows.map((a,i)=>`<div class="global-addon-row" data-index="${i}" style="display:grid;grid-template-columns:90px minmax(0,1fr) 150px 100px auto;gap:10px;align-items:center;border:1px solid #e5e7eb;border-radius:12px;padding:10px">
    <div class="global-addon-image" style="width:80px;height:80px;border-radius:10px;background:#f3f4f6;overflow:hidden;display:flex;align-items:center;justify-content:center">${a.image ? `<img src="${globalAddonEsc(a.image)}" style="width:100%;height:100%;object-fit:cover">` : `<span class="muted" style="font-size:12px">No image</span>`}</div>
    <div><input class="global-addon-name" value="${globalAddonEsc(a.name)}" placeholder="Nama additional"><label style="display:block;margin-top:6px;font-size:12px"><input type="file" class="global-addon-file" accept="image/*"> Ganti gambar</label></div>
    <input type="number" class="global-addon-price" min="0" step="1000" value="${a.price || ""}" placeholder="Harga">
    <label style="font-size:13px"><input type="checkbox" class="global-addon-active" ${a.active ? "checked" : ""}> Aktif</label>
    <button type="button" class="danger global-addon-remove">Hapus</button>
  </div>`).join("");
  box.querySelectorAll('.global-addon-row').forEach((row)=>{
    const i=Number(row.dataset.index);
    row.querySelector('.global-addon-name').addEventListener('input',e=>globalAddonRows[i].name=e.target.value);
    row.querySelector('.global-addon-price').addEventListener('input',e=>globalAddonRows[i].price=Math.max(0,Number(e.target.value)||0));
    row.querySelector('.global-addon-active').addEventListener('change',e=>globalAddonRows[i].active=e.target.checked);
    row.querySelector('.global-addon-file').addEventListener('change',async e=>{
      const f=e.target.files?.[0]; if(!f)return;
      try { globalAddonRows[i].image=await compress(f,700,0.78); renderGlobalAddons(globalAddonRows); } catch(err){ alert('Gambar additional gagal dibaca.'); }
    });
    row.querySelector('.global-addon-remove').addEventListener('click',()=>{ globalAddonRows.splice(i,1); renderGlobalAddons(globalAddonRows); });
  });
}
function addGlobalAddon(){ globalAddonRows.push({id:Date.now(),name:"",price:0,image:"",active:true}); renderGlobalAddons(globalAddonRows); }
async function loadGlobalAddons(){ try { const st=await api('/admin/settings'); let items=[]; try{items=JSON.parse(st.global_addons||'[]')}catch{} renderGlobalAddons(Array.isArray(items)?items:[]); } catch(e){ console.error(e); renderGlobalAddons([]); } }
async function saveGlobalAddons(){
  const btn=$("#saveGlobalAddonBtn"); if(btn){btn.disabled=true;btn.textContent='Menyimpan…';}
  try {
    const clean=globalAddonRows.map((a,i)=>({id:a.id||i+1,name:String(a.name||'').trim(),price:Math.max(0,Number(a.price)||0),image:String(a.image||''),active:a.active!==false})).filter(a=>a.name);
    await api('/admin/settings',{method:'PUT',body:JSON.stringify({global_addons:JSON.stringify(clean)})});
    globalAddonRows=clean; renderGlobalAddons(clean); alert('Additional global berhasil disimpan.');
  } catch(e){ alert('Gagal menyimpan Additional: '+(e.message||'error')); }
  finally{if(btn){btn.disabled=false;btn.textContent='Simpan Additional';}}
}

function syncAddonData() {
  const rows = [...document.querySelectorAll("#addonRows .addon-row")];
  const data = rows.map(row => {
    const name = String(row.querySelector(".addon-name")?.value || "").trim();
    const price = Math.max(0, Number(String(row.querySelector(".addon-price")?.value || "0").replace(/[^0-9.-]/g, "")) || 0);
    return name ? { name, price } : null;
  }).filter(Boolean);
  const hidden = document.querySelector("#additionalItemsData");
  if (hidden) hidden.value = JSON.stringify(data);
  return data;
}

function addAddonRow(item = {}) {
  const box = document.querySelector("#addonRows");
  if (!box) return;
  box.querySelector(".addon-empty")?.remove();

  const safeName = String(item?.name || item?.label || "")
    .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;");

  const price = (() => { const s=String(item?.price ?? "").trim().replace(/[^0-9,.-]/g,""); if(!s)return 0; const n=Number(s.includes(".")&&s.split(".").slice(1).every(p=>/^\\d{3}$/.test(p))?s.replace(/\\./g,""):s.replace(",",".")); return Number.isFinite(n)?Math.max(0,Math.round(n)):0; })();
  const row = document.createElement("div");
  row.className = "addon-row";
  row.style.cssText = "display:grid;grid-template-columns:minmax(0,1fr) 150px auto;gap:8px;align-items:center";
  row.innerHTML = `
    <input type="text" class="addon-name" placeholder="Nama add-on" value="${safeName}">
    <input type="number" class="addon-price" min="0" step="1000" placeholder="Harga" value="${price || ""}">
    <button type="button" class="danger addon-remove">Hapus</button>`;

  box.appendChild(row);
  row.querySelectorAll("input").forEach(input => input.addEventListener("input", syncAddonData));
  row.querySelector(".addon-remove").addEventListener("click", () => {
    row.remove();
    if (!box.querySelector(".addon-row")) {
      box.innerHTML = `<div class="addon-empty" style="padding:10px;border:1px dashed #d1d5db;border-radius:10px;color:#6b7280">
        Belum ada add-on. Klik <b>+ Tambah Add-on</b>.
      </div>`;
    }
    syncAddonData();
  });
  syncAddonData();
}

function renderAddonRows(items = []) {
  const box = document.querySelector("#addonRows");
  if (!box) return;
  box.innerHTML = "";
  const normalized = (Array.isArray(items) ? items : []).map(item => {
    if (typeof item === "string") {
      const [name, price] = item.split("|");
      return { name, price };
    }
    return item;
  }).filter(x => String(x?.name || x?.label || "").trim());

  if (!normalized.length) {
    box.innerHTML = `<div class="addon-empty" style="padding:10px;border:1px dashed #d1d5db;border-radius:10px;color:#6b7280">
      Belum ada add-on. Klik <b>+ Tambah Add-on</b>.
    </div>`;
  } else {
    normalized.forEach(addAddonRow);
  }
  syncAddonData();
}

document.addEventListener("DOMContentLoaded", () => {
  document.querySelector("#addGlobalAddonBtn")?.addEventListener("click", addGlobalAddon);
  document.querySelector("#saveGlobalAddonBtn")?.addEventListener("click", saveGlobalAddons);
  loadGlobalAddons();
});

async function editCostume(id) {
  const c = await api("/admin/costumes/" + id);
  const f = $("#costumeForm");
  f.elements.cid.value = c.id; f.elements.name.value = c.name;
  f.elements.series.value = c.series; f.elements.category.value = c.category || ""; f.elements.gender.value = c.gender;
  f.elements.price_per_day.value = c.price_per_day;
  f.elements.status.value = c.status;
  f.elements.description.value = c.description;
  f.elements.package_items.value = pj(c.package_items, []).join("\n");
  const legacyAccessories = Array.isArray(c.accessories) ? c.accessories : (() => { try { const v = JSON.parse(c.accessories || "[]"); return Array.isArray(v) ? v : []; } catch { return []; } })();
  f.elements.accessories.value = legacyAccessories.filter(x => typeof x === "string").join("\n");
  f.elements.rules_text.value = c.rules_text;
  photoList = [{ url: c.main_image, is_ai: false }, ...(c.gallery || []).map((g) => ({ url: g.url, is_ai: !!g.is_ai }))].filter((p) => p.url);
  try { const det = await api("/admin/costumes/" + id); const mm = new Map((det.size_measurements || []).map(m => [String(m.size), m])); const savedSizes = Array.isArray(det.sizes) ? det.sizes : []; const savedMeasurements = Array.isArray(det.size_measurements) ? det.size_measurements : []; sizeRows = (savedSizes.length ? savedSizes : savedMeasurements).map(sz => { const m = mm.get(String(sz.size)); return { size: sz.size, stock: sz.stock ?? 1, bust: m?.measurements?.bust ?? "", waist: m?.measurements?.waist ?? "", length: m?.measurements?.length ?? "", note: m?.note || "" }; }); } catch {}
  if (!sizeRows.length) sizeRows = [{ size: "S", stock: 1, bust: "", waist: "", length: "", note: "" }];
  renderPhotos(); renderSizeRows(); activateTab("costumes");
}
function resetCostumeForm() {
  const f = $("#costumeForm"); f.reset(); f.elements.cid.value = "";
  photoList = []; sizeRows = []; addSizeRow(); renderPhotos(); renderSizeRows();
}
function toggleAddCategory(force) {
  const box = $("#addCategoryBox");
  if (!box) return;
  const show = typeof force === "boolean" ? force : box.hidden;
  box.hidden = !show;
  if (show) { $("#newCategoryName")?.focus(); } else if ($("#newCategoryName")) { $("#newCategoryName").value = ""; }
}
function categorySlug(name) {
  return String(name || "").trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 50);
}
async function addCategory() {
  const input = $("#newCategoryName");
  const name = input?.value.trim();
  if (!name) return alert("Isi nama kategori dulu.");
  const slug = categorySlug(name);
  if (!slug) return alert("Nama kategori tidak valid.");
  const existingCategories = Array.isArray(settingsCache.categories) ? settingsCache.categories : pj(settingsCache.categories, []);
  const categories = existingCategories.map(c => ({ slug: String(c.slug || categorySlug(c.name)), name: String(c.name || c.slug || "").trim() })).filter(c => c.name);
  if (categories.some(c => c.slug === slug)) {
    $("#fCategory").value = slug;
    toggleAddCategory(false);
    return alert("Kategori tersebut sudah ada.");
  }
  categories.push({ slug, name });
  try {
    const res = await api("/admin/settings", { method: "PUT", body: JSON.stringify({ categories: JSON.stringify(categories) }) });
    if (!res || res.ok === false) throw new Error(res?.error || "Gagal menyimpan kategori");
    settingsCache.categories = JSON.stringify(categories);
    $("#fCategory").innerHTML = `<option value="" disabled>Pilih kategori</option>` + categories.map(c => `<option value="${esc(c.slug)}">${esc(c.name)}</option>`).join("");
    $("#fCategory").value = slug;
    toggleAddCategory(false);
    alert("Kategori berhasil ditambahkan.");
  } catch (e) {
    alert(e.message || "Kategori gagal disimpan.");
  }
}

async function saveCostume(e) {
  e.preventDefault();
  const f = e.target, d = Object.fromEntries(new FormData(f));
  const rows = sizeRows.filter((s) => String(s.size || "").trim());
  if (!rows.length) return alert("Tambahkan minimal satu ukuran.");
  const addonItems = syncAddonData();
  const body = {
    name: d.name, character: "", series: d.series || "", category: d.category || "",
    gender: d.gender, price_per_day: +d.price_per_day || 0, status: d.status,
    description: d.description || "",
    package_items: (d.package_items || "").split("\n").map((x) => x.trim()).filter(Boolean),
    accessories: (d.accessories || "").split("\n").map((x) => x.trim()).filter(Boolean),
    additional_items: addonItems,
    // Simpan langsung sebagai array JSON; jangan bergantung pada hidden textarea.
    addon_items: addonItems,
    rules_text: d.rules_text || "",
    images: photoList, sizes: rows,
    size_measurements: rows.map(r => ({ size:r.size, bust:r.bust, waist:r.waist, length:r.length, note:r.note || "" })),
  };
  try {
    const result = await api(d.cid ? "/admin/costumes/" + d.cid : "/admin/costumes", { method: d.cid ? "PUT" : "POST", body: JSON.stringify(body) });
    if (!result?.ok) throw new Error(result?.error || "Gagal menyimpan kostum");
    alert(d.cid ? "Kostum berhasil diperbarui." : "Kostum berhasil disimpan ke database.");
    resetCostumeForm(); await loadCostumes();
  } catch (err) {
    alert(err?.message || "Kostum gagal disimpan.");
  }
}
async function toggleCostumeVisibility(id, currentlyHidden) {
  try {
    await api("/admin/costumes/" + id, { method: "PUT", body: JSON.stringify({ status: currentlyHidden ? "published" : "hidden" }) });
    await loadCostumes();
  } catch (err) { alert(err?.message || "Status kostum gagal diubah."); }
}
async function delCostume(id) {
  if (!confirm("Hapus kostum ini?")) return;
  try {
    const r = await api("/admin/costumes/" + id, { method: "DELETE" });
    await loadCostumes();
    alert(r?.deactivated ? (r.message || "Kostum dinonaktifkan karena masih punya riwayat.") : "Kostum berhasil dihapus.");
  } catch (err) { alert(err?.message || "Kostum gagal dihapus."); }
}

/* ---- Customer ---- */
async function loadCustomers() {
  const list = await api("/admin/customers");
  $("#custTable").innerHTML = `<table><tr><th>Nama</th><th>Email</th><th>HP</th><th>Terdaftar</th><th></th></tr>
    ${list.map((u) => `<tr><td>${esc(u.name)}${u.must_change_password ? ' <span class="pill st-pending">temp pass</span>' : ""}</td>
    <td>${esc(u.email)}</td><td>${esc(u.phone || "-")}</td><td>${esc(u.created_at)}</td>
    <td><button onclick="makeTemp(${u.id})">Password Sementara</button></td></tr>`).join("")}</table>`;
}
async function makeTemp(id) {
  if (!confirm("Buat password sementara untuk customer ini? Password lama tidak berlaku.")) return;
  const r = await api(`/admin/customers/${id}/temp-password`, { method: "POST" });
  alert(`Password sementara (TAMPIL SEKALI INI):\n\n${r.temp_password}\n\nCustomer wajib menggantinya setelah login.`);
  loadCustomers();
}

/* ---- Reviews ---- */
async function loadReviews() {
  const list = await api("/admin/reviews");
  $("#reviewList").innerHTML = list.length ? list.map((r) => `
    <div class="order-item"><div class="order-head"><b>${esc(r.costume_name)}</b> • ${"⭐".repeat(r.rating)} • ${esc(r.user_name)}
      <span class="pill ${r.status === "approved" ? "st-done" : r.status === "rejected" ? "st-cancelled" : "st-pending"}">${r.status}</span></div>
      <p>${esc(r.text)}</p><p class="muted">${esc(r.order_code)} • ${esc(r.created_at)}</p>
      ${r.status === "pending" ? `<div class="stack"><button onclick="setReview(${r.id},'approved')">✅ Approve</button>
      <button onclick="setReview(${r.id},'rejected')">❌ Reject</button></div>` : ""}</div>`).join("") : `<p class="muted">Belum ada review.</p>`;
}
async function setReview(id, status) { await api("/admin/reviews/" + id, { method: "PUT", body: JSON.stringify({ status }) }); loadReviews(); }

/* ---- Maintenance ---- */
async function loadMaint() {
  const list = await api("/admin/maintenance");
  $("#maintList").innerHTML = list.length ? list.map((m) => `
    <div class="row"><b>${esc(m.costume_name)}</b> ${esc(m.start_date)} s/d ${esc(m.end_date)} ${esc(m.note)}
    <button onclick="delMaint(${m.id})">Hapus</button></div>`).join("") : `<p class="muted">Tidak ada jadwal maintenance.</p>`;
}
async function addMaint(e) {
  e.preventDefault();
  const d = Object.fromEntries(new FormData(e.target));
  await api("/admin/maintenance", { method: "POST", body: JSON.stringify(d) });
  e.target.reset(); loadMaint();
}
async function delMaint(id) { await api("/admin/maintenance/" + id, { method: "DELETE" }); loadMaint(); }

/* ---- KTP ---- */
async function loadKtp() {
  const list = await api("/admin/ktp");
  $("#ktpGrid").innerHTML = list.length ? list.map((k) => `
    <div class="ktp-card"><b>${esc(k.full_name)}</b> <small>(${esc(k.order_code || "-")})</small>
    <p>NIK: <b>${esc(k.nik_masked)}</b></p>
    <img src="${esc(k.image)}">
    <div class="stack"><select data-id="${k.id}">
      ${["pending","approved","rejected"].map((s) => `<option value="${s}" ${s === k.status ? "selected" : ""}>${s}</option>`).join("")}
    </select><button onclick="setKtp(${k.id})">Simpan</button></div></div>`).join("") : `<p class="muted">Belum ada data KTP.</p>`;
}
async function setKtp(id) {
  const status = document.querySelector(`select[data-id="${id}"]`).value;
  await api("/admin/ktp/" + id, { method: "PUT", body: JSON.stringify({ status }) });
  loadKtp();
}

/* ---- Centralized Settings ---- */
const SETTINGS_SECTIONS = [
  { id:"identity", title:"Identitas", desc:"Nama, logo, warna, dan identitas website.", fields:[
    ["site_title","Nama Website","text"],["site_description","Deskripsi Website","ta","full"],["brand_1","Brand 1","text"],["brand_2","Brand 2","text"],["logo_url","Logo COSRENT","logo","full"],["favicon_url","Favicon URL","url"],["primary_color","Warna Utama","text"],["accent_color","Warna Aksen","text"]
  ]},
  { id:"homepage", title:"Homepage", desc:"Teks utama yang tampil di halaman depan.", fields:[
    ["hero_eyebrow","Teks Kecil Hero","text"],["hero_title_1","Judul Hero","text"],["hero_title_2","Judul Hero Baris 2","text"],["hero_copy","Deskripsi Hero","ta","full"],
    ["btn_primary_text","Tombol Utama","text"],["btn_primary_href","Link Tombol Utama","text"],["btn_ghost_text","Tombol Kedua","text"],["btn_ghost_href","Link Tombol Kedua","text"],["catalog_title","Judul Katalog","text"],["how_title","Judul Cara Sewa","text"],["rules_title","Judul Aturan","text"],["fines_title","Judul Denda","text"],["footer_description","Deskripsi Footer","ta","full"]
  ]},
  { id:"contact", title:"Kontak", desc:"Informasi yang bisa dihubungi customer.", fields:[
    ["instagram","Instagram","text"],["email","Email","email"],["address","Alamat","ta","full"],["operating_hours","Jam Operasional","text"]
  ]},
  { id:"rental", title:"Rental", desc:"Aturan dan biaya dasar rental.", fields:[
    ["minimum_rental_days","Minimal Sewa (hari)","number"],["maximum_rental_days","Maksimal Sewa (hari)","number"],["deposit_amount","Deposit (Rp)","number"],["fine_per_day","Denda Terlambat / Hari (Rp)","number"],["minimum_booking_notice","Minimal Booking Sebelum (hari)","number"],
    ["damage_policy","Aturan Kerusakan","ta","full"],["lost_item_policy","Aturan Kehilangan","ta","full"],["cancellation_policy","Aturan Pembatalan","ta","full"],["reschedule_policy","Aturan Reschedule","ta","full"]
  ]},
  { id:"payment", title:"Pembayaran", desc:"Atur QRIS dan catatan pembayaran tanpa mengedit kode.", fields:[
    ["payment_note","Catatan Pembayaran","ta","full"]
  ], extra:"qris"},
  { id:"ai", title:"AI Customer", desc:"Konfigurasi AI yang dipakai customer. Tidak ada tool AI di dashboard admin.", fields:[
    ["ai_enabled","AI Aktif","check"],["customer_ai_enabled","AI Customer Aktif","check"],["ai_provider","Provider AI","select","","mistral"],["ai_api_key","Mistral API Key","secret"],["ai_base_url","AI API URL","url"],["ai_model","Model AI","text"],["ai_temperature","Temperature","number"],["ai_max_tokens","Max Response Token","number"],["ai_system_prompt","Instruksi Sistem AI","ta","full"],["ai_customer_prompt","Instruksi Customer AI","ta","full"]
  ]},
  { id:"ktp", title:"KTP", desc:"Aturan KTP dan masking NIK.", fields:[
    ["ktp_required","KTP Wajib","check"],["nik_masking","Masking NIK","check"],["require_ktp_before_booking","KTP Sebelum Booking","check"],["require_ktp_before_payment","KTP Sebelum Pembayaran","check"]
  ]},
  { id:"legal", title:"Halaman Legal", desc:"Isi halaman publik yang bisa diubah Admin.", fields:[
    ["terms_content","Syarat & Ketentuan","ta","full"],["rules_content","Rules","ta","full"],["privacy_content","Privacy Policy","ta","full"],["about_content","About","ta","full"],["contact_content","Contact","ta","full"]
  ]},
  { id:"maintenance", title:"Maintenance", desc:"Tutup sementara website jika diperlukan.", fields:[
    ["maintenance_mode","Mode Maintenance","check"],["maintenance_message","Pesan Maintenance","ta","full"]
  ]}
];
let settingsSnapshot = {};
let settingsSection = "identity";
let settingsDirty = false;
function settingsValue(v) { return v == null ? "" : String(v); }
const SETTING_EXAMPLES = {
  site_title:"Contoh: COSRENT", site_description:"Contoh: Rental costume cosplay terpercaya.", brand_1:"Contoh: COS", brand_2:"Contoh: RENT",
  logo_url:"Upload logo COSRENT, lalu crop sebelum disimpan.", favicon_url:"Contoh: https://domain.com/favicon.ico", primary_color:"Contoh: #111111", accent_color:"Contoh: #6c5ce7",
  hero_eyebrow:"Contoh: RENTAL COSTUME COSPLAY", hero_title_1:"Contoh: Cosplay jadi lebih mudah.", hero_title_2:"Contoh: Sewa tanpa ribet.", hero_copy:"Contoh: Cari costume, cek tanggal dan ongkir, lalu sewa.",
  btn_primary_text:"Contoh: Cari Costume", btn_primary_href:"Contoh: #catalog", btn_ghost_text:"Contoh: Cara Sewa", btn_ghost_href:"Contoh: #how",
  catalog_title:"Contoh: Costume Populer", how_title:"Contoh: Cara Sewa", rules_title:"Contoh: Aturan Rental", fines_title:"Contoh: Denda", footer_description:"Contoh: Rental costume cosplay dengan proses sederhana.",
  instagram:"Contoh: @cosrent.id", email:"Contoh: hello@cosrent.id", address:"Contoh: Bekasi, Jawa Barat", operating_hours:"Contoh: Senin-Sabtu, 09.00-18.00",
  minimum_rental_days:"Contoh: 1", maximum_rental_days:"Contoh: 7", deposit_amount:"Contoh: 50000", fine_per_day:"Contoh: 25000", minimum_booking_notice:"Contoh: 1",
  damage_policy:"Contoh: Kerusakan dikenakan biaya sesuai tingkat kerusakan.", lost_item_policy:"Contoh: Barang hilang diganti sesuai nilai barang.", cancellation_policy:"Contoh: Pembatalan maksimal 1 hari sebelum sewa.", reschedule_policy:"Contoh: Reschedule maksimal 1 kali.",
  payment_note:"Contoh: Pembayaran diverifikasi maksimal 1x24 jam.", ai_provider:"Gunakan Mistral.", ai_base_url:"Biarkan kosong untuk API Mistral resmi.", ai_model:"ministral-3b-latest", ai_temperature:"Contoh: 0.3", ai_max_tokens:"Contoh: 700", ai_system_prompt:"Contoh: Jawab berdasarkan data COSRENT.", ai_customer_prompt:"Contoh: Jawab singkat, jelas, dan gunakan data nyata COSRENT.",
  terms_content:"Contoh: Ketentuan rental, pembayaran, pembatalan, pengembalian, kerusakan, dan tanggung jawab pengguna.", rules_content:"Contoh: Dilarang merusak, menghilangkan, atau menyalahgunakan kostum.", privacy_content:"Contoh: Data digunakan untuk akun, rental, pembayaran, dan komunikasi.", about_content:"Contoh: COSRENT adalah layanan rental costume cosplay.", contact_content:"Contoh: Hubungi COSRENT melalui email atau kontak yang tersedia.", maintenance_message:"Contoh: COSRENT sedang melakukan pemeliharaan. Silakan kembali beberapa saat lagi."
};
const CHECK_EXAMPLES = {ai_enabled:"Aktifkan jika COSRENT AI digunakan.",customer_ai_enabled:"Aktifkan agar customer dapat memakai COSRENT AI.",ktp_required:"Aktifkan jika KTP wajib sebelum rental.",nik_masking:"Sebaiknya tetap aktif agar NIK customer selalu tersamarkan.",require_ktp_before_booking:"Aktifkan jika KTP harus ada sebelum booking.",require_ktp_before_payment:"Aktifkan jika KTP harus ada sebelum pembayaran.",maintenance_mode:"Aktifkan hanya ketika website ingin ditutup sementara."};
function settingField([key,label,type,wide,options]) {
  const v = settingsCache[key] ?? "";
  const configured = settingsCache[key + "_configured"];
  const example = SETTING_EXAMPLES[key] || "";
  if (type === "check") return `<label class="settings-check ${wide === "full" ? "full" : ""}"><input data-setting="${key}" type="checkbox" ${String(v)==="1" || String(v)==="true" ? "checked" : ""}> <span>${esc(label)}<small class="settings-help">${esc(CHECK_EXAMPLES[key] || "Aktifkan jika fitur ini diperlukan.")}</small></span></label>`;
  if (type === "ta") return `<div class="settings-field ${wide === "full" ? "full" : ""}"><label>${esc(label)}</label><textarea data-setting="${key}" placeholder="${esc(example)}">${esc(v)}</textarea>${example ? `<span class="settings-help">${esc(example)}</span>` : ""}</div>`;
  if (type === "select") {
    const opts = String(options || "").split("|").filter(Boolean);
    return `<div class="settings-field"><label>${esc(label)}</label><select data-setting="${key}">${opts.map(o=>`<option value="${esc(o)}" ${String(v)===String(o)?"selected":""}>${esc(o)}</option>`).join("")}</select></div>`;
  }
  if (type === "logo") {
    return `<div class="settings-field ${wide === "full" ? "full" : ""}">
      <label>${esc(label)}</label>
      <input type="hidden" data-setting="${key}" id="logoSettingValue" value="${esc(v)}">
      <div class="logo-upload-box">
        <div class="logo-preview" id="logoPreview">${v ? `<img src="${esc(v)}" alt="Logo COSRENT">` : `<span>Belum ada logo</span>`}</div>
        <div class="logo-upload-actions">
          <button type="button" class="btn ghost" id="logoChooseBtn">Upload Logo</button>
          <button type="button" class="btn ghost" id="logoPasteBtn">Paste / Ctrl+V</button>
          ${v ? `<button type="button" class="btn ghost danger" id="logoRemoveBtn">Hapus</button>` : ""}
        </div>
        <small class="settings-help">Upload gambar → crop dulu → simpan. Tidak perlu URL/domain.</small>
        <input id="logoFileInput" type="file" accept="image/*" hidden>
      </div>
    </div>`;
  }
  if (type === "secret") return `<div class="settings-field"><label>${esc(label)}</label><input data-setting="${key}" type="password" autocomplete="new-password" placeholder="${configured ? "Masukkan key baru untuk mengganti" : "Masukkan API key"}"><span class="secret-status">${configured ? "● Sudah tersimpan, nilai disembunyikan" : "○ Belum dikonfigurasi"}</span></div>`;
  return `<div class="settings-field ${wide === "full" ? "full" : ""}"><label>${esc(label)}</label><input data-setting="${key}" type="${type === "number" ? "number" : type}" value="${esc(v)}" placeholder="${esc(example)}"></div>`;
}

let logoCropState = null;
function openLogoCrop(file) {
  if (!file || !String(file.type || "").startsWith("image/")) return;
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      logoCropState = { img, zoom: 1, x: 0, y: 0, dragging: false, sx: 0, sy: 0, ox: 0, oy: 0 };
      const modal = document.createElement("div");
      modal.id = "logoCropModal";
      modal.className = "logo-crop-modal";
      modal.innerHTML = `<div class="logo-crop-card">
        <div class="logo-crop-head"><b>Crop Logo COSRENT</b><button type="button" class="btn ghost" id="logoCropClose">Tutup</button></div>
        <div class="logo-crop-stage"><canvas id="logoCropCanvas" width="360" height="360"></canvas></div>
        <label class="settings-field" style="margin-top:12px">Zoom <input id="logoCropZoom" type="range" min="1" max="3" step="0.01" value="1"></label>
        <div class="logo-crop-actions"><button type="button" class="btn ghost" id="logoCropCancel">Batal</button><button type="button" class="btn primary" id="logoCropApply">Pakai Logo</button></div>
        <small class="settings-help">Geser gambar di kotak crop untuk menentukan posisi logo.</small>
      </div>`;
      document.body.appendChild(modal);
      const canvas=modal.querySelector("#logoCropCanvas"), ctx=canvas.getContext("2d");
      const draw=()=>{
        const S=canvas.width, base=Math.max(S/img.width,S/img.height), sc=base*logoCropState.zoom;
        const w=img.width*sc,h=img.height*sc;
        ctx.clearRect(0,0,S,S); ctx.fillStyle="#f3f3f7"; ctx.fillRect(0,0,S,S);
        ctx.drawImage(img,(S-w)/2+logoCropState.x,(S-h)/2+logoCropState.y,w,h);
      };
      const close=()=>{ modal.remove(); logoCropState=null; };
      modal.querySelector("#logoCropClose").onclick=close; modal.querySelector("#logoCropCancel").onclick=close;
      modal.querySelector("#logoCropZoom").oninput=e=>{logoCropState.zoom=Number(e.target.value);draw();};
      canvas.onpointerdown=e=>{canvas.setPointerCapture(e.pointerId);logoCropState.dragging=true;logoCropState.sx=e.clientX;logoCropState.sy=e.clientY;logoCropState.ox=logoCropState.x;logoCropState.oy=logoCropState.y;};
      canvas.onpointermove=e=>{if(!logoCropState?.dragging)return;logoCropState.x=logoCropState.ox+e.clientX-logoCropState.sx;logoCropState.y=logoCropState.oy+e.clientY-logoCropState.sy;draw();};
      canvas.onpointerup=()=>{if(logoCropState)logoCropState.dragging=false;};
      modal.querySelector("#logoCropApply").onclick=()=>{
        const out=document.createElement("canvas"); out.width=512; out.height=512; const o=out.getContext("2d");
        const S=canvas.width,base=Math.max(S/img.width,S/img.height),sc=base*logoCropState.zoom,w=img.width*sc,h=img.height*sc;
        o.fillStyle="#fff";o.fillRect(0,0,512,512);
        o.drawImage(img,(S-w)/2+logoCropState.x,(S-h)/2+logoCropState.y,w,h,0,0,512,512);
        const data=out.toDataURL("image/webp",0.9);
        const input=document.querySelector("#logoSettingValue"); if(input){input.value=data;input.dispatchEvent(new Event("input",{bubbles:true}));}
        const prev=document.querySelector("#logoPreview"); if(prev)prev.innerHTML=`<img src="${esc(data)}" alt="Logo COSRENT">`;
        markSettingsDirty(true); close();
      };
      draw();
    };
    img.src=reader.result;
  };
  reader.readAsDataURL(file);
}
function initLogoControls() {
  const choose=document.querySelector("#logoChooseBtn"), file=document.querySelector("#logoFileInput"), paste=document.querySelector("#logoPasteBtn"), remove=document.querySelector("#logoRemoveBtn");
  if(choose&&file) choose.onclick=()=>file.click();
  if(file) file.onchange=e=>openLogoCrop(e.target.files?.[0]);
  if(paste) paste.onclick=()=>alert("Tekan Ctrl+V setelah kotak crop dibuka, atau gunakan Upload Logo.");
  if(remove) remove.onclick=()=>{const input=document.querySelector("#logoSettingValue");if(input){input.value="";input.dispatchEvent(new Event("input",{bubbles:true}));}const p=document.querySelector("#logoPreview");if(p)p.innerHTML="<span>Belum ada logo</span>";remove.remove();};
}
document.addEventListener("paste",e=>{
  if(settingsSection!=="identity") return;
  const item=[...(e.clipboardData?.items||[])].find(x=>x.type?.startsWith("image/"));
  if(item){e.preventDefault();openLogoCrop(item.getAsFile());}
});

function renderSettingsNav() {
  $("#settingsNav").innerHTML = SETTINGS_SECTIONS.map(x => `<button type="button" class="${x.id===settingsSection?"active":""}" onclick="switchSettingsSection('${x.id}')">${esc(x.title)}</button>`).join("");
}
function renderSettingsSection() {
  const sec = SETTINGS_SECTIONS.find(x => x.id === settingsSection) || SETTINGS_SECTIONS[0];
  let html = `<div class="settings-card"><h3>${esc(sec.title)}</h3><p class="muted">${esc(sec.desc)}</p><div class="settings-grid">${sec.fields.map(settingField).join("")}</div>`;
  if (sec.extra === "qris") html += `<div id="qrisSettingsBox" class="qris-settings-box"><p class="muted">Memuat pengaturan QRIS...</p></div>`;
  html += `</div><div class="settings-actions"><button type="button" class="btn ghost" onclick="resetSettingsSection()">Reset</button><button class="btn primary">Simpan Perubahan</button></div>`;
  $("#settingsForm").innerHTML = html;
  $("#settingsForm").querySelectorAll("[data-setting]").forEach(el => el.addEventListener("input", () => markSettingsDirty(true)));
  $("#settingsForm").querySelectorAll("[data-setting]").forEach(el => el.addEventListener("change", () => markSettingsDirty(true)));
  markSettingsDirty(settingsDirty);
  initLogoControls();
  if (sec.id === "ai") {
    const box = document.createElement("div");
    box.className = "settings-card ai-key-status-card";
    box.innerHTML = `<h3>Keamanan AI</h3><p class="muted">API key disimpan terenkripsi. Kunci enkripsi tidak disimpan di database.</p><div class="secret-status">${settingsCache.settings_encryption_key_configured ? "● SETTINGS_ENCRYPTION_KEY sudah dikonfigurasi" : "○ SETTINGS_ENCRYPTION_KEY belum dikonfigurasi — wajib diisi sebagai Cloudflare Secret sebelum menyimpan API key."}</div><small class="settings-help">Secret name: <b>SETTINGS_ENCRYPTION_KEY</b></small>`;
    $("#settingsForm").insertBefore(box, $("#settingsForm").querySelector(".settings-actions"));
  }
  if (sec.extra === "qris") loadQrisSettings();
}
async function loadQrisSettings() {
  const box = $("#qrisSettingsBox");
  if (!box) return;
  try {
    const list = await api("/admin/payment-methods");
    let q = list.find(x => String(x.type).toLowerCase() === "qris" || String(x.name).toLowerCase() === "qris");
    if (!q) {
      await api("/admin/payment-methods", { method:"POST", body:JSON.stringify({name:"QRIS", type:"qris", account_number:"", account_name:"", instructions:"", qr_image:"", is_active:1, sort_order:0}) });
      q = (await api("/admin/payment-methods")).find(x => String(x.type).toLowerCase() === "qris");
    }
    box.innerHTML = `<div class="qris-settings-grid">
      <div><label class="settings-field"><b>Nama Metode</b><input id="qrisName" value="${esc(q?.name || "QRIS")}" placeholder="Contoh: QRIS"></label>
      <label class="settings-field"><b>Nomor / ID Pembayaran</b><input id="qrisAccount" value="${esc(q?.account_number || "")}" placeholder="Contoh: QRIS merchant"></label>
      <label class="settings-field"><b>Nama Pemilik</b><input id="qrisOwner" value="${esc(q?.account_name || "")}" placeholder="Contoh: COSRENT"></label>
      <label class="settings-field"><b>Instruksi</b><textarea id="qrisInstruction" placeholder="Contoh: Scan QR lalu upload bukti pembayaran.">${esc(q?.instructions || "")}</textarea></label>
      <label class="settings-check"><input id="qrisActive" type="checkbox" ${q?.is_active ? "checked" : ""}><span>QRIS aktif<small class="settings-help">Jika aktif, QRIS dapat dipilih customer.</small></span></label>
      <div class="stack" style="margin-top:8px"><input id="qrisFile" type="file" accept="image/*"><button type="button" class="btn ghost" onclick="saveQrisSettings(${q?.id || 0})">Simpan QRIS</button></div></div>
      <div class="qris-preview"><b>Preview QRIS</b><div id="qrisPreview">${q?.qr_image ? `<img src="${esc(q.qr_image)}" alt="QRIS">` : `<div class="qris-empty">Belum ada foto QRIS</div>`}</div></div>
    </div>`;
  } catch (e) { box.innerHTML = `<p class="muted">QRIS belum dapat dimuat. ${esc(e.message || "Coba lagi")}</p>`; }
}
async function saveQrisSettings(id) {
  if (!id) return showSettingsToast("✕ Metode QRIS belum tersedia.", false);
  const btn = document.querySelector('#qrisSettingsBox button'); if (btn) { btn.disabled=true; btn.textContent="Menyimpan…"; }
  try {
    let qr_image = "";
    const current = (await api("/admin/payment-methods")).find(x => x.id === id);
    qr_image = current?.qr_image || "";
    const file = $("#qrisFile")?.files?.[0];
    if (file) qr_image = await compress(file, 1000, 0.82);
    await api("/admin/payment-methods/"+id, { method:"PUT", body:JSON.stringify({name:$("#qrisName").value.trim() || "QRIS", type:"qris", account_number:$("#qrisAccount").value.trim(), account_name:$("#qrisOwner").value.trim(), instructions:$("#qrisInstruction").value.trim(), qr_image, is_active:$("#qrisActive").checked, sort_order:current?.sort_order || 0}) });
    showSettingsToast("✓ QRIS berhasil disimpan.", true); await loadQrisSettings();
  } catch (e) { showSettingsToast("✕ QRIS gagal disimpan: " + (e.message || "error"), false); }
  finally { if (btn) { btn.disabled=false; btn.textContent="Simpan QRIS"; } }
}
function markSettingsDirty(v) { settingsDirty = !!v; $("#settingsDirty").hidden = !settingsDirty; }
function switchSettingsSection(id) { if (settingsDirty && !confirm("Perubahan belum disimpan. Pindah section dan buang perubahan?")) return; settingsDirty=false; settingsSection=id; renderSettingsNav(); renderSettingsSection(); }
function collectSettingsSection() {
  const body = {};
  $("#settingsForm").querySelectorAll("[data-setting]").forEach(el => { body[el.dataset.setting] = el.type === "checkbox" ? (el.checked ? "1" : "0") : el.value; });
  return body;
}
async function saveSettings(e) {
  e.preventDefault();
  const btn = e.submitter || e.target.querySelector('button[type="submit"],button.btn.primary');
  const body = collectSettingsSection();
  if (btn) { btn.disabled = true; btn.dataset.oldText = btn.textContent; btn.textContent = "Menyimpan…"; }
  try {
    const res = await api("/admin/settings", { method:"PUT", body:JSON.stringify(body) });
    if (!res || res.error) throw new Error(res?.error || "Server menolak perubahan");
    Object.assign(settingsCache, body); settingsSnapshot = JSON.parse(JSON.stringify(settingsCache)); markSettingsDirty(false);
    showSettingsToast("✓ Pengaturan berhasil disimpan.", true); renderSettingsSection();
  } catch (err) {
    showSettingsToast("✕ Pengaturan gagal disimpan: " + (err.message || "kesalahan server"), false);
  } finally { if (btn) { btn.disabled = false; btn.textContent = btn.dataset.oldText || "Simpan Perubahan"; } }
}
function showSettingsToast(message, ok) {
  let el = document.querySelector("#settingsToast");
  if (!el) { el = document.createElement("div"); el.id = "settingsToast"; document.body.appendChild(el); }
  el.textContent = message; el.className = ok ? "settings-toast ok" : "settings-toast error";
  clearTimeout(window.__settingsToastTimer); window.__settingsToastTimer = setTimeout(() => el.remove(), 3500);
}
function resetSettingsSection() { if (!confirm("Reset perubahan section ini?")) return; settingsCache = JSON.parse(JSON.stringify(settingsSnapshot)); markSettingsDirty(false); renderSettingsSection(); }
async function loadSettings() {
  try {
    const data = await api("/admin/settings");
    if (!data || data.error) throw new Error(data?.error || "Settings tidak dapat dimuat");
    settingsCache = data;
    settingsCache.categories = Array.isArray(settingsCache.categories) ? settingsCache.categories : pj(settingsCache.categories, []);
    if (!settingsCache.categories.length) settingsCache.categories = DEFAULT_CATEGORIES;
    if (settingsCache.ai_enabled == null) settingsCache.ai_enabled = "1";
    if (settingsCache.customer_ai_enabled == null) settingsCache.customer_ai_enabled = "1";
    if (settingsCache.ai_provider == null || !settingsCache.ai_provider) settingsCache.ai_provider = "mistral";
    if (settingsCache.ai_model == null || !settingsCache.ai_model) settingsCache.ai_model = "ministral-3b-latest";
    if (settingsCache.ai_temperature == null || settingsCache.ai_temperature === "") settingsCache.ai_temperature = "0.3";
    if (settingsCache.ai_max_tokens == null || settingsCache.ai_max_tokens === "") settingsCache.ai_max_tokens = "700";
    settingsSnapshot = JSON.parse(JSON.stringify(settingsCache)); renderSettingsNav(); renderSettingsSection();
  } catch (e) { showSettingsToast("✕ Gagal memuat pengaturan: " + (e.message || "error"), false); }
}
window.addEventListener("beforeunload", e => { if (settingsDirty) { e.preventDefault(); e.returnValue = ""; } });

async function changeAdminPass(e) {
  e.preventDefault();
  const d = Object.fromEntries(new FormData(e.target));
  const r = await fetch("/api/profile/password", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(d) }).then((x) => x.json());
  alert(r.ok ? "Password diganti ✅" : r.error || "Gagal");
  if (r.ok) e.target.reset();
}

/* ---- Order detail click handler (delegated, works even after table rerender) ---- */
document.addEventListener("click", (e) => {
  const btn = e.target.closest?.(".order-detail-btn");
  if (!btn) return;
  e.preventDefault();
  e.stopPropagation();
  const id = btn.getAttribute("data-order-id");
  if (id) window.openOrder(id);
});

/* ---- Init ---- */
 $("#orderSearch").addEventListener("input", () => loadOrders());
async function loadAll() {
  await loadSettings();
  await loadCostumes();
  loadDash(); loadOrders(); loadPayments(); loadCustomers(); loadReviews(); loadMaint(); loadKtp();
}
(async () => {
  if ((await api("/admin/check").catch(() => null))?.ok) return showPanel();
  showLogin();
})();