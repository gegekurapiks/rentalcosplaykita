const $ = (s) => document.querySelector(s);
const esc = (t) => String(t ?? "").replace(/[&<>"']/g, (c) => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
const rupiah = (n) => "Rp" + Number(n || 0).toLocaleString("id-ID");
const STATUS_ID = { pending_payment:"Menunggu Pembayaran", payment_review:"Verifikasi Pembayaran", paid:"Dibayar", preparing:"Disiapkan", shipped:"Dikirim", rented:"Sedang Disewa", returned:"Dikembalikan", inspection:"Pemeriksaan", completed:"Selesai", cancelled:"Dibatalkan" };
const PAY_ID = { pending:"Menunggu verifikasi", approved:"Disetujui", rejected:"Ditolak" };
const PAYMENT_STATUS_ID = { unpaid: "Belum dibayar", pending: "Menunggu verifikasi", partial: "DP 50% Dibayar", paid: "Lunas / Full Payment" };

const DEFAULTS = {
  site_description: "Sewa kostum cosplay dengan proses yang simpel, jelas, dan aman.", logo_url: "", favicon_url: "", instagram: "", email: "", address: "", operating_hours: "", footer_description: "Sewa kostum cosplay dengan proses yang simpel, jelas, dan aman.",
  terms_content: "Ketentuan penggunaan\n\nRental\n\nPembayaran\n\nPembatalan\n\nPengembalian\n\nKerusakan\n\nTanggung jawab pengguna.", rules_content: "Peraturan penggunaan website\n\nPeraturan rental\n\nLarangan\n\nKetentuan transaksi.", privacy_content: "Data yang dikumpulkan\n\nPenggunaan data\n\nPenyimpanan data\n\nCookies/localStorage\n\nKontak.", about_content: "COSRENT adalah layanan rental kostum cosplay.", contact_content: "Hubungi COSRENT melalui informasi kontak yang tersedia.",
  site_title: "COSRENT — Sewa Kostum Cosplay", brand_1: "COS", brand_2: "RENT",
  nav_links: JSON.stringify([{label:"Beranda",href:"/"},{label:"Katalog",href:"/#/catalog"},{label:"Cara Sewa",href:"/#how"},{label:"Aturan",href:"/rules.html"},{label:"S&K",href:"/terms.html"},{label:"Privacy",href:"/privacy.html"}]),
  hero_eyebrow: "RENTAL COSTUME COSPLAY", hero_title_1: "Cosplay jadi", hero_title_2: "lebih mudah.",
  hero_copy: "Sewa kostum cosplay favoritmu dengan proses yang simpel, jelas, dan aman.",
  btn_primary_text: "Lihat Kostum", btn_primary_href: "#/catalog", btn_ghost_text: "Cara Sewa", btn_ghost_href: "#how",
  featured_label: "KOSTUM UNGGULAN", catalog_eyebrow: "KOLEKSI", catalog_title: "Pilih kostum favoritmu",
  how_eyebrow: "MUDAH & JELAS", how_title: "Cara Sewa", rules_eyebrow: "SEBELUM MENYEWA", rules_title: "Aturan & Ketentuan",
  steps_list: JSON.stringify([{number:"01",title:"Pilih kostum",description:"Cari karakter dan ukuran yang sesuai dari katalog."},{number:"02",title:"Tentukan tanggal",description:"Pilih tanggal kirim, pakai, dan pengembalian."},{number:"03",title:"Lengkapi data",description:"Isi data penyewa dan KTP sesuai kebutuhan."},{number:"04",title:"Bayar & tunggu",description:"Lakukan pembayaran manual lalu tunggu verifikasi admin."}]),
  terms_list: JSON.stringify(["Data penyewa harus benar dan dapat dipertanggungjawabkan.","Kostum dikembalikan sesuai tanggal yang dipilih.","Periksa isi paket saat kostum diterima."]),
  rules_list: JSON.stringify(["Gunakan kostum dengan wajar dan sesuai peruntukannya.","Jaga kostum dari noda, kerusakan, dan kehilangan.","Hubungi admin jika ada kendala selama masa sewa."]),
  categories: JSON.stringify([{slug:"anime",name:"Anime"},{slug:"game",name:"Game"},{slug:"film",name:"Film"},{slug:"original-character",name:"Original Character"},{slug:"lainnya",name:"Lainnya"}]), fine_per_day: "0", deposit_amount: "0", fine_damage_text: "", fine_lost_text: "", fines_note: "", ktp_required: "1", ai_enabled: "1", customer_ai_enabled: "1", ai_provider: "groq", ai_model: "openai/gpt-oss-20b"
};
const state = { user: null, settings: {...DEFAULTS}, costumes: [], cart: JSON.parse(localStorage.getItem("cosrent_cart_v2") || "[]"), cartDraftDates: JSON.parse(localStorage.getItem("cosrent_cart_dates_v1") || "{}") };
function saveCart(){ localStorage.setItem("cosrent_cart_v2", JSON.stringify(state.cart || [])); localStorage.setItem("cosrent_cart_dates_v1", JSON.stringify(state.cartDraftDates || {})); updateCartBadge(); }
function updateCartBadge(){ const n=(state.cart||[]).reduce((sum,x)=>sum+Math.max(1,Number(x.quantity||1)),0); const el=$("#cartCount"); if(el) el.textContent=n; const fab=$("#cartFabCount"); if(fab) fab.textContent=n; }
function cartSubtotal(){ return (state.cart||[]).reduce((sum,item)=> sum + Number(item.price_per_day||0)*Math.max(1,Math.ceil(Number(item.days||3)/3))*Math.max(1,Number(item.quantity||1)) + (item.addons||[]).reduce((a,x)=>a+Number(x.price||0),0),0); }
function addCostumeToCart(c){
  const found=state.cart.find(x=>x.type==='costume' && String(x.costume_id)===String(c.id));
  if(found) found.quantity=Math.max(1,Number(found.quantity||1)+1);
  else state.cart.push({type:'costume',costume_id:c.id,name:c.name,image:c.main_image||c.image||'',price_per_day:Number(c.price_per_day||0),quantity:1,addons:[],additional:Array.isArray(c.additional)?c.additional:[]});
  saveCart(); closeModal(); location.hash='#/cart';
}
function removeCartItem(i){ state.cart.splice(i,1); saveCart(); renderCart(); }
function changeCartQty(i,delta){ const x=state.cart[i]; if(!x)return; x.quantity=Math.max(1,Number(x.quantity||1)+delta); saveCart(); renderCart(); }
let cartAddonTarget=-1;
function openCartAdditional(i){
  const item=state.cart[i]; if(!item) return;
  cartAddonTarget=i;
  const list=Array.isArray(item.additional)?item.additional:[];
  $("#modalBody").innerHTML=`<h2>Tambah Additional</h2><p class="muted">Untuk <b>${esc(item.name)}</b></p>${list.length?`<div class="additional-search"><span>⌕</span><input id="cartAddonSearch" type="search" placeholder="Cari additional..." autocomplete="off"></div><div class="cart-addon-picker" id="cartAddonPicker">${list.map((a,j)=>`<button type="button" class="cart-addon-choice" onclick="addAddonToCart(${i},${j})"><span class="addon-image">${a.image?`<img src="${esc(a.image)}" alt="${esc(a.name)}">`:'+'}</span><span><b>${esc(a.name)}</b><small>${rupiah(a.price)}</small></span><strong>+ Tambah</strong></button>`).join('')}</div>`:`<p class="muted">Belum ada Additional yang tersedia.</p>`}<button class="btn ghost" type="button" onclick="closeModal()">Selesai</button>`;
  $("#modal").classList.remove('hidden');
  const search=$("#cartAddonSearch"), picker=$("#cartAddonPicker"); if(search&&picker) search.addEventListener('input',()=>{const q=search.value.toLowerCase(); picker.querySelectorAll('.cart-addon-choice').forEach((el)=>el.hidden=!el.textContent.toLowerCase().includes(q));});
}
function addAddonToCart(i,j){ const item=state.cart[i], a=item?.additional?.[j]; if(!item||!a)return; item.addons=item.addons||[]; item.addons.push({name:a.name,price:Number(a.price)||0,image:a.image||''}); saveCart(); closeModal(); renderCart(); }
function removeAddonFromCart(i,j){ const item=state.cart[i]; if(!item?.addons)return; item.addons.splice(j,1); saveCart(); renderCart(); }


async function api(path, opts = {}) {
  const r = await fetch("/api" + path, { credentials: "include", cache: "no-store", ...opts, headers: { ...(opts.body ? { "content-type": "application/json" } : {}), ...(opts.headers || {}) } });
  const d = await r.json().catch(() => ({}));
  // Do not log the customer out just because an individual API request is unauthorized.
  // The canonical session check is /auth/me; protected pages can show their own error.
  if (r.status === 401 && path === "/auth/me") { state.user = null; renderAccount(); }
  return { ok: r.ok, data: d };
}
function compress(file, maxDim = 1200, q = 0.72) {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => {
      const sc = Math.min(1, maxDim / Math.max(img.width, img.height));
      const cv = document.createElement("canvas");
      cv.width = Math.round(img.width * sc); cv.height = Math.round(img.height * sc);
      cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
      res(cv.toDataURL("image/jpeg", q)); URL.revokeObjectURL(img.src);
    };
    img.onerror = rej; img.src = URL.createObjectURL(file);
  });
}

/* ============ AKUN ============ */
function renderAccount() {
  const na = $("#navActions");
  const cart = `<a class="btn ghost small cart-nav" href="#/cart">🛒 Keranjang <span id="cartCount">${(state.cart||[]).reduce((n,x)=>n+Math.max(1,Number(x.quantity||1)),0)}</span></a>`;
  if (state.user) {
    na.innerHTML = `${cart}<span class="user-chip">Hai, ${esc(state.user.name.split(" ")[0])}</span>
      <a class="btn ghost small" href="#/orders">Pesanan</a>
      <a class="btn ghost small" href="#/settlements">Pelunasan DP</a>
      <a class="btn ghost small" href="#/profile">Profil</a>`;
  } else {
    na.innerHTML = `${cart}<button class="btn ghost small" onclick="openAuth('login')">Masuk</button>
      <button class="btn primary small" onclick="openAuth('register')">Daftar</button>`;
  }
  updateCartBadge();
}
function openAuth(mode) {
  const isLogin = mode === "login";
  $("#modalBody").innerHTML = `<h2>${isLogin ? "Masuk" : "Daftar Akun"}</h2>
    <p class="muted">Lupa password? Hubungi admin untuk mendapatkan password sementara.</p>
    <form onsubmit="submitAuth(event,'${mode}')">
      ${isLogin ? "" : `<label>Nama lengkap<input name="name" required></label>`}
      <label>Email<input type="email" name="email" required></label>
      <label>Password<input type="password" name="password" required minlength="6"></label>
      <button class="btn primary" type="submit">${isLogin ? "Masuk" : "Daftar"}</button>
    </form>
    <p class="muted">${isLogin ? `Belum punya akun? <a href="#" onclick="openAuth('register');return false"><b>Daftar</b></a>` : `Sudah punya akun? <a href="#" onclick="openAuth('login');return false"><b>Masuk</b></a>`}</p>`;
  $("#modal").classList.remove("hidden");
}
async function submitAuth(e, mode) {
  e.preventDefault();
  const d = Object.fromEntries(new FormData(e.target));
  const res = await api(`/auth/${mode}`, { method: "POST", body: JSON.stringify(d) });
  if (res.ok && res.data.user) {
    state.user = res.data.user; closeModal(); renderAccount();
    if (state.user.must_change_password) forceChangePassword();
    else if (location.hash.startsWith("#/orders") || location.hash.startsWith("#/profile")) route();
  } else alert(res.data.error || "Gagal");
}
function forceChangePassword() {
  $("#modalBody").innerHTML = `<h2>Ganti Password</h2>
    <p class="muted">Akunmu menggunakan password sementara dari admin. Buat password baru sekarang.</p>
    <form onsubmit="doForceChange(event)">
      <label>Password sementara<input type="password" name="old" required></label>
      <label>Password baru (min. 6)<input type="password" name="new" required minlength="6"></label>
      <button class="btn primary">Simpan</button></form>`;
  $("#modal").classList.remove("hidden");
}
async function doForceChange(e) {
  e.preventDefault();
  const d = Object.fromEntries(new FormData(e.target));
  const res = await api("/profile/password", { method: "POST", body: JSON.stringify(d) });
  if (res.ok) { state.user.must_change_password = 0; closeModal(); alert("Password berhasil diganti ✅"); }
  else alert(res.data.error || "Gagal");
}
async function logout() { await api("/auth/logout", { method: "POST" }); state.user = null; renderAccount(); route(); }
async function initAuth() {
  const res = await api("/auth/me");
  state.user = res.data?.user || null;
  renderAccount();
  if (state.user?.must_change_password) forceChangePassword();
}

/* ============ ROUTER ============ */
const views = ["home", "catalog", "cart", "profile", "payment", "orders", "order", "settlements"];
async function route() {
  const h = location.hash.replace(/^#\/?/, "");
  const [view, arg] = h.split("/");
  views.forEach((v) => ($("#view-" + v).hidden = v !== (view || "home") && !(view === "" && v === "home")));
  $("#view-" + (view || "home")).hidden = false;
  if (!view || view === "home") await renderHome();
  else if (view === "catalog") await renderCatalog();
  else if (view === "cart") await renderCart();
  else if (view === "profile") renderProfile();
  else if (view === "payment") {
    try { await renderPayment(arg); }
    catch (e) {
      console.error("Payment page error:", e);
      const el = $("#paymentBody");
      if (el) el.innerHTML = `<div class="order-item"><h2>Pembayaran belum dapat dimuat</h2><p class="muted">Terjadi kesalahan saat memuat detail pembayaran. Silakan refresh halaman. Jika masih kosong, hubungi admin.</p><button class="btn primary" onclick="route()">Coba Lagi</button></div>`;
    }
  }
  else if (view === "orders") await renderOrders();
  else if (view === "order") await renderOrderDetail(arg);
  else if (view === "settlements") await renderSettlements();
  window.scrollTo(0, 0);
}

/* ============ HOME ============ */
function parseJsonSetting(v, fb) { try { return JSON.parse(v ?? "") ?? fb; } catch { return fb; } }
async function renderHome() {
  const s = state.settings;
  const steps = parseJsonSetting(s.steps_list, parseJsonSetting(DEFAULTS.steps_list, []));
  const rules = parseJsonSetting(s.rules_list, parseJsonSetting(DEFAULTS.rules_list, []));
  const terms = parseJsonSetting(s.terms_list, parseJsonSetting(DEFAULTS.terms_list, []));
  $("#steps").innerHTML = steps.map((x) => `<div><b>${esc(x.number || "01")}</b><h3>${esc(x.title || "Langkah")}</h3><p>${esc(x.description || "Ikuti langkah berikut untuk menyewa kostum.")}</p></div>`).join("");
  $("#rulesList").innerHTML = rules.map((x) => `<li>${esc(x)}</li>`).join("");
  $("#termsList").innerHTML = terms.map((x) => `<li>${esc(x)}</li>`).join("");
  renderFines();
}

function renderFines() {
  const s = state.settings, el = $("#finesList");
  if (!el) return;
  const perDay = Number(s.fine_per_day || 0), dep = Number(s.deposit_amount || 0);
  el.innerHTML =
    (perDay ? `<p>⏰ <b>Telat kembali:</b> ${rupiah(perDay)} / hari</p>` : "") +
    (dep ? `<p>🔐 <b>Deposit:</b> ${rupiah(dep)}</p>` : "") +
    (s.fine_damage_text ? `<p>🧵 <b>Kerusakan:</b> ${esc(s.fine_damage_text)}</p>` : "") +
    (s.fine_lost_text ? `<p>📦 <b>Kehilangan:</b> ${esc(s.fine_lost_text)}</p>` : "");
  if ($("#finesNote")) $("#finesNote").textContent = s.fines_note || "";
}

/* ============ KATALOG ============ */
async function renderCatalog() {
  await loadCostumes();
}
function resetFilters() { $("#fSearch").value = ""; $("#fCategory").value = ""; $("#fGender").value = ""; $("#fMaxPrice").value = ""; $("#fDate").value = ""; loadCostumes(); }
async function loadCostumes() {
  const grid = $("#catalogGrid");
  if (grid) grid.innerHTML = `<div class="empty-state"><b>Memuat katalog…</b><span>Menyiapkan koleksi kostum.</span></div>`;
  const qs = new URLSearchParams();
  const v = (id) => $(id).value.trim();
  if (v("#fSearch")) qs.set("search", v("#fSearch"));
  if (v("#fCategory")) qs.set("category", v("#fCategory"));
  if (v("#fGender")) qs.set("gender", v("#fGender"));
  if (v("#fMaxPrice")) qs.set("max_price", v("#fMaxPrice"));
  if (v("#fDate")) qs.set("date", v("#fDate"));
  try {
    const r = await fetch("/api/costumes?" + qs, { cache: "no-store" });
    if (!r.ok) throw new Error("catalog");
    const data = await r.json();
    state.costumes = Array.isArray(data) ? data.map(c => ({...c, character: c.character ?? c.character_name ?? "", series: c.series ?? c.anime_name ?? "", main_image: c.main_image ?? c.image_url ?? c.image ?? ""})) : [];
  } catch (e) {
    console.error("Gagal memuat katalog", e);
    state.costumes = [];
    if (grid) grid.innerHTML = `<div class="empty-state"><b>Data belum dapat dimuat.</b><span>Coba lagi beberapa saat.</span><button class="btn ghost small" onclick="loadCostumes()">Coba lagi</button></div>`;
    return;
  }
  renderCatalogGrid();
}
function renderCatalogGrid() {
  const grid = $("#catalogGrid");
  if (!state.costumes.length) { grid.innerHTML = `<div class="empty-state"><b>Belum ada kostum tersedia</b><span>Admin belum menambahkan koleksi kostum.</span></div>`; return; }
  grid.innerHTML = state.costumes.map((c) => {
    const safeId = JSON.stringify(String(c.id));
    const unavailable = c.any_available === false;
    return `
    <article class="card catalog-card" data-costume-id="${esc(c.id)}" role="button" tabindex="0" aria-label="Lihat ${esc(c.name)}" data-open-costume="${esc(String(c.id))}">
      <div class="thumb">${c.main_image ? `<img src="${esc(c.main_image)}" alt="${esc(c.name)}">` : `<div class="thumb-fallback"><span>🎭</span><small>Foto belum tersedia</small></div>`}</div>
      <h3>${esc(c.name)}</h3>
      <small>${esc(c.character)} • ${esc(c.series)}</small>
      <strong>${rupiah(c.price_per_day)}/3 hari</strong>
      ${Array.isArray(c.additional) && c.additional.length ? `<div class="catalog-additional-price"><b>Additional:</b> ${c.additional.map(a => `${esc(a.name)} — ${rupiah(a.price)}`).join(" • ")}</div>` : ""}
      <span class="badge ${unavailable ? "off" : "ok"}">${unavailable ? "Tidak tersedia tgl itu" : c.available_size_count ? `${c.available_size_count} ukuran tersedia` : "Tersedia"}</span>
      <button type="button" class="btn primary small catalog-rent-btn" data-rent-costume="${esc(String(c.id))}">🛒 Sewa kostum ini</button>
    </article>`;
  }).join("");

  // Delegated click handling: avoids fragile inline handlers and works with dynamically rendered cards.
  grid.querySelectorAll("[data-open-costume], [data-rent-costume]").forEach((el) => {
    el.addEventListener("click", (event) => {
      if (el.hasAttribute("data-rent-costume")) event.stopPropagation();
      const id = el.getAttribute("data-rent-costume") || el.getAttribute("data-open-costume");
      if (id) openCostume(id);
    });
  });
  grid.querySelectorAll("[data-open-costume]").forEach((el) => {
    el.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        const id = el.getAttribute("data-open-costume");
        if (id) openCostume(id);
      }
    });
  });
}

/* ============ DETAIL + CHECKOUT ============ */
let currentSlides = [], slideIdx = 0, currentAvail = [], curCostume = null;
function goSlide(i) {
  const s = $("#slider"); if (!s) return;
  slideIdx = (i + currentSlides.length) % currentSlides.length;
  $("#slideTrack").style.transform = `translateX(-${slideIdx * 100}%)`;
  s.querySelectorAll(".dots button").forEach((b, j) => b.classList.toggle("on", j === slideIdx));
  document.querySelectorAll("#sliderThumbs button").forEach((b, j) => b.classList.toggle("on", j === slideIdx));
  const avImg = $("#availabilityPhotoMain");
  if (avImg && currentSlides[slideIdx]) avImg.src = currentSlides[slideIdx].src;
  document.querySelectorAll(".availability-photo-thumbs button").forEach((b, j) => b.classList.toggle("on", j === slideIdx));
}
function moveSlide(d) { goSlide(slideIdx + d); }
let lbIdx = 0, lbZoomed = false, lbPX = 0, lbPY = 0, lbDrag = null;
function renderLb() {
  const s = currentSlides[lbIdx]; if (!s) return;
  const img = $("#lightboxImg");
  img.src = s.src; img.classList.toggle("zoomed", lbZoomed);
  img.style.transform = lbZoomed ? `translate(${lbPX}px,${lbPY}px) scale(2)` : "";
  $("#lbLabel").textContent = `${s.label} • ${lbIdx + 1}/${currentSlides.length}`;
}
function openLightbox(i) { lbIdx = i; lbZoomed = false; lbPX = lbPY = 0; renderLb(); $("#lightbox").classList.remove("hidden"); }
function closeLightbox() { $("#lightbox").classList.add("hidden"); }
function lbNav(d) { lbIdx = (lbIdx + d + currentSlides.length) % currentSlides.length; lbZoomed = false; lbPX = lbPY = 0; renderLb(); }
function toggleLbZoom() { lbZoomed = !lbZoomed; if (!lbZoomed) lbPX = lbPY = 0; renderLb(); }
function lbFullscreen() { const el = $("#lightbox"); document.fullscreenElement ? document.exitFullscreen() : el.requestFullscreen?.(); }

function renderSizeGuide(c) {
  const rawMeasurements = Array.isArray(c.size_measurements) ? c.size_measurements : [];
  const rawSizes = Array.isArray(c.sizes) ? c.sizes : [];
  const bySize = new Map(rawMeasurements.map(r => [String(r.size), r]));
  const rows = rawSizes.length ? rawSizes.map(sz => {
    const m = bySize.get(String(sz.size));
    return { size: sz.size, measurements: m?.measurements || {}, note: m?.note || "", stock: sz.stock };
  }) : rawMeasurements;
  if (!rows.length) return `<section class="size-guide"><div class="section-head"><div><p class="eyebrow">PANDUAN UKURAN</p><h3>Panduan Ukuran</h3></div></div><div class="empty-inline">Belum ada ukuran dari admin.</div></section>`;
  const fields = [["bust","Lingkar Dada"],["waist","Pinggang"],["length","Panjang"]].filter(([key]) => rows.some(r => r.measurements?.[key] !== undefined && r.measurements?.[key] !== ""));
  return `<section class="size-guide"><div class="section-head"><div><p class="eyebrow">PANDUAN UKURAN</p><h3>Panduan Ukuran</h3></div></div><div class="size-table-wrap"><table class="size-table"><thead><tr><th>Ukuran</th>${fields.map(([,label])=>`<th>${label}</th>`).join("")}<th>Stok</th><th>Catatan</th></tr></thead><tbody>${rows.map(r=>`<tr><th>${esc(r.size)}</th>${fields.map(([key])=>`<td>${esc(r.measurements?.[key] ?? "—")}${r.measurements?.[key] !== undefined && r.measurements?.[key] !== "" ? " cm" : ""}</td>`).join("")}<td>${esc(r.stock ?? "—")}</td><td>${esc(r.note || "—")}</td></tr>`).join("")}</tbody></table></div><p class="muted size-note">Gunakan ukuran yang sesuai dengan data kostum ini. Jika ragu, hubungi admin.</p></section>`;
}

async function openCostume(id) {
  try {
    const r = await fetch(`/api/costumes/${encodeURIComponent(String(id))}`, { cache: "no-store" });
    const res = await r.json().catch(() => ({}));
    if (!r.ok || res.error) throw new Error(res.error || `Gagal memuat kostum (${r.status})`);
  const c = res; curCostume = c;
  currentSlides = [];
  const seen = new Set();
  const push = (src, label) => { if (src && !seen.has(src)) { seen.add(src); currentSlides.push({ src, label }); } };
  push(c.main_image, "Foto Kostum (Asli)");
  (c.gallery || []).forEach((g) => push(g.url, g.is_ai ? "Gambar AI (pelengkap)" : "Detail Kostum"));
  slideIdx = 0;
  const gallery = currentSlides.length ? `
    <div class="slider" id="slider" data-total="${currentSlides.length}">
      <div class="slide-track" id="slideTrack">${currentSlides.map((s, i) =>
        `<div class="slide"><img src="${esc(s.src)}" data-idx="${i}" alt="${esc(s.label)}"></div>`).join("")}</div>
      <button class="snav prev" onclick="moveSlide(-1)">‹</button>
      <button class="snav next" onclick="moveSlide(1)">›</button>
      <button class="snav fs" onclick="openLightbox(slideIdx)">⛶</button>
      <div class="dots">${currentSlides.map((_, i) => `<button class="${i === 0 ? "on" : ""}" onclick="goSlide(${i})"></button>`).join("")}</div>
    </div>
    <div class="thumbs" id="sliderThumbs">${currentSlides.map((s, i) =>
      `<button class="${i === 0 ? "on" : ""}" onclick="goSlide(${i})" title="${esc(s.label)}"><img src="${esc(s.src)}"></button>`).join("")}</div>` : "";

  const paket = parseJsonSetting(JSON.stringify(c.package_items ?? []), []);
  const aksesorisRaw = c.accessories;
  const aksesoris = Array.isArray(aksesorisRaw) ? aksesorisRaw : parseJsonSetting(aksesorisRaw ?? "[]", []);
  const aksesorisList = Array.isArray(aksesoris) ? aksesoris : (aksesoris && typeof aksesoris === "object" ? [aksesoris] : []);
  $("#modalBody").innerHTML = `
    ${gallery}
    <h2>${esc(c.name)}</h2>
    <p class="muted">${esc(c.character)} • ${esc(c.series)} • ${esc(c.category)} ${c.gender !== "unisex" ? "• " + esc(c.gender) : ""}
      ${c.rating?.count ? ` • ⭐ ${c.rating.avg ?? "0"} (${c.rating.count} review)` : ""}</p>
    <p>${esc(c.description)}</p>
    <p><strong>${rupiah(c.price_per_day)} / 3 hari</strong></p>
    <div class="detail-actions">
      <button type="button" class="btn ghost small" onclick="askAiAboutCostume()">✨ Tanya AI tentang kostum ini</button>
      <button type="button" class="btn ghost small" onclick="loadAiRecommendations()">💡 Rekomendasi serupa</button>
    </div>
    <div id="aiRecommendations" class="ai-recommendations" hidden></div>
    ${paket.length ? `<p><b>Isi paket:</b></p><ul class="mini-list">${paket.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}
    ${aksesorisList.filter(x => typeof x === "string").length ? `<p><b>Aksesoris:</b> ${aksesorisList.filter(x => typeof x === "string").map(esc).join(", ")}</p>` : ""}
    ${(Array.isArray(c.additional) && c.additional.length) ? `<div class="costume-addons"><p><b>Add-on:</b></p><ul class="mini-list">${c.additional.map(a => `<li>${esc(a.name)}${Number(a.price || 0) > 0 ? ` — ${rupiah(a.price)}` : ""}</li>`).join("")}</ul></div>` : ""}
    ${c.rules_text ? `<p class="fine-note">📋 ${esc(c.rules_text)}</p>` : ""}
    <section class="availability-section">
      <div class="section-head"><div><p class="eyebrow">KETERSEDIAAN</p><h3>Kalender Ketersediaan</h3></div><span class="muted">Cek tanggal sebelum masuk keranjang</span></div>
      <div id="availabilityCalendar" class="availability-calendar"><p class="muted">Memuat ketersediaan...</p></div>
    </section>
    ${renderSizeGuide(c)}
    ${!["published","available","active"].includes(String(c.status || "published")) ? `<p class="badge off">Kostum tidak tersedia</p>` : `
    <div class="cart-add-main"><p class="muted">Tambahkan kostum ini ke keranjang. Tanggal rental dan Additional dipilih setelahnya di keranjang.</p><button type="button" class="btn primary" onclick='addCostumeToCart(${JSON.stringify({id:c.id,name:c.name,main_image:c.main_image||"",price_per_day:c.price_per_day,additional:c.additional||[]}).replace(/'/g,"&apos;")})'>🛒 Tambah ke Keranjang</button><button type="button" class="btn ghost" onclick="location.hash='#/cart';closeModal()">Lihat Keranjang</button></div>`}`;
  $("#modal").classList.remove("hidden");
  loadAvailabilityCalendar();

  const sl = $("#slider");
  if (sl) {
    let sd = null;
    sl.addEventListener("pointerdown", (e) => { sd = { x: e.clientX, y: e.clientY, moved: false }; });
    sl.addEventListener("pointermove", (e) => { if (sd && Math.abs(e.clientX - sd.x) > 10) sd.moved = true; });
    sl.addEventListener("pointerup", (e) => {
      if (!sd) return;
      const dx = e.clientX - sd.x, dy = e.clientY - sd.y;
      if (!sd.moved && Math.abs(dx) < 8 && Math.abs(dy) < 8) {
        const idx = e.target.closest("img")?.dataset?.idx;
        openLightbox(idx !== undefined ? +idx : slideIdx);
      } else if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) moveSlide(dx < 0 ? 1 : -1);
      sd = null;
    });
  }
  updateCartBadge();

  } catch (err) {
    console.error("Gagal membuka kostum", err);
    alert(err?.message || "Kostum tidak dapat dibuka. Silakan coba lagi.");
  }
}
window.openCostume = openCostume;
const availabilityCache = new Map();
let availabilityAbort = null;
async function refreshAvailabilityCalendar() {
  const f = $("#bookForm"), block = $("#availabilityCalendar");
  if (!f || !block || !curCostume?.id) return;
  const from = f.elements.ship_date.value || new Date().toISOString().slice(0, 10);
  const key = `${curCostume.id}|${from}`;
  const cached = availabilityCache.get(key);
  if (cached && Date.now() - cached.time < 30000) {
    renderAvailabilityCalendar(cached.data);
    return;
  }
  if (availabilityAbort) availabilityAbort.abort();
  availabilityAbort = new AbortController();
  block.innerHTML = `<p class="muted">Memuat ketersediaan...</p>`;
  try {
    const res = await fetch(`/api/costumes/${encodeURIComponent(curCostume.id)}/availability-dates?from=${encodeURIComponent(from)}&days=60`, { cache: "default", signal: availabilityAbort.signal });
    const data = await res.json();
    if (!res.ok || !data.ok) throw new Error(data.error || "Gagal memuat ketersediaan");
    availabilityCache.set(key, { time: Date.now(), data });
    renderAvailabilityCalendar(data);
  } catch (e) {
    if (e?.name === "AbortError") return;
    block.innerHTML = `<p class="muted">Kalender ketersediaan belum bisa dimuat. Sistem tetap akan mengecek tanggal saat checkout.</p>`;
  }
}
function renderAvailabilityCalendar(data) {
  const block = $("#availabilityCalendar");
  if (!block) return;
  const unavailable = new Set(data.unavailable || []);
  const photoGallery = currentSlides.length ? `
    <div class="availability-photo">
      <div class="availability-photo-main"><img id="availabilityPhotoMain" src="${esc(currentSlides[slideIdx]?.src || currentSlides[0].src)}" alt="${esc(curCostume?.name || "Foto kostum")}"></div>
      ${currentSlides.length > 1 ? `<div class="availability-photo-nav"><button type="button" onclick="availabilityPhotoMove(-1)" aria-label="Foto sebelumnya">‹</button><div class="availability-photo-thumbs">${currentSlides.map((s,i)=>`<button type="button" class="${i===slideIdx?"on":""}" onclick="availabilityPhotoGo(${i})"><img src="${esc(s.src)}" alt="Foto ${i+1}"></button>`).join("")}</div><button type="button" onclick="availabilityPhotoMove(1)" aria-label="Foto berikutnya">›</button></div>` : ""}
      <div class="availability-photo-caption"><b>${esc(curCostume?.name || "Kostum")}</b><span>Geser foto untuk melihat detail kostum</span></div>
    </div>` : "";
  block.innerHTML = `${photoGallery}<div class="availability-legend"><span class="avail-dot ok"></span>Tersedia <span class="avail-dot off"></span>Tidak tersedia</div><div class="availability-grid">${(data.days || []).map(d => `<button type="button" data-date="${esc(d.date)}" class="avail-day ${unavailable.has(d.date) ? "is-off" : "is-ok"}" ${unavailable.has(d.date) ? "disabled" : ""} onclick="pickRentalDate('${d.date}')"><b>${esc(d.day)}</b><span>${esc(d.label)}</span></button>`).join("")}</div>`;
}
function availabilityPhotoGo(i) {
  if (!currentSlides.length) return;
  goSlide(i);
  const img = $("#availabilityPhotoMain");
  if (img) img.src = currentSlides[slideIdx].src;
  document.querySelectorAll(".availability-photo-thumbs button").forEach((b,j)=>b.classList.toggle("on",j===slideIdx));
}
function availabilityPhotoMove(d) { availabilityPhotoGo(slideIdx + d); }
function pickRentalDate(date) {
  const draft = state.cartDraftDates || {};
  if (!draft.ship_date || (draft.ship_date && draft.return_date) || date < draft.ship_date) {
    state.cartDraftDates = { ship_date: date, return_date: "" };
  } else {
    state.cartDraftDates = { ship_date: draft.ship_date, return_date: date };
  }
  saveCart();
  document.querySelectorAll(".avail-day.is-selected").forEach(el => el.classList.remove("is-selected"));
  const btn = [...document.querySelectorAll(`.avail-day[data-date="${date}"]`)][0];
  if (btn) btn.classList.add("is-selected");
  const block = $("#availabilityCalendar");
  if (block) {
    const d = state.cartDraftDates;
    let hint = block.querySelector(".availability-selection");
    if (!hint) { hint = document.createElement("p"); hint.className = "availability-selection"; block.appendChild(hint); }
    hint.innerHTML = d.ship_date && d.return_date ? `Tanggal dipilih: <b>${esc(d.ship_date)}</b> → <b>${esc(d.return_date)}</b>` : `Tanggal kirim dipilih: <b>${esc(d.ship_date)}</b>. Pilih satu tanggal lagi untuk tanggal kembali.`;
  }
}
function validateRentalDates() {
  const f = $("#bookForm"); if (!f) return true;
  const start = f.elements.ship_date.value, end = f.elements.return_date.value;
  f.elements.return_date.setCustomValidity(start && end && end < start ? "Tanggal kembali tidak boleh sebelum tanggal kirim." : "");
  return !f.elements.return_date.validationMessage;
}

function setupKtpUpload(form) {
  const box = $("#ktpUploadBox"), input = $("#ktpFile"), preview = $("#ktpPreview");
  if (!box || !input || !preview) return;
  const setFile = async (file) => {
    if (!file || !String(file.type || "").startsWith("image/")) return alert("File KTP harus berupa gambar.");
    try {
      const data = await compress(file, 1000, 0.62);
      form.dataset.ktpImage = data;
      preview.hidden = false;
      preview.innerHTML = `<img src="${esc(data)}" alt="Preview KTP"><div><b>✓ KTP siap dikirim</b><button type="button" class="btn ghost small" onclick="clearKtpUpload()">Ganti</button></div>`;
      box.classList.add("has-file");
    } catch { alert("Foto KTP tidak dapat diproses."); }
  };
  input.onchange = () => setFile(input.files?.[0]);
  box.ondragover = e => { e.preventDefault(); box.classList.add("drag"); };
  box.ondragleave = () => box.classList.remove("drag");
  box.ondrop = e => { e.preventDefault(); box.classList.remove("drag"); setFile(e.dataTransfer?.files?.[0]); };
  box.onpaste = e => { const f = [...(e.clipboardData?.files || [])].find(x => String(x.type||"").startsWith("image/")); if (f) { e.preventDefault(); setFile(f); } };
  window.clearKtpUpload = () => { form.dataset.ktpImage = ""; input.value = ""; preview.hidden = true; preview.innerHTML = ""; box.classList.remove("has-file"); };
}

async function submitCartCheckout(e) {
  e.preventDefault();
  if (!state.user) return openAuth("login");
  if (!state.cart.length) return alert("Keranjang masih kosong.");
  const f=e.target, d=Object.fromEntries(new FormData(f));
  if (!d.ship_date || !d.return_date || d.return_date < d.ship_date) return alert("Tanggal rental tidak valid.");
  const ktpImage=f.dataset.ktpImage||"";
  if (String(state.settings.ktp_required ?? "1")==="1" && !ktpImage) return alert("Upload foto KTP terlebih dahulu.");
  const items=state.cart.filter(x=>x.type==='costume').map(x=>({costume_id:x.costume_id,quantity:Math.max(1,Number(x.quantity||1)),addons:(x.addons||[]).map(a=>({name:a.name,price:Number(a.price)||0}))}));
  if(!items.length) return alert("Tambahkan kostum ke keranjang terlebih dahulu.");
  const body={items,ship_date:d.ship_date,return_date:d.return_date,ship_address:d.ship_address,recipient_name:d.recipient_name,recipient_phone:d.recipient_phone,note:d.note,ktp_image:ktpImage};
  const res=await api("/orders",{method:"POST",body:JSON.stringify(body)});
  if(res.ok){state.cart=[];state.cartDraftDates={};saveCart();location.hash="#/payment/"+res.data.order_code;} else alert(res.data.error||"Gagal membuat pesanan");
}
function renderCart(){
  const el=$("#cartBody"); if(!el)return;
  if(!state.cart.length){el.innerHTML=`<div class="empty-state"><h2>Keranjang masih kosong</h2><p class="muted">Pilih kostum dari katalog lalu tambahkan ke keranjang.</p><a class="btn primary" href="#/catalog">Lihat Katalog</a></div>`;updateCartBadge();return;}
  const rows=state.cart.map((x,i)=>{const addons=x.addons||[];const base=Number(x.price_per_day||0)*Math.max(1,Math.ceil(Number(x.days||3)/3))*Math.max(1,Number(x.quantity||1));return `<article class="cart-item"><div class="cart-item-main">${x.image?`<img src="${esc(x.image)}" alt="${esc(x.name)}">`:''}<div><h3>${esc(x.name)}</h3><p class="muted">${rupiah(x.price_per_day)} / 3 hari</p><div class="cart-qty"><button onclick="changeCartQty(${i},-1)">−</button><b>${x.quantity||1}</b><button onclick="changeCartQty(${i},1)">+</button></div></div><strong>${rupiah(base)}</strong></div>${addons.length?`<div class="cart-addons"><b>Additional</b>${addons.map((a,j)=>`<div><span>${a.image?`<img src="${esc(a.image)}" alt="">`:''}${esc(a.name)}</span><span>${rupiah(a.price)} <button class="link-btn" onclick="removeAddonFromCart(${i},${j})">Hapus</button></span></div>`).join('')}</div>`:''}<div class="cart-item-actions"><button class="btn secondary small" onclick="openCartAdditional(${i})">＋ Tambah Additional</button><button class="btn ghost small" onclick="removeCartItem(${i})">Hapus kostum</button></div></article>`}).join('');
  el.innerHTML=`<section class="cart-layout"><div><div class="section-head"><div><p class="eyebrow">KERANJANG</p><h1>Pesananmu</h1></div><a class="btn ghost small" href="#/catalog">＋ Tambah kostum</a></div>${rows}</div><aside class="cart-checkout"><h2>Checkout</h2><div class="cart-summary"><span>Subtotal</span><b>${rupiah(cartSubtotal())}</b></div><form id="cartCheckoutForm" onsubmit="submitCartCheckout(event)"><label>Tanggal kirim<input type="date" name="ship_date" value="${esc(state.cartDraftDates?.ship_date || "")}" required min="${new Date().toISOString().slice(0,10)}"></label><label>Tanggal kembali<input type="date" name="return_date" value="${esc(state.cartDraftDates?.return_date || "")}" required min="${new Date().toISOString().slice(0,10)}"></label><label>Nama penerima<input name="recipient_name" value="${state.user?esc(state.user.name):''}" required></label><label>No. HP penerima<input name="recipient_phone" value="${state.user?esc(state.user.phone||''):''}" required></label><label>Alamat lengkap<textarea name="ship_address" required></textarea></label><div class="ktp-upload" id="ktpUploadBox"><div class="ktp-upload-head"><div><b>KTP</b><span>${String(state.settings.ktp_required??'1')==='1'?'Wajib diupload':'Opsional'}</span></div><small>Foto KTP</small></div><input id="ktpFile" type="file" accept="image/*" hidden><button type="button" class="ktp-drop" onclick="document.getElementById('ktpFile').click()"><span class="ktp-upload-icon">▣</span><strong>Upload foto KTP</strong><small>Pilih foto atau tarik file</small></button><div id="ktpPreview" class="ktp-preview" hidden></div></div><label>Catatan (opsional)<input name="note"></label><p class="muted">Ongkir ditentukan admin setelah checkout.</p><button class="btn primary" type="submit">Lanjut ke Pembayaran</button></form></aside></section>`;
  setupKtpUpload($("#cartCheckoutForm")); updateCartBadge();
}
function closeModal() { $("#modal").classList.add("hidden"); }

/* ============ PAYMENT ============ */
async function renderPayment(code) {
  const el = $("#paymentBody");
  if (!code) { el.innerHTML = `<p class="muted">Kode pesanan tidak ada.</p>`; return; }
  const res = await api("/orders/" + encodeURIComponent(code));
  if (!res.ok) { el.innerHTML = `<p class="muted">${esc(res.data.error || "Pesanan tidak ditemukan")}</p>`; return; }
  const o = res.data;
  const canPay = !["cancelled", "completed"].includes(o.status) && ["unpaid", "partial", "rejected"].includes(String(o.payment_summary?.status || "unpaid"));
  let methods = [];
  if (canPay) {
    try {
      const pmRes = await api("/payment-methods");
      methods = Array.isArray(pmRes.data) ? pmRes.data : (Array.isArray(pmRes.data?.methods) ? pmRes.data.methods : []);
    } catch (e) {
      methods = [];
      console.error("Gagal memuat metode pembayaran", e);
    }
  }
  const ship = o.shipping_cost > 0 ? rupiah(o.shipping_cost) : `<span class="muted">Menunggu ditentukan admin</span>`;
  el.innerHTML = `
    <h2>Pembayaran — ${esc(o.order_code)}</h2>
    ${(o.shipping?.tracking_number || o.tracking_number || o.shipping?.courier || o.courier) ? `<div class="order-item"><h3>Pengiriman</h3>${o.shipping?.courier || o.courier ? `<p><b>Kurir:</b> ${esc(o.shipping?.courier || o.courier)}${o.shipping?.service || o.service ? ` • ${esc(o.shipping?.service || o.service)}` : ""}</p>` : ""}<p><b>Ongkir:</b> ${rupiah(o.shipping?.cost || o.shipping_cost || 0)} ${(o.shipping?.tracking_number || o.tracking_number) ? `• <b>Resi:</b> ${esc(o.shipping?.tracking_number || o.tracking_number)}` : ""}</p></div>` : `<div class="order-item"><h3>Pengiriman</h3><p class="muted">Kurir, ongkir, dan resi akan ditentukan admin.</p></div>`}
    <div class="order-item">
      ${o.items.map((i) => { const addons = Array.isArray(i.addons) ? i.addons : []; const addonTotal = addons.reduce((n,a)=>n+Number(a.price||0),0); return `<div class="payment-item"><p><b>${esc(i.costume_name)}</b> • ${i.days || 1} hari • ${rupiah(i.price_per_day || 0)}/3 hari</p>${addons.length ? `<div class="order-addons"><b>Additional</b>${addons.map(a=>`<div><span>${esc(a.name)}</span><span>+${rupiah(a.price)}</span></div>`).join("")}<div><span>Total additional</span><b>+${rupiah(addonTotal)}</b></div></div>` : `<p class="muted">Tidak ada additional.</p>`}</div>`; }).join("")}
      <p class="muted">${esc(o.ship_date || o.start_date || "-")} s/d ${esc(o.return_date || o.end_date || "-")}</p>
      <div class="pay-summary">
        <div><span>Subtotal</span><b>${rupiah(o.subtotal)}</b></div>
        <div><span>Ongkir</span><b>${ship}</b></div>
        ${o.fine_amount > 0 ? `<div><span>Denda</span><b>${rupiah(o.fine_amount)}</b></div>` : ""}
        <div class="pay-total"><span>Total</span><b>${rupiah(Number(o.total) || Number(o.subtotal) || 0)}</b></div>
      </div>
    </div>
    ${o.payments.length ? `<h3>Status pembayaran</h3>${o.payments.map((p) => `
      <div class="order-item"><div class="order-head"><b>${rupiah(p.amount)}</b>
      <span class="pill ${p.status === "approved" ? "st-done" : p.status === "rejected" ? "st-cancelled" : "st-pending"}">${PAY_ID[p.status]}</span></div>
      <p class="muted">${esc(p.payment_type === "dp" || p.type === "dp" || p.note === "dp" ? "DP 50%" : "Full Payment")} • ${esc(p.method_name || "-")} • ${esc(p.created_at)}</p>
      ${p.admin_note ? `<p class="fine-note">Admin: ${esc(p.admin_note)}</p>` : ""}
      <img class="proof-thumb" src="${esc(p.proof_image)}"></div>`).join("")}` : ""}
    ${o.payment_summary?.status === "pending" ? `<div class="order-item"><b>⏳ Bukti pembayaran sedang diverifikasi.</b><p class="muted">Tanggal rental belum dikunci sampai admin menyetujui pembayaran. Kamu tidak perlu upload ulang.</p></div>` : ""}
    ${canPay ? `
    <h3>1. Pilih metode pembayaran</h3>
    <div class="pm-list">${methods.map((m, i) => `
      <label class="pm-opt"><input type="radio" name="pm" value="${m.id}" ${i === 0 ? "checked" : ""} onchange="showPm(${m.id})">
      <b>${esc(m.name)}</b></label>`).join("")}</div>
    <div id="pmDetail"></div>
    <h3>2. Pilih pembayaran</h3>
    ${o.payment_summary?.status === "partial" ? `<div class="order-item"><p><b>DP sudah diterima: ${rupiah(o.payment_summary.approved)}</b></p><p class="muted">Sisa pembayaran: ${rupiah(Math.max(0,(o.payment_summary.total||o.total||0)-o.payment_summary.approved))}</p><input type="hidden" id="paymentType" value="full"></div>` : `<div class="pm-list"><label class="pm-opt"><input type="radio" name="paymentType" value="dp" checked><b>DP 50%</b><span class="muted">Bayar ${rupiah(Math.ceil((Number(o.total)||Number(o.subtotal)||0)*0.5))}</span></label><label class="pm-opt"><input type="radio" name="paymentType" value="full"><b>Full Payment</b><span class="muted">Bayar ${rupiah(Number(o.total)||Number(o.subtotal)||0)}</span></label></div>`}
    <h3>3. Upload bukti transfer</h3>
    <input type="file" id="proofFile" accept="image/*">
    <div id="proofPreview" class="photo-preview"></div>
    <button class="btn primary" style="margin-top:10px" onclick="uploadProof('${esc(o.order_code)}')">Kirim Bukti Pembayaran</button>
    <p class="muted" style="font-size:13px">Setelah dikirim, admin akan memverifikasi. Kamu bisa melihat status di halaman ini.</p>` :
    `<p>Lihat <a href="#/order/${esc(o.order_code)}"><b>detail pesanan</b></a> untuk status lengkap.</p>`}`;
  if (canPay && methods.length) showPm(methods[0].id);
  if (canPay && !methods.length) {
    const box = $("#pmDetail");
    if (box) box.innerHTML = `<div class="order-item"><b>Metode pembayaran belum tersedia.</b><p class="muted">Admin belum mengaktifkan QRIS atau rekening bank. Silakan hubungi admin.</p></div>`;
  }
  $("#proofFile")?.addEventListener("change", async (e) => {
    const f = e.target.files[0];
    if (f) $("#proofPreview").innerHTML = `<div class="photo-thumb"><img src="${await compress(f, 1000, 0.7)}"></div>`;
  });
}
let proofData = null;
async function showPm(id) {
  try {
    const res = await api("/payment-methods");
    const ms = Array.isArray(res.data) ? res.data : (Array.isArray(res.data?.methods) ? res.data.methods : []);
    const m = ms.find((x) => String(x.id) === String(id));
    if (!m) return;
    $("#pmDetail").innerHTML = `
      <div class="order-item">
        <p><b>${esc(m.name)}</b></p>
        ${m.account_number ? `<p>No. ${esc(m.account_number)} <button class="btn ghost small" onclick="navigator.clipboard.writeText('${esc(m.account_number)}');alert('Disalin')">Copy</button></p>` : ""}
        ${m.account_name ? `<p>a/n ${esc(m.account_name)}</p>` : ""}
        ${m.instructions ? `<p class="muted">${esc(m.instructions)}</p>` : ""}
        ${m.qr_image ? `<img class="proof-thumb" src="${esc(m.qr_image)}" alt="QR">` : ""}
      </div>`;
  } catch (e) {
    const box = $("#pmDetail");
    if (box) box.innerHTML = `<div class="order-item"><b>Metode pembayaran gagal dimuat.</b><p class="muted">Silakan refresh halaman atau hubungi admin.</p></div>`;
    console.error(e);
  }
}
async function uploadProof(code) {
  const file = $("#proofFile").files[0];
  if (!file) return alert("Upload foto bukti transfer terlebih dahulu.");
  proofData = await compress(file, 1100, 0.7);
  const mid = document.querySelector('input[name="pm"]:checked')?.value;
  const paymentType = document.querySelector('input[name="paymentType"]:checked')?.value || $("#paymentType")?.value || "full";
  const res = await api(`/orders/${encodeURIComponent(code)}/payment-proof`, { method: "POST", body: JSON.stringify({ method_id: +mid, payment_type: paymentType, proof_image: proofData }) });
  if (res.ok) { alert("Bukti terkirim! Menunggu verifikasi admin."); renderPayment(code); }
  else alert(res.data.error || "Gagal upload");
}

/* ============ ORDERS & DETAIL ============ */
async function renderSettlements() {
  const el = $("#settlementsBody");
  if (!state.user) {
    el.innerHTML = `<h2>Pelunasan DP</h2><div class="login-cta"><p>Masuk untuk melihat sisa pembayaran.</p><button class="btn primary small" onclick="openAuth('login')">Masuk</button></div>`;
    return;
  }
  const res = await api("/my-orders");
  const orders = Array.isArray(res.data) ? res.data : [];
  const partial = orders.filter(o => o.payment_summary?.status === "partial" && Number(o.payment_summary?.approved || 0) < Number(o.payment_summary?.total || o.total || 0));
  el.innerHTML = `<a href="#/orders" class="muted">← Pesanan Saya</a><h2>Pelunasan DP</h2>` +
    (partial.length ? partial.map(o => {
      const remain=Math.max(0,Number(o.payment_summary?.total||o.total||0)-Number(o.payment_summary?.approved||0));
      return `<div class="order-item"><div class="order-head"><b>${esc(o.order_code)}</b><span class="pill st-pending">Belum lunas</span></div>
        <p>${esc(o.items_label||"-")}</p><p class="muted">Sisa pembayaran: <b>${rupiah(remain)}</b></p>
        ${o.tracking_number ? `<p class="muted">📦 Resi: <b>${esc(o.tracking_number)}</b>${o.courier ? ` • ${esc(o.courier)}` : ""}</p>` : ""}
        <a class="btn primary small" href="#/payment/${esc(o.order_code)}">Bayar Pelunasan</a>
      </div>`;
    }).join("") : `<div class="empty-state"><b>Tidak ada pelunasan tertunda</b><span>Semua pesananmu sudah lunas atau belum memiliki pembayaran DP.</span></div>`);
}
async function renderOrders() {
  const el = $("#ordersBody");
  if (!state.user) { el.innerHTML = `<h2>Pesanan Saya</h2><div class="login-cta"><p>Masuk untuk melihat riwayat pesananmu.</p><button class="btn primary small" onclick="openAuth('login')">Masuk</button></div>`; return; }
  const list = await api("/my-orders").then((r) => r.data);
  const orders = Array.isArray(list) ? list : [];
  const partial = orders.filter(o => o.payment_summary?.status === "partial" && Number(o.payment_summary?.approved || 0) < Number(o.payment_summary?.total || o.total || 0));
  el.innerHTML = `<h2>Pesanan Saya</h2>${partial.length ? `<div class="order-item pay-reminder"><h3>🔔 Pengingat Pelunasan</h3>${partial.map(o => `<p><b>${esc(o.order_code)}</b> masih memiliki sisa <b>${rupiah(Math.max(0, Number(o.payment_summary?.total || o.total || 0)-Number(o.payment_summary?.approved || 0)))}</b>. <a class="btn primary small" href="#/payment/${esc(o.order_code)}">Bayar Pelunasan</a></p>`).join("")}</div>` : ""}` + (orders.length ? orders.map((o) => `
    <div class="order-item" onclick="location.hash='#/order/${esc(o.order_code)}'" style="cursor:pointer">
      <div class="order-head"><b>${esc(o.order_code)}</b>
        <span class="pill st-${esc(o.status)}">${STATUS_ID[o.status] || esc(o.status)}</span></div>
      <p><b>${esc(o.items_label || "-")}</b></p>
      <p class="muted">${esc(o.ship_date)} s/d ${esc(o.return_date)} • Total ${rupiah(o.total)}</p>
      ${o.payment_summary?.status === "partial" ? `<p class="pay-reminder">💳 DP sudah dibayar • Sisa pelunasan: <b>${rupiah(Math.max(0, Number(o.payment_summary?.total || o.total || 0)-Number(o.payment_summary?.approved || 0)))}</b></p>` : ""}
      ${o.tracking_number ? `<p class="muted">📦 Resi: <b>${esc(o.tracking_number)}</b>${o.courier ? ` • ${esc(o.courier)}` : ""}</p>` : `<p class="muted">📦 Resi: belum ada</p>`}
    </div>`).join("") : `<p class="muted">Belum ada pesanan. Yuk <a href="#/catalog">pilih kostum</a>! 🎭</p>`);
  if (partial.length && "Notification" in window && Notification.permission === "granted") {
    const key = `cosrent-settlement-reminder-${new Date().toISOString().slice(0,10)}`;
    if (!localStorage.getItem(key)) {
      new Notification("COSRENT — Pengingat Pelunasan", {body:`Kamu masih memiliki ${partial.length} pesanan yang belum lunas. Cek Pesanan Saya untuk melanjutkan pembayaran.`});
      localStorage.setItem(key, "1");
    }
  }
}
async function renderOrderDetail(code) {
  const el = $("#orderBody");
  const res = await api("/orders/" + encodeURIComponent(code));
  if (!res.ok) { el.innerHTML = `<p class="muted">${esc(res.data.error || "Tidak ditemukan")}</p>`; return; }
  const o = res.data;
  const flow = ["pending_payment","payment_review","paid","preparing","shipped","rented","returned","inspection","completed"];
  const idx = flow.indexOf(o.status);
  el.innerHTML = `
    <a href="#/orders" class="muted">← Kembali ke daftar</a>
    <h2>${esc(o.order_code)} <span class="pill st-${esc(o.status)}">${STATUS_ID[o.status]}</span></h2>
    ${o.status !== "cancelled" ? `<div class="timeline">${flow.map((s, i) =>
      `<div class="tl-step ${i <= idx ? "done" : ""}"><i></i><span>${STATUS_ID[s]}</span></div>`).join("")}</div>` : ""}
    <div class="order-item">
      ${o.items.map((i) => { const addons = Array.isArray(i.addons) ? i.addons : []; const addonTotal = addons.reduce((n,a)=>n+Number(a.price||0),0); return `<div class="order-item-line"><p><b>${esc(i.costume_name)}</b> • ${i.days || 1} hari • ${rupiah((i.price_per_day || 0) * Math.max(1, Math.ceil((i.days || 1) / 3)) + addonTotal)}</p>${addons.length ? `<div class="order-addons"><b>Additional</b>${addons.map(a=>`<div><span>${esc(a.name)}</span><span>+${rupiah(a.price)}</span></div>`).join("")}</div>` : ""}</div>`; }).join("")}
      <div class="pay-summary">
        <div><span>Subtotal</span><b>${rupiah(o.subtotal)}</b></div>
        <div><span>Ongkir</span><b>${o.shipping_cost > 0 ? rupiah(o.shipping_cost) : `<span class="muted">Menunggu admin</span>`}</b></div>
        ${o.fine_amount > 0 ? `<div><span>Denda</span><b>${rupiah(o.fine_amount)} ${o.fine_note ? `(${esc(o.fine_note)})` : ""}</b></div>` : ""}
        <div class="pay-total"><span>Total</span><b>${rupiah(Number(o.total) || Number(o.subtotal) || 0)}</b></div>
      </div>
    </div>
    <div class="order-item"><h3>Pengiriman</h3>
      <p class="muted">Penerima: ${esc(o.recipient_name)} (${esc(o.recipient_phone)})</p>
      <p class="muted">Alamat: ${esc(o.ship_address)}</p>
      ${(o.shipping?.tracking_number || o.tracking_number || o.shipping?.courier) ? `<p>${o.shipping?.courier ? `Kurir: <b>${esc(o.shipping.courier)} ${esc(o.shipping.service || "")}</b> • ` : ""}${(o.shipping?.tracking_number || o.tracking_number) ? `Resi: <b>${esc(o.shipping?.tracking_number || o.tracking_number)}</b>` : "Resi: <b>belum ada</b>"}</p>` : `<p class="muted">Kurir, ongkir, dan resi akan ditentukan admin.</p>`}
    </div>
    ${canEditOrder(o) ? `<div class="order-item"><div class="section-head"><div><h3>Detail Pesanan</h3><p class="muted">Pesanan belum dibayar, jadi detail masih bisa diperbaiki.</p></div><button class="btn ghost small" type="button" onclick="toggleOrderEdit()">✏️ Perbaiki</button></div><div id="orderEditPanel" hidden><form onsubmit="saveOrderEdit(event,'${esc(o.order_code)}')"><label>Tanggal kirim <input type="date" name="ship_date" value="${esc(o.ship_date)}" required></label><label>Tanggal kembali <input type="date" name="return_date" value="${esc(o.return_date)}" required></label><label>Nama penerima <input name="recipient_name" value="${esc(o.recipient_name || o.user_name || '')}" required></label><label>No. HP <input name="recipient_phone" value="${esc(o.recipient_phone || o.user_phone || '')}" required></label><label>Alamat <textarea name="ship_address" required>${esc(o.ship_address || '')}</textarea></label><label>Catatan <textarea name="note">${esc(o.note || '')}</textarea></label><button class="btn primary">Simpan Perubahan</button></form></div></div>` : ""}
    <div class="order-item"><h3>Pembayaran</h3>
      <p><b>Status pembayaran:</b> ${PAYMENT_STATUS_ID[o.payment_summary?.status] || "Belum dibayar"}</p>
      ${o.payment_summary?.approved > 0 ? `<p><b>Sudah dibayar:</b> ${rupiah(o.payment_summary.approved)}${o.payment_summary.status === "partial" ? ` • <b>Sisa:</b> ${rupiah(Math.max(0,(o.payment_summary.total||o.total||0)-o.payment_summary.approved))}` : ""}</p>` : ""}
      ${o.payments.length ? o.payments.map((p) => `<p>${rupiah(p.amount)} • ${esc(p.method_name || "-")} • <span class="pill ${p.status === "approved" ? "st-done" : p.status === "rejected" ? "st-cancelled" : "st-pending"}">${PAY_ID[p.status]}</span> ${p.admin_note ? `— ${esc(p.admin_note)}` : ""}</p>`).join("") : `<p class="muted">Belum ada bukti pembayaran.</p>`}
      ${["pending_payment","payment_review"].includes(o.status) ? `<a class="btn primary small" href="#/payment/${esc(o.order_code)}">Bayar / Upload Ulang Bukti</a>` : ""}
    </div>
    ${o.status === "cancelled" ? `<div class="order-item cancel-notice"><h3>Pesanan Dibatalkan</h3><p>Pesanan ini telah dibatalkan. DP yang telah dibayarkan tidak dikembalikan.</p><p><b>Rental:</b> Dibatalkan<br><b>Pembayaran:</b> ${PAYMENT_STATUS_ID[o.payment_summary?.status] || "Belum dibayar"}<br><b>Refund:</b> Tidak Ada</p></div>` : ""}
    ${o.ktp ? `<div class="order-item"><h3>KTP</h3><p class="muted">NIK: <b>${esc(o.ktp.nik_masked)}</b> • ${esc(o.ktp.full_name)} • ${PAY_ID[o.ktp.status] || o.ktp.status}</p></div>` : ""}
    ${["pending_payment","payment_review","paid","preparing"].includes(o.status) ? `<button class="btn ghost" onclick="confirmCancelOrder('${esc(o.order_code)}')">Batalkan Pesanan</button>` : ""}
    ${o.status === "completed" && !o.review ? `
    <div class="order-item"><h3>Beri Review ⭐</h3>
      <form onsubmit="submitReview(event,'${esc(o.order_code)}')">
        <label>Rating <select name="rating" required><option value="">Pilih</option><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option></select></label>
        <label>Ulasan <textarea name="text" required></textarea></label>
        <label>Foto (opsional) <input type="file" id="revFile" accept="image/*"></label>
        <button class="btn primary">Kirim Review</button>
      </form></div>` : ""}
    ${o.review ? `<div class="order-item"><h3>Review kamu</h3><p>${"⭐".repeat(o.review.rating)} • ${PAY_ID[o.review.status] === undefined ? "" : ""}<span class="muted">${o.review.status === "approved" ? "Ditampilkan" : "Menunggu moderasi"}</span></p><p>${esc(o.review.text)}</p></div>` : ""}`;
}
function canEditOrder(o) { return !!o && !["cancelled","completed"].includes(o.status) && String(o.payment_summary?.status || "unpaid") !== "paid"; }
function toggleOrderEdit() { const p=$("#orderEditPanel"); if(p) p.hidden=!p.hidden; }
async function loadAiRecommendations() {
  const box=$("#aiRecommendations"); if(!box || !curCostume?.id) return;
  box.hidden=false; box.innerHTML='<p class="muted">Mencari rekomendasi…</p>';
  try { const r=await fetch(`/api/recommendations?costume_id=${encodeURIComponent(curCostume.id)}`,{cache:"no-store"}); const d=await r.json(); const items=d.items||[]; box.innerHTML=items.length?`<h3>💡 Rekomendasi untukmu</h3><div class="mini-reco-grid">${items.map(x=>`<button type="button" class="reco-card" onclick="openCostume(${Number(x.id)})">${x.main_image?`<img src="${esc(x.main_image)}" alt="">`:''}<b>${esc(x.name)}</b><small>${esc(x.series||x.category||'')} • ${rupiah(x.price_per_day)}/3 hari</small></button>`).join('')}</div>`:'<p class="muted">Belum ada rekomendasi serupa.</p>'; } catch { box.innerHTML='<p class="muted">Rekomendasi belum tersedia.</p>'; }
}
function askAiAboutCostume() {
  if($("#aiPanel").classList.contains("hidden")) toggleAiChat();
  const msg=`Jelaskan kostum ini dan bantu aku memutuskan apakah cocok untukku: ${curCostume?.name||""}, series ${curCostume?.series||""}, kategori ${curCostume?.category||""}, harga ${rupiah(curCostume?.price_per_day||0)}/3 hari. Jangan mengarang data.`;
  $("#aiInput").value=msg; sendAiMsg();
}
async function saveOrderEdit(e, code) {
  e.preventDefault(); const d=Object.fromEntries(new FormData(e.target));
  if(d.return_date<d.ship_date) return alert("Tanggal kembali tidak boleh sebelum tanggal kirim.");
  const res=await api(`/orders/${encodeURIComponent(code)}`,{method:"PUT",body:JSON.stringify(d)});
  if(res.ok){ alert("Detail pesanan berhasil diperbarui."); renderOrderDetail(code); } else alert(res.data.error||"Gagal menyimpan perubahan");
}

function confirmCancelOrder(code) {
  $("#modalBody").innerHTML = `
    <h2>Batalkan Pesanan?</h2>
    <p>Batalkan pesanan ini?</p>
    <p class="muted">DP yang sudah dibayar tidak dikembalikan dan tanggal rental akan tersedia kembali untuk customer lain.</p>
    <div class="row" style="justify-content:flex-end;margin-top:16px">
      <button class="btn ghost" onclick="closeModal()">Kembali</button>
      <button class="btn primary" onclick="cancelOrder('${esc(code)}')">Ya, Batalkan</button>
    </div>`;
  $("#modal").classList.remove("hidden");
}
async function cancelOrder(code) {
  const res = await api(`/orders/${encodeURIComponent(code)}/cancel`, { method: "POST" });
  if (res.ok) { closeModal(); alert("Pesanan dibatalkan. DP yang sudah dibayar tidak dikembalikan."); renderOrderDetail(code); }
  else alert(res.data.error || "Pesanan gagal dibatalkan");
}
async function submitReview(e, code) {
  e.preventDefault();
  const d = Object.fromEntries(new FormData(e.target));
  const file = $("#revFile").files[0];
  const body = { rating: +d.rating, text: d.text };
  if (file) body.photo = await compress(file, 1000, 0.7);
  const res = await api(`/orders/${encodeURIComponent(code)}/review`, { method: "POST", body: JSON.stringify(body) });
  if (res.ok) { alert("Terima kasih! Review menunggu moderasi admin."); renderOrderDetail(code); }
  else alert(res.data.error);
}

/* ============ PROFILE ============ */
function renderProfile() {
  const el = $("#profileBody");
  if (!state.user) { el.innerHTML = `<h2>Profil</h2><div class="login-cta"><p>Masuk untuk melihat profil.</p><button class="btn primary small" onclick="openAuth('login')">Masuk</button></div>`; return; }
  const u = state.user;
  el.innerHTML = `
    <h2>Profil</h2>
    <form class="profile-form" onsubmit="saveProfile(event)">
      <label>Nama <input name="name" value="${esc(u.name)}" required></label>
      <label>Email <input value="${esc(u.email)}" disabled></label>
      <label>No. HP <input name="phone" value="${esc(u.phone || "")}"></label>
      <label>Alamat <textarea name="address">${esc(u.address || "")}</textarea></label>
      <label>Nama penerima <input name="recipient_name" value="${esc(u.recipient_name || "")}"></label>
      <label>No. HP penerima <input name="recipient_phone" value="${esc(u.recipient_phone || "")}"></label>
      <button class="btn primary">Simpan Profil</button>
    </form>
    <h3 style="margin-top:24px">Ganti Password</h3>
    <form class="profile-form" onsubmit="changePass(event)">
      <label>Password lama <input type="password" name="old" required></label>
      <label>Password baru <input type="password" name="new" required minlength="6"></label>
      <button class="btn ghost">Ganti Password</button>
    </form>
    <p class="muted" style="margin-top:16px;font-size:13px">Lupa password? Hubungi admin untuk password sementara.</p>
    <button class="btn ghost" style="margin-top:16px" onclick="logout()">Keluar</button>`;
}
async function saveProfile(e) {
  e.preventDefault();
  const d = Object.fromEntries(new FormData(e.target));
  const res = await api("/profile", { method: "PUT", body: JSON.stringify(d) });
  alert(res.ok ? "Profil tersimpan ✅" : res.data.error || "Gagal");
  initAuth();
}
async function changePass(e) {
  e.preventDefault();
  const d = Object.fromEntries(new FormData(e.target));
  const res = await api("/profile/password", { method: "POST", body: JSON.stringify(d) });
  alert(res.ok ? "Password diganti ✅" : res.data.error || "Gagal");
  if (res.ok) e.target.reset();
}

/* ============ AI CUSTOMER ============ */
function toggleAiChat() {
  $("#aiPanel").classList.toggle("hidden");
  if (!$("#aiPanel").classList.contains("hidden") && !$("#aiMsgs").children.length) {
    aiBubble("Hai! Aku Agent COSRENT 🤖\nAku bisa bantu cari kostum, cek harga, ukuran, aturan, dan proses rental.", "ai");
  }
}
function aiBubble(text, who) {
  const d = document.createElement("div");
  d.className = "bubble " + who; d.textContent = text;
  $("#aiMsgs").appendChild(d); $("#aiMsgs").scrollTop = $("#aiMsgs").scrollHeight;
}
async function sendAiMsg() {
  const inp = $("#aiInput"), msg = inp.value.trim();
  if (!msg) return;
  inp.value = ""; aiBubble(msg, "me"); aiBubble("Sedang mengetik...", "ai");
  const context = curCostume ? `\nKonteks kostum yang sedang dilihat: ${curCostume.name||""} | ${curCostume.series||""} | ${curCostume.category||""} | Rp${Number(curCostume.price_per_day||0).toLocaleString("id-ID")}/3 hari.` : "";
  const res = await api("/ai-assistant", { method: "POST", body: JSON.stringify({ message: msg + context }) });
  $("#aiMsgs").lastChild.remove();
  aiBubble(res.data.reply || "Tidak ada jawaban.", "ai");
  if (res.data.open_costume_id) { toggleAiChat(); openCostume(res.data.open_costume_id); }
}

/* ============ INIT ============ */
 $("#navToggle").addEventListener("click", () => document.body.classList.toggle("nav-open"));
 $("#navLinks").addEventListener("click", () => document.body.classList.remove("nav-open"));
let debounceT;
 $("#fSearch")?.addEventListener("input", () => { clearTimeout(debounceT); debounceT = setTimeout(loadCostumes, 300); });
["#fCategory", "#fGender", "#fMaxPrice", "#fDate"].forEach((s) => $(s)?.addEventListener("change", loadCostumes));
 $("#lightboxImg").addEventListener("dblclick", toggleLbZoom);
 $("#lightboxImg").addEventListener("pointerdown", (e) => { if (lbZoomed) { lbDrag = { x: e.clientX, y: e.clientY, px: lbPX, py: lbPY }; e.target.setPointerCapture(e.pointerId); } });
 $("#lightboxImg").addEventListener("pointermove", (e) => {
  if (!lbDrag) return;
  lbPX = lbDrag.px + (e.clientX - lbDrag.x); lbPY = lbDrag.py + (e.clientY - lbDrag.y);
  $("#lightboxImg").style.transform = `translate(${lbPX}px,${lbPY}px) scale(2)`;
});
 $("#lightboxImg").addEventListener("pointerup", () => (lbDrag = null));
 $("#lightbox").addEventListener("click", (e) => { if (e.target === $("#lightbox")) closeLightbox(); });
document.addEventListener("keydown", (e) => {
  const lbOpen = !$("#lightbox").classList.contains("hidden");
  if (e.key === "Escape") lbOpen ? closeLightbox() : closeModal();
  if (lbOpen) { if (e.key === "ArrowRight") lbNav(1); if (e.key === "ArrowLeft") lbNav(-1); }
});

async function loadSettings() {
  const r = await fetch("/api/settings", { cache: "no-store", headers: { "cache-control": "no-cache" } });
  const data = r.ok ? await r.json() : {};
  if (!r.ok && !data.settings) throw new Error(data.error || `Settings HTTP ${r.status}`);
  state.settings = {...DEFAULTS, ...(data.settings || data || {})};
  return data;
}
function applySettings(data = {}) {
  const s = state.settings;
  const root = document.documentElement;
  if (s.primary_color) root.style.setProperty("--accent", s.primary_color);
  if (s.accent_color) root.style.setProperty("--accent", s.accent_color);
  if (s.background_color) root.style.setProperty("--bg", s.background_color);
  document.title = s.site_title || DEFAULTS.site_title;
  $("#brand1").textContent = s.brand_1 || DEFAULTS.brand_1; $("#brand2").textContent = s.brand_2 || DEFAULTS.brand_2;
  const brandEl = document.querySelector(".brand");
  if (brandEl) {
    const logo = String(s.logo_url || "").trim();
    let img = brandEl.querySelector(".site-logo");
    if (logo) {
      if (!img) { img = document.createElement("img"); img.className = "site-logo"; brandEl.prepend(img); }
      img.src = logo; img.alt = s.site_title || "COSRENT";
      $("#brand1").style.display = "none"; $("#brand2").style.display = "none";
    } else {
      if (img) img.remove();
      $("#brand1").style.display = ""; $("#brand2").style.display = "";
    }
  }
  const links = parseJsonSetting(s.nav_links, parseJsonSetting(DEFAULTS.nav_links, []));
  $("#navLinks").innerHTML = links.map((l) => `<a href="${esc(l.href || "/")}">${esc(l.label || "Menu")}</a>`).join("");
  $("#heroEyebrow").textContent = s.hero_eyebrow || DEFAULTS.hero_eyebrow;
  $("#heroTitle1").textContent = s.hero_title_1 || DEFAULTS.hero_title_1; $("#heroTitle2").textContent = s.hero_title_2 || DEFAULTS.hero_title_2;
  $("#heroCopy").textContent = s.hero_copy || DEFAULTS.hero_copy;
  $("#btnPrimary").textContent = s.btn_primary_text || DEFAULTS.btn_primary_text; $("#btnPrimary").href = s.btn_primary_href || DEFAULTS.btn_primary_href;
  $("#btnGhost").textContent = s.btn_ghost_text || DEFAULTS.btn_ghost_text; $("#btnGhost").href = s.btn_ghost_href || DEFAULTS.btn_ghost_href;
  $("#catalogEyebrow").textContent = s.catalog_eyebrow || DEFAULTS.catalog_eyebrow; $("#catalogTitle").textContent = s.catalog_title || DEFAULTS.catalog_title;
  $("#howEyebrow").textContent = s.how_eyebrow || DEFAULTS.how_eyebrow; $("#howTitle").textContent = s.how_title || DEFAULTS.how_title;
  $("#rulesEyebrow").textContent = s.rules_eyebrow || DEFAULTS.rules_eyebrow; $("#rulesTitle").textContent = s.rules_title || DEFAULTS.rules_title;
  const catSelect = $("#fCategory");
  if (catSelect) {
    const keep = catSelect.options[0]?.outerHTML || '<option value="">Semua kategori</option>';
    catSelect.innerHTML = keep;
    const configured = parseJsonSetting(s.categories, []);
    const fallback = parseJsonSetting(DEFAULTS.categories, []);
    const cats = configured.length ? configured : fallback;
    cats.forEach((c) => { const o=document.createElement("option"); o.value=String(c.slug || c.name || "").trim(); o.textContent=String(c.name || c.slug || "").trim(); catSelect.appendChild(o); });
  }
  $("#heroCardLabel").textContent = s.featured_label || DEFAULTS.featured_label;
  const fd = $("#footerDescription"); if (fd) fd.textContent = s.footer_description || DEFAULTS.footer_description;
  const ig = $("#footerInstagram"); if (ig && s.instagram) { ig.href = s.instagram.startsWith("http") ? s.instagram : `https://instagram.com/${s.instagram.replace(/^@/,"")}`; ig.textContent = s.instagram; }
  if (s.favicon_url) { let f=document.querySelector('link[rel="icon"]'); if(!f){f=document.createElement("link");f.rel="icon";document.head.appendChild(f)} f.href=s.favicon_url; }
}

(async () => {
  let data = {};
  try {
    data = await loadSettings();
    applySettings(data);
    const featured = data.featured || null;
    $("#heroCardName").textContent = featured?.name || "Koleksi COSRENT";
    $("#heroCardPrice").textContent = featured ? `Mulai ${rupiah(featured.price_per_day)} / hari` : "Pilih kostum favoritmu dari katalog";
    if (featured) { const detail=await fetch(`/api/costumes/${featured.id}`, {cache:"no-store"}).then(r=>r.ok?r.json():null).catch(()=>null); if(detail?.main_image){$("#heroCardImg").src=detail.main_image;$("#heroCardImg").hidden=false;} }
  } catch (e) { console.error("Settings gagal dimuat", e); state.settings={...DEFAULTS}; applySettings({}); }
  $("#footerYear").textContent = new Date().getFullYear();
  if (String(state.settings.customer_ai_enabled ?? "1") === "0") $("#aiFab").classList.add("hidden");
  else $("#aiFab").classList.remove("hidden");
  if (state.settings.maintenance_mode === "1") {
    const overlay = document.createElement("div");
    overlay.className = "maintenance-overlay";
    overlay.innerHTML = `<div class="maintenance-card"><span class="eyebrow">MAINTENANCE</span><h2>${esc(state.settings.maintenance_message || "COSRENT sedang melakukan pemeliharaan.")}</h2><p class="muted">Silakan kembali beberapa saat lagi.</p></div>`;
    document.body.appendChild(overlay);
  }
  await initAuth();
  window.addEventListener("hashchange", route);
  await route();
})();