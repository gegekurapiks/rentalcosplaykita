const LEGAL_PAGE = document.body.dataset.page || "about";
const DEFAULT_LEGAL = {
  terms: {title:"Syarat & Ketentuan", key:"terms_content", fallback:"Ketentuan penggunaan\n\nRental\n\nPembayaran\n\nPembatalan\n\nPengembalian\n\nKerusakan\n\nTanggung jawab pengguna."},
  rules: {title:"Rules", key:"rules_content", fallback:"Peraturan penggunaan website\n\nPeraturan rental\n\nLarangan\n\nKetentuan transaksi."},
  privacy: {title:"Privacy Policy", key:"privacy_content", fallback:"Data yang dikumpulkan\n\nPenggunaan data\n\nPenyimpanan data\n\nCookies/localStorage\n\nKontak."},
  about: {title:"Tentang Kami", key:"about_content", fallback:"COSRENT adalah layanan rental kostum cosplay."},
  contact: {title:"Kontak", key:"contact_content", fallback:"Hubungi COSRENT melalui informasi kontak yang tersedia."}
};
const esc = t => String(t ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
function renderContent(text){
  return String(text||"").split(/\n\s*\n/).map(block=>{
    const lines=block.split(/\n/).map(x=>x.trim()).filter(Boolean);
    if(!lines.length) return "";
    if(lines.every(x=>x.startsWith("- "))) return `<ul>${lines.map(x=>`<li>${esc(x.slice(2))}</li>`).join("")}</ul>`;
    if(lines.length>1 && lines.every(x=>/^\d+[.)]\s+/.test(x))) return `<ol>${lines.map(x=>`<li>${esc(x.replace(/^\d+[.)]\s+/,""))}</li>`).join("")}</ol>`;
    return `<p>${lines.map(esc).join("<br>")}</p>`;
  }).join("");
}
async function loadLegal(){
  const meta=DEFAULT_LEGAL[LEGAL_PAGE]||DEFAULT_LEGAL.about;
  document.title=`${meta.title} — COSRENT`;
  document.querySelector("#pageTitle").textContent=meta.title;
  const r=await fetch("/api/settings",{cache:"no-store",headers:{"cache-control":"no-cache"}});
  const data=r.ok?await r.json():{}; const s=data.settings||{};
  document.querySelector("#pageContent").innerHTML=renderContent(s[meta.key]||meta.fallback);
  document.querySelector("#brand").textContent=(s.brand_1||"COS")+(s.brand_2||"RENT");
  document.querySelector("#year").textContent=new Date().getFullYear();
}
loadLegal().catch(e=>{console.error(e); const meta=DEFAULT_LEGAL[LEGAL_PAGE]||DEFAULT_LEGAL.about; document.querySelector("#pageContent").innerHTML=renderContent(meta.fallback); document.querySelector("#year").textContent=new Date().getFullYear();});