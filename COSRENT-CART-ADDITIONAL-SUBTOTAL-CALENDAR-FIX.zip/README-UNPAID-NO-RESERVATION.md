# COSRENT — Unpaid orders do not reserve rental dates

Changes in this patch:
- `pending_payment` / unpaid orders do not block calendar availability.
- Dates become blocked after payment proof is submitted (`payment_review`) or payment is approved/confirmed.
- Payment-proof submission rechecks the requested rental dates to prevent two unpaid orders from reserving the same dates.
- Order edit conflict checks use the same paid/payment-review blocking statuses.
- No database migration or reset is required.
