﻿CREATE TABLE IF NOT EXISTS policies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL DEFAULT 'rule',
  text TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0
);
ALTER TABLE orders ADD COLUMN fine_amount INTEGER NOT NULL DEFAULT 0;
ALTER TABLE orders ADD COLUMN fine_note TEXT NOT NULL DEFAULT '';

UPDATE settings SET value='COSRENT - Sewa Kostum Cosplay' WHERE key='site_title';
UPDATE settings SET value='Sewa kostum cosplay anime dengan mudah, aman, dan terpercaya.' WHERE key='site_description';
UPDATE settings SET value='[{"label":"Katalog","href":"#catalog"},{"label":"Cara Sewa","href":"#how"},{"label":"Aturan","href":"#rules"},{"label":"Pesanan","href":"#dashboard"}]' WHERE key='nav_links';
UPDATE settings SET value='SEWA KOSTUM COSPLAY - INDONESIA' WHERE key='hero_eyebrow';
UPDATE settings SET value='Wujudkan karaktermu' WHERE key='hero_title_1';
UPDATE settings SET value='yang paling favorit.' WHERE key='hero_title_2';
UPDATE settings SET value='Sewa kostum cosplay siap pakai: cek ukuran, ketersediaan tanggal, pilihan kurir, dan pembayaran QRIS.' WHERE key='hero_copy';
UPDATE settings SET value='Lihat Katalog' WHERE key='btn_primary_text';
UPDATE settings SET value='Cara Sewa' WHERE key='btn_ghost_text';
UPDATE settings SET value='UNGGULAN' WHERE key='featured_label';
UPDATE settings SET value='KOLEKSI' WHERE key='catalog_eyebrow';
UPDATE settings SET value='Temukan karaktermu.' WHERE key='catalog_title';
UPDATE settings SET value='ALUR MUDAH' WHERE key='how_eyebrow';
UPDATE settings SET value='Dari lemari ke event.' WHERE key='how_title';
UPDATE settings SET value='PELANGGAN' WHERE key='dashboard_eyebrow';
UPDATE settings SET value='Dashboard pesananmu.' WHERE key='dashboard_title';

INSERT OR IGNORE INTO settings (key, value) VALUES
  ('fine_per_day','25000'),
  ('deposit_amount','100000'),
  ('fine_damage_text','Kerusakan ringan dikenakan biaya perawatan. Kerusakan berat dikenakan biaya perbaikan penuh sesuai kondisi kostum.'),
  ('fine_lost_text','Kehilangan kostum atau aksesori dikenakan ganti senilai 3x harga sewa per hari.'),
  ('fines_note','Semua denda dibayarkan saat pengembalian, atau dipotong dari deposit.'),
  ('rules_eyebrow','PERATURAN'),
  ('rules_title','Peraturan sewa.'),
  ('terms_eyebrow','S & K'),
  ('terms_title','Syarat dan ketentuan.'),
  ('fines_eyebrow','DENDA'),
  ('fines_title','Biar jelas dari awal.');

INSERT INTO policies (type, text, sort_order) SELECT 'rule','Wajib menyerahkan foto KTP yang sama dengan data pemesan (NIK harus diblur saat upload).',1 WHERE NOT EXISTS (SELECT 1 FROM policies WHERE text='Wajib menyerahkan foto KTP yang sama dengan data pemesan (NIK harus diblur saat upload).');
INSERT INTO policies (type, text, sort_order) SELECT 'rule','Kostum wajib dikembalikan dalam kondisi yang sama seperti saat diterima.',2 WHERE NOT EXISTS (SELECT 1 FROM policies WHERE text='Kostum wajib dikembalikan dalam kondisi yang sama seperti saat diterima.');
INSERT INTO policies (type, text, sort_order) SELECT 'rule','Dilarang mencuci, menggunting, menjahit, atau memodifikasi kostum.',3 WHERE NOT EXISTS (SELECT 1 FROM policies WHERE text='Dilarang mencuci, menggunting, menjahit, atau memodifikasi kostum.');
INSERT INTO policies (type, text, sort_order) SELECT 'rule','Wajib memakai kaos dalam (inner) saat memakai kostum agar tidak meninggalkan noda.',4 WHERE NOT EXISTS (SELECT 1 FROM policies WHERE text='Wajib memakai kaos dalam (inner) saat memakai kostum agar tidak meninggalkan noda.');
INSERT INTO policies (type, text, sort_order) SELECT 'rule','Pembatalan H-1 sebelum pengambilan dikenakan biaya 50% dari total sewa.',5 WHERE NOT EXISTS (SELECT 1 FROM policies WHERE text='Pembatalan H-1 sebelum pengambilan dikenakan biaya 50% dari total sewa.');
INSERT INTO policies (type, text, sort_order) SELECT 'rule','Pengambilan dan pengembalian dilakukan di alamat yang disepakati bersama admin.',6 WHERE NOT EXISTS (SELECT 1 FROM policies WHERE text='Pengambilan dan pengembalian dilakukan di alamat yang disepakati bersama admin.');
INSERT INTO policies (type, text, sort_order) SELECT 'term','Pesanan dianggap sah setelah pembayaran dikonfirmasi oleh admin.',1 WHERE NOT EXISTS (SELECT 1 FROM policies WHERE text='Pesanan dianggap sah setelah pembayaran dikonfirmasi oleh admin.');
INSERT INTO policies (type, text, sort_order) SELECT 'term','Deposit ditahan dan dikembalikan penuh setelah kostum lolos pemeriksaan.',2 WHERE NOT EXISTS (SELECT 1 FROM policies WHERE text='Deposit ditahan dan dikembalikan penuh setelah kostum lolos pemeriksaan.');
INSERT INTO policies (type, text, sort_order) SELECT 'term','Keterlambatan pengembalian dikenakan denda per hari sesuai tarif yang berlaku.',3 WHERE NOT EXISTS (SELECT 1 FROM policies WHERE text='Keterlambatan pengembalian dikenakan denda per hari sesuai tarif yang berlaku.');
INSERT INTO policies (type, text, sort_order) SELECT 'term','Kerusakan atau kehilangan aksesori dikenakan biaya penggantian sesuai kondisi.',4 WHERE NOT EXISTS (SELECT 1 FROM policies WHERE text='Kerusakan atau kehilangan aksesori dikenakan biaya penggantian sesuai kondisi.');
INSERT INTO policies (type, text, sort_order) SELECT 'term','Admin berhak menolak pesanan jika data pemesan tidak valid atau tidak sesuai.',5 WHERE NOT EXISTS (SELECT 1 FROM policies WHERE text='Admin berhak menolak pesanan jika data pemesan tidak valid atau tidak sesuai.');
INSERT INTO policies (type, text, sort_order) SELECT 'term','Harga sewa sudah termasuk perawatan standar setelah kostum dikembalikan.',6 WHERE NOT EXISTS (SELECT 1 FROM policies WHERE text='Harga sewa sudah termasuk perawatan standar setelah kostum dikembalikan.');
