﻿DROP TABLE IF EXISTS order_items; DROP TABLE IF EXISTS payments; DROP TABLE IF EXISTS shipping;
DROP TABLE IF EXISTS reviews; DROP TABLE IF EXISTS maintenance; DROP TABLE IF EXISTS ktp_records;
DROP TABLE IF EXISTS ktp_uploads; DROP TABLE IF EXISTS ai_drafts; DROP TABLE IF EXISTS payment_methods;
DROP TABLE IF EXISTS orders; DROP TABLE IF EXISTS costume_sizes; DROP TABLE IF EXISTS costume_images;
DROP TABLE IF EXISTS size_measurements; DROP TABLE IF EXISTS sessions; DROP TABLE IF EXISTS costumes;
DROP TABLE IF EXISTS categories; DROP TABLE IF EXISTS steps; DROP TABLE IF EXISTS policies; DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  recipient_name TEXT NOT NULL DEFAULT '',
  recipient_phone TEXT NOT NULL DEFAULT '',
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'customer',
  must_change_password INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

CREATE TABLE costumes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  character TEXT NOT NULL DEFAULT '',
  series TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT '',
  gender TEXT NOT NULL DEFAULT 'unisex',
  price_per_day INTEGER NOT NULL DEFAULT 0,
  description TEXT NOT NULL DEFAULT '',
  package_items TEXT NOT NULL DEFAULT '[]',
  includes_wig INTEGER NOT NULL DEFAULT 0,
  includes_styling INTEGER NOT NULL DEFAULT 0,
  accessories TEXT NOT NULL DEFAULT '[]',
  rules_text TEXT NOT NULL DEFAULT '',
  size_guide_image TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'published',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_costumes_series ON costumes(series);

CREATE TABLE costume_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  costume_id INTEGER NOT NULL REFERENCES costumes(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'detail',
  is_ai INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_images_costume ON costume_images(costume_id);

CREATE TABLE costume_sizes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  costume_id INTEGER NOT NULL REFERENCES costumes(id) ON DELETE CASCADE,
  size TEXT NOT NULL,
  stock INTEGER NOT NULL DEFAULT 1,
  UNIQUE(costume_id, size)
);
CREATE TABLE size_measurements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  costume_id INTEGER NOT NULL REFERENCES costumes(id) ON DELETE CASCADE,
  size TEXT NOT NULL, field TEXT NOT NULL, value_cm REAL NOT NULL
);

CREATE TABLE orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_code TEXT UNIQUE NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'pending_payment',
  ship_date TEXT NOT NULL, event_date TEXT NOT NULL, return_date TEXT NOT NULL,
  ship_address TEXT NOT NULL DEFAULT '',
  recipient_name TEXT NOT NULL DEFAULT '', recipient_phone TEXT NOT NULL DEFAULT '',
  subtotal INTEGER NOT NULL DEFAULT 0, shipping_cost INTEGER NOT NULL DEFAULT 0,
  fine_amount INTEGER NOT NULL DEFAULT 0, fine_note TEXT NOT NULL DEFAULT '',
  total INTEGER NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);

CREATE TABLE order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  costume_id INTEGER NOT NULL REFERENCES costumes(id),
  costume_name TEXT NOT NULL DEFAULT '',
  size TEXT NOT NULL, price_per_day INTEGER NOT NULL, days INTEGER NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX idx_items_order ON order_items(order_id);

CREATE TABLE payment_methods (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'ewallet',
  account_number TEXT NOT NULL DEFAULT '', account_name TEXT NOT NULL DEFAULT '',
  instructions TEXT NOT NULL DEFAULT '', qr_image TEXT NOT NULL DEFAULT '',
  is_active INTEGER NOT NULL DEFAULT 1, sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  method_id INTEGER REFERENCES payment_methods(id),
  amount INTEGER NOT NULL, proof_image TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', admin_note TEXT NOT NULL DEFAULT '',
  verified_by INTEGER REFERENCES users(id), verified_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_payments_order ON payments(order_id);

CREATE TABLE shipping (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER UNIQUE NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  courier TEXT NOT NULL DEFAULT '', service TEXT NOT NULL DEFAULT '',
  cost INTEGER NOT NULL DEFAULT 0, tracking_number TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending', shipped_at TEXT
);
CREATE TABLE ktp_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  order_id INTEGER REFERENCES orders(id),
  nik_hash TEXT NOT NULL, nik_masked TEXT NOT NULL, full_name TEXT NOT NULL DEFAULT '',
  image TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER UNIQUE NOT NULL REFERENCES orders(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  costume_id INTEGER NOT NULL REFERENCES costumes(id),
  rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
  text TEXT NOT NULL DEFAULT '', photo TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_reviews_costume ON reviews(costume_id);
CREATE TABLE maintenance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  costume_id INTEGER NOT NULL REFERENCES costumes(id) ON DELETE CASCADE,
  start_date TEXT NOT NULL, end_date TEXT NOT NULL, note TEXT NOT NULL DEFAULT ''
);
CREATE TABLE ai_drafts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  image TEXT NOT NULL, result_json TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'draft',
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE settings ( key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT '' );

INSERT INTO users (name,email,password_hash,role) VALUES ('Admin','admin@cosrent.id','plain$admin123','admin');

INSERT INTO settings (key,value) VALUES
 ('brand_1','COS'),('brand_2','RENT'),
 ('site_title','COSRENT - Sewa Kostum Cosplay'),
 ('site_description','Sewa kostum cosplay anime dengan mudah, aman, dan terpercaya.'),
 ('nav_links','[{"label":"Beranda","href":"#/"},{"label":"Katalog","href":"#/catalog"},{"label":"Pesanan","href":"#/orders"}]'),
 ('hero_eyebrow','SEWA KOSTUM COSPLAY - INDONESIA'),
 ('hero_title_1','Wujudkan karaktermu'),('hero_title_2','yang paling favorit.'),
 ('hero_copy','Sewa kostum cosplay siap pakai: cek ukuran, ketersediaan tanggal, pengiriman, dan pembayaran manual yang terverifikasi admin.'),
 ('btn_primary_text','Lihat Katalog'),('btn_primary_href','#/catalog'),
 ('btn_ghost_text','Cara Sewa'),('btn_ghost_href','#/#how'),
 ('featured_label','UNGGULAN'),('featured_costume_id','1'),
 ('catalog_eyebrow','KOLEKSI'),('catalog_title','Temukan karaktermu.'),
 ('how_eyebrow','ALUR MUDAH'),('how_title','Dari lemari ke event.'),
 ('steps_list','[{"number":"01","title":"Pilih kostum","description":"Cari karakter, cek galeri foto, size guide, dan isi paket."},{"number":"02","title":"Pilih tanggal & ukuran","description":"Sistem cek ketersediaan per ukuran berdasarkan tanggal kirim s/d kembali."},{"number":"03","title":"Checkout & bayar","description":"Transfer manual ke metode yang dipilih, upload bukti."},{"number":"04","title":"Verifikasi & kirim","description":"Admin verifikasi pembayaran, tentukan ongkir, kirim kostum."}]'),
 ('rules_eyebrow','ATURAN'),('rules_title','Peraturan sewa.'),
 ('rules_list','["Wajib menyerahkan data diri valid; NIK disimpan aman dan tidak pernah ditampilkan penuh.","Kostum wajib dikembalikan dalam kondisi yang sama seperti saat diterima.","Dilarang mencuci, menggunting, menjahit, atau memodifikasi kostum.","Wajib memakai kaos dalam (inner) saat memakai kostum.","Pembatalan H-1 sebelum pengiriman dikenakan biaya 50% dari total sewa.","Foto asli kostum selalu ditampilkan; gambar AI hanya pelengkap, bukan pengganti."]'),
 ('terms_eyebrow','S & K'),('terms_title','Syarat dan ketentuan.'),
 ('terms_list','["Pesanan dianggap sah setelah pembayaran diverifikasi admin.","Ongkir ditentukan oleh admin setelah checkout, bukan diisi customer.","Keterlambatan pengembalian dikenakan denda per hari sesuai tarif.","Kerusakan atau kehilangan dikenakan biaya penggantian.","Lupa password? Hubungi admin untuk mendapatkan password sementara."]'),
 ('fines_eyebrow','DENDA'),('fines_title','Biar jelas dari awal.'),
 ('fine_per_day','25000'),('deposit_amount','100000'),
 ('fine_damage_text','Kerusakan ringan dikenakan biaya perawatan. Kerusakan berat dikenakan biaya perbaikan penuh sesuai kondisi kostum.'),
 ('fine_lost_text','Kehilangan kostum atau aksesori dikenakan ganti senilai 3x harga sewa per hari.'),
 ('fines_note','Semua denda dibayarkan saat pengembalian, atau dipotong dari deposit.'),
 ('dashboard_eyebrow','PELANGGAN'),('dashboard_title','Pesanan & status rental.'),
 ('ktp_required','1'),
 ('categories','[{"slug":"kimono","name":"Kimono"},{"slug":"school","name":"Sekolah"},{"slug":"armor","name":"Armor"},{"slug":"dress","name":"Gaun"}]'),
 ('ai_enabled','1'),('ai_provider','workers-ai'),
 ('ai_model','@cf/meta/llama-3.3-70b-instruct-fp8-fast'),
 ('ai_vision_model','@cf/meta/llama-3.2-11b-vision-instruct'),
 ('ai_api_key',''),('ai_base_url',''),
 ('ai_system_prompt','Kamu asisten COSRENT, platform sewa kostum cosplay Indonesia. Jawab HANYA dari data yang diberikan. Jangan pernah mengarang harga, stok, ukuran, isi paket, tanggal, atau aturan. Jika informasi tidak ada di data, katakan bahwa informasi tersebut belum tersedia. Untuk pertanyaan tanggal spesifik, sarankan user menggunakan fitur cek ketersediaan di halaman detail kostum. Jawab dalam Bahasa Indonesia.');

INSERT INTO payment_methods (name,type,account_number,account_name,instructions,is_active,sort_order) VALUES
 ('QRIS','qris','','COSRENT','Scan QRIS di bawah, lalu upload bukti pembayaran.',1,1),
 ('DANA','ewallet','081234567890','COSRENT','Transfer ke nomor DANA, lalu upload bukti.',1,2),
 ('BCA','bank','1234567890','PT COSRENT','Transfer ke rekening BCA a/n PT COSRENT, lalu upload bukti.',1,3);

INSERT INTO costumes (id,name,character,series,category,gender,price_per_day,description,package_items,includes_wig,includes_styling,accessories,rules_text,status) VALUES
 (1,'Fantasy Knight','Knight Commander','Original','armor','unisex',125000,'Set armor lengkap dengan cape dan properti pedang.','["Jaket armor","Cape","Sabuk","Pelindung lengan"]',0,0,'["Pedang properti"]','Wajib inner penuh. Dilarang kena hujan berlebih.','published'),
 (2,'Kimono Sakura','Yuki','Original','kimono','wanita',110000,'Kimono motif sakura dengan obi mengkilap.','["Kimono","Obi","Getah sandal"]',1,0,'[]','Wajib inner. Tidak boleh terkena tinta.','published');

INSERT INTO costume_images (costume_id,url,type,is_ai) VALUES
 (1,'https://placehold.co/600x800?text=Knight+Foto+Asli','main',0),
 (1,'https://placehold.co/800x600?text=Knight+Detail','detail',0),
 (1,'https://placehold.co/600x800?text=Knight+Versi+AI','ai_extra',1),
 (2,'https://placehold.co/600x800?text=Kimono+Foto+Asli','main',0),
 (2,'https://placehold.co/800x600?text=Kimono+Detail','detail',0);

INSERT INTO costume_sizes (costume_id,size,stock) VALUES
 (1,'M',1),(1,'L',1),(1,'XL',1),
 (2,'Free Size',2);

UPDATE settings SET value='1' WHERE key='featured_costume_id';