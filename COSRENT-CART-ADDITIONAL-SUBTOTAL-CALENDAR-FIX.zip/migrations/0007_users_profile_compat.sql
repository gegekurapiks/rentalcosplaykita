-- Backward-compatible profile columns for existing COSRENT D1 databases.
-- Safe to run only once through Wrangler migrations.
ALTER TABLE users ADD COLUMN phone TEXT DEFAULT '';
ALTER TABLE users ADD COLUMN address TEXT DEFAULT '';
ALTER TABLE users ADD COLUMN recipient_name TEXT DEFAULT '';
ALTER TABLE users ADD COLUMN recipient_phone TEXT DEFAULT '';
ALTER TABLE users ADD COLUMN must_change_password INTEGER DEFAULT 0;
