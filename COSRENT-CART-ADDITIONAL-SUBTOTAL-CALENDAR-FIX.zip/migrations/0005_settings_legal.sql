CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);

INSERT OR IGNORE INTO settings (key,value) VALUES
 ('site_title','COSRENT — Sewa Kostum Cosplay'),
 ('site_description','Sewa kostum cosplay dengan proses yang simpel, jelas, dan aman.'),
 ('brand_1','COS'),('brand_2','RENT'),
 ('logo_url',''),('favicon_url',''),
 ('instagram',''),('email',''),('address',''),('operating_hours',''),
 ('hero_eyebrow','RENTAL COSTUME COSPLAY'),
 ('hero_title_1','Cosplay jadi'),('hero_title_2','lebih mudah.'),
 ('hero_copy','Sewa kostum cosplay favoritmu dengan proses yang simpel, jelas, dan aman.'),
 ('footer_description','Sewa kostum cosplay dengan proses yang simpel, jelas, dan aman.'),
 ('terms_content','Ketentuan penggunaan

Rental

Pembayaran

Pembatalan

Pengembalian

Kerusakan

Tanggung jawab pengguna.'),
 ('rules_content','Peraturan penggunaan website

Peraturan rental

Larangan

Ketentuan transaksi.'),
 ('privacy_content','Data yang dikumpulkan

Penggunaan data

Penyimpanan data

Cookies/localStorage

Kontak.'),
 ('about_content','COSRENT adalah layanan rental kostum cosplay yang membantu pengguna menemukan kostum, memeriksa detail, dan melakukan pemesanan secara online.'),
 ('contact_content','Hubungi COSRENT melalui informasi kontak yang tersedia di halaman ini.'),
 ('nav_links','[{"label":"Beranda","href":"/"},{"label":"Katalog","href":"/#/catalog"},{"label":"Cara Sewa","href":"/#how"},{"label":"Aturan","href":"/rules.html"}]');
