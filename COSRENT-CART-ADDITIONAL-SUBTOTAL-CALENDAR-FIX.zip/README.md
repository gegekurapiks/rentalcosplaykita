# COSRENT — FINAL FIXED

Versi ini menggunakan:
- Email/password customer, tanpa Google Login
- Admin login terpisah
- Pembayaran manual (QRIS, DANA, ShopeePay, GoPay, OVO, transfer bank)
- Tanpa Pakasir
- Tanpa KTP
- Ongkir MANUAL oleh admin; tidak ada API Berdu / cek ongkir customer
- Admin dapat mengubah ongkir + kurir/layanan dari panel Pesanan
- Total pesanan dan nominal pembayaran diperbarui otomatis setelah ongkir diatur
- Admin dapat mengganti password dari menu Pengaturan

## Deploy

1. Pastikan `wrangler.toml` memakai D1 database COSRENT yang benar.
2. Jalankan migration:

```powershell
npx wrangler d1 migrations apply DB --remote
```

3. Set password admin pertama kali:

```powershell
npx wrangler secret put ADMIN_PASSWORD
```

Masukkan password admin yang kamu inginkan. Password ini hanya dipakai untuk bootstrap pertama. Setelah login pertama, hash password disimpan di D1 dan password dapat diganti dari `/admin/index.html` → **Pengaturan**.

4. Deploy:

```powershell
npx wrangler deploy
```

## Password admin

ZIP tidak menyimpan password admin produksi. Password admin adalah nilai Cloudflare Secret `ADMIN_PASSWORD` yang kamu set sendiri. Untuk menggantinya setelah login, buka **Admin → Pengaturan → Ganti Password Admin**.

Jika kamu lupa password yang tersimpan di D1, reset bootstrap dapat dilakukan dengan menghapus row `admin_settings` dari D1 lalu set `ADMIN_PASSWORD` baru dan login lagi.

## Alur ongkir

Customer membuat pesanan dengan alamat pengiriman. Ongkir awal = Rp0 dan customer **tidak dapat menentukan ongkir**.

Admin membuka **Pesanan → Atur ongkir**, memasukkan nominal dan nama kurir/layanan. Total otomatis dihitung ulang dan payment amount ikut diperbarui.

Customer tidak boleh mengirim bukti pembayaran sebelum admin menetapkan ongkir/layanan.

## Admin Settings

Admin configuration is centralized under **Admin → Settings**. Business/content settings are stored in D1 `settings`; sensitive `BERDU_API_KEY` and `AI_API_KEY` values entered through Settings are encrypted server-side when `SETTINGS_ENCRYPTION_KEY` is configured. Cloudflare environment secrets `BERDU_API_KEY` and `AI_API_KEY` take precedence over stored values.

Required for encrypted admin-managed secrets:
- `SETTINGS_ENCRYPTION_KEY` — long random Cloudflare Secret

Optional direct Cloudflare Secrets:
- `BERDU_API_KEY`
- `AI_API_KEY`

Secrets are never returned by `/api/settings` or `/api/admin/settings` as raw values.


## Perbaikan settings & navigasi
- Cloudflare Pages Functions hanya menggunakan `functions/api/[[route]].js`; runtime Worker lama sudah dihapus agar tidak ada backend duplikat.
- Jalankan migration `0005_settings_legal.sql` setelah migration sebelumnya.
- Settings publik diambil melalui `GET /api/settings` dengan `Cache-Control: no-store`.
- Halaman legal terpisah: `/terms.html`, `/rules.html`, `/privacy.html`, `/about.html`, `/contact.html`.
- Admin tersedia di `/admin/index.html`.
- API key tetap server-side dan tidak dikirim ke frontend.


## Pembatalan Rental
- Pembatalan menggunakan `status=cancelled`, tidak menghapus order.
- Availability mengabaikan order `cancelled`, sehingga tanggal otomatis tersedia kembali.
- Pembayaran/DP yang sudah diterima tetap tercatat; tidak ada refund otomatis.
- Customer dapat membatalkan sebelum status pengiriman/sewa aktif (`pending_payment`, `payment_review`, `paid`, `preparing`).
- Admin memiliki `Batalkan Pesanan` dan `Hapus Permanen` terpisah. Hard-delete hanya tersedia untuk order yang sudah cancelled.
